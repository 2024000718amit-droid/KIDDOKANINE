// ============================================================
// INDIA-SPECIFIC DEEP CLINICAL MATRIX
// Sources: Marwah 5th Ed. (Jaypee 2024), Shobha Tandon 3rd Ed. (Paras 2018),
// DCI Curriculum 2022, JISPPD research, Indian clinical context
// ============================================================

const INDIA_MATRIX = {

  // ── INFANT (0–18 months) ────────────────────────────────────────
  infant: {
    definitely_negative: {
      exam: buildRecord({
        success: "90%",
        duration: "10–15 min",
        durationTip: "Do not exceed 12 min active clinical time. Infant fatigue = behavior collapse.",
        protocol: "Knee-to-Knee Lap Examination (Marwah Ch.12)",
        stratTitle: "Knee-to-Knee with Parent Containment",
        stratDesc: "Set up knee-to-knee positioning — clinician and parent seated facing each other, child supine across both laps. Parent holds infant's hands firmly. This is the only acceptable exam position for infants. Crying is expected and normal — it opens the mouth. Keep the exam under 90 seconds. Use finger rather than mirror. Check for natal/neonatal teeth, ECC Type III signs, lip/tongue tie, mucosal health.",
        cultural: "Indian mothers often refuse to 'restrain' the child, interpreting it as harmful. Reframe: 'Aap ki god mein hi rahega, aap isko pakad ke rakhein taaki hum jaldi khatam karein.' Joint family members standing nearby will offer unsolicited advice — establish a single-adult rule at the door before entering.",
        techniques: ["Knee-to-Knee Positioning","Non-Verbal Communication","Positive Reinforcement (immediate)","Parent-Assisted Restraint"],
        checklist: [
          "Set up knee-to-knee before calling patient in — no adjustments with child present",
          "Ask all family except one adult guardian to wait outside",
          "Keep instruments (mirror, probe) in pocket; use only index finger for initial exam",
          "Have sticker / small toy as immediate post-exam reward visible to parent"
        ],
        escalation: [
          { title: "Step 1: Finger Exam Only", desc: "If crying intensifies, switch entirely to finger palpation. Get your data in 60 seconds." },
          { title: "Step 2: Defer Invasive Tx", desc: "For Frankl 1 infants, never attempt restoration in same sitting as first exam. Schedule desensitisation visit." },
          { title: "Step 3: Refer", desc: "If ECC Type III requiring extraction/GA, refer to paediatric dental specialist or dental hospital with GA facility." }
        ],
        drugs: [
          { name: "Topical LA 2% Lignocaine gel", dose: "Topical only", note: "For natal tooth extraction only. No injections ≤18 mo without specialist backup." }
        ],
        drugNote: "Avoid sedation in infants <18 months in outpatient setting. GA at accredited centre is the appropriate escalation if treatment under LA is not feasible.",
        scriptEn: "Mrs. [Name], we're going to do a quick tooth-counting game while your baby is lying in our laps together. She/he will likely cry — please know that is completely safe and normal, it actually helps us see the teeth. Your job is to hold her/his little hands snugly on her/his tummy. We'll be done in under two minutes.",
        scriptHi: "बहनजी, हम आपके बच्चे के दाँत गिनने का एक छोटा सा खेल खेलेंगे — आपकी गोद में ही। रोना बिल्कुल normal है, इससे हमें दाँत अच्छे से दिखते हैं। आप बस उनके हाथ पेट पर पकड़कर रखें। दो मिनट में हो जाएगा।",
        scriptNote: "*Goal: Normalise crying. Establish single-voice authority. Set time expectation (creates urgency and cooperation).",
        parentTactics: "For overprotective Indian mothers: Do NOT say 'It won't hurt' or 'Don't cry.' Instead give them an active role — 'Your job today is to hold these two hands.' This converts anxiety into a task. Avoid engaging grandparents or other family in the room.",
        failures: [
          "Attempting to separate infant from mother — immediate crisis",
          "Saying 'don't cry' — this signals something scary is coming",
          "Allowing multiple family members to talk simultaneously",
          "Using standard dental chair/recline position for infants",
          "Attempting restoration or LA in a Frankl 1 infant on first visit"
        ],
        flagActions: "ECC: Apply 38% SDF with parent consent — no LA needed, fast, highly effective in this age. Sickle cell/thalassaemia: consult haematologist before extraction. Tongue tie: assess with Kotlow classification before any intervention."
    }),
    xray: buildRecord({
      success: "90%",
      duration: "5-10 min",
      steps: [
        "TSD: show sensor/film on parent finger first",
        "Place lead apron and thyroid collar before exposure",
        "Use child-sized XCP holder or bite-block",
        "Start with bite-wing before periapical",
        "Positive reinforcement after each film",
        "Defer non-urgent views if child refuses — document in notes"
      ],
      drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
      parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
      parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
      clinicalFlags: [
        "Confirm lead apron and thyroid collar placed before exposure",
        "Use paediatric kVp/mA settings",
        "Document films attempted vs completed",
        "If refused: note in record, reattempt next visit",
        "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
      ],
      flagActions: ["defer_if_refused","document_refusal","reassure_parent_radiation_safe"]
    }),
    },
    negative: {
      exam: buildRecord({
        success: "92%",
        duration: "10–15 min",
        durationTip: "Keep under 10 min active clinical time. Infant fatigue = collapse.",
        protocol: "Knee-to-Knee Lap Examination (Marwah Ch.12)",
        stratTitle: "Gentle Knee-to-Knee with Reassuring Parent Presence",
        stratDesc: "Frankl 2 infants are fearful but not actively resisting. Position knee-to-knee with parent holding infant's hands gently over the abdomen. Maintain soft, continuous vocal tone throughout. Use finger only for initial exam — no instruments until trust is established. Limit to 90 seconds of active oral assessment. Provide immediate tactile reassurance (pat on cheek, verbal praise) after each micro-step.",
        cultural: "Indian mothers may anticipate distress and transmit this anxiety non-verbally to the infant. Brief the mother beforehand: 'Aap muskurate rahein — baby apko dekh ke samjhega ki sab theek hai.' A calm mother is your most powerful tool for Frankl 2 infants.",
        techniques: ["Knee-to-Knee Positioning","Non-Verbal Communication","Soft Voice Modulation","Positive Reinforcement","Maternal Calm Facilitation"],
        checklist: [
          "Set up knee-to-knee before patient entry — no adjustments with infant present",
          "Brief mother to smile and avoid anxious facial expression",
          "Use index finger only for initial exam — no metal instruments initially",
          "Have sticker/colourful toy as immediate post-exam reward"
        ],
        escalation: [
          { title: "Step 1: Finger-Only Exam", desc: "Complete full exam using only index finger palpation if instruments cause distress." },
          { title: "Step 2: Defer Detailed Assessment", desc: "If infant becomes Frankl 1 mid-exam, record what you can and schedule brief follow-up." },
          { title: "Step 3: GA if Treatment Required", desc: "Any invasive treatment beyond SDF in infants requires GA at accredited centre." }
        ],
        drugs: [{ name: "Topical LA gel 2%", dose: "Topical only", note: "For natal/neonatal tooth extraction only if required." }],
        drugNote: "No oral sedation for infants <18 months in outpatient settings. GA is the appropriate escalation.",
        scriptEn: "Mrs. [Name], we'll do a quick tooth-counting check — your baby stays right in our laps the whole time. Please hold both little hands gently on the tummy and keep smiling at her/him. We'll be done in under two minutes.",
        scriptHi: "बहनजी, हम बस दाँत जल्दी से देखेंगे — बच्चा आपकी गोद में ही रहेगा। आप दोनों हाथ पेट पर पकड़ें और मुस्कुराते रहें। दो मिनट में हो जाएगा।",
        scriptNote: "*Give the parent a physical task. A mother with a job is calmer than a mother who is merely watching.",
        parentTactics: "Anxious transmitting parent: ask them explicitly to maintain a neutral-to-happy face and avoid hushing the infant preemptively, which signals danger.",
        failures: [
          "Using metal instruments before establishing finger-trust",
          "Parent hushing infant before any distress occurs — preemptive hushing signals threat",
          "Rushing through exam without continuous vocal distraction"
        ],
        flagActions: "ECC risk assessment: assess presence of visible white spot lesions on upper anteriors. Apply 5% NaF varnish with cotton tip, no LA required. Tongue tie: refer to specialist if grade 3–4 Kotlow and feeding difficulty."
    }),
    xray: buildRecord({
      success: "90%",
      duration: "5-10 min",
      steps: [
        "TSD: show sensor/film on parent finger first",
        "Place lead apron and thyroid collar before exposure",
        "Use child-sized XCP holder or bite-block",
        "Start with bite-wing before periapical",
        "Positive reinforcement after each film",
        "Defer non-urgent views if child refuses — document in notes"
      ],
      drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
      parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
      parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
      clinicalFlags: [
        "Confirm lead apron and thyroid collar placed before exposure",
        "Use paediatric kVp/mA settings",
        "Document films attempted vs completed",
        "If refused: note in record, reattempt next visit",
        "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
      ],
      flagActions: ["defer_if_refused","document_refusal","reassure_parent_radiation_safe"]
    })
  }
  },

  // ── TODDLER (1.5–3 years) ────────────────────────────────────────
  toddler: {
    definitely_negative: {
      exam: buildRecord({
        success: "80%",
        duration: "15–20 min",
        durationTip: "Limit active operative time to 8–10 minutes. Pre-cooperative period required.",
        protocol: "Knee-to-Knee + Desensitisation (Marwah Ch.12, 18)",
        stratTitle: "Active Restraint with Distraction — Knee-to-Knee Setup",
        stratDesc: "Toddlers cannot be reasoned with — verbal negotiation is ineffective and wastes clinical time. Position knee-to-knee, parent holds hips and hands. Assistant controls head. Provide non-stop vocal commentary as distraction: 'Look at the light, it's so bright and beautiful! Like a little sun!' Use age-appropriate metaphors: the suction is 'the little elephant's trunk that drinks water.' Keep instruments hidden until moment of use. Complete exam in 90 seconds. Praise immediately and extravagantly after each micro-step.",
        cultural: "Joint family setting: grandmothers frequently intervene verbally ('chhod do, baad mein aayenge!'). Address this proactively — brief the accompanying adult at the door: only one adult in the room, no verbal input unless asked. Indian toddlers are often still breastfed at 2+ years — note this in ECC risk and dietary counselling.",
        techniques: ["Knee-to-Knee Positioning","Physical Restraint (parental)","Non-Verbal Communication","Distraction (auditory/visual)","Immediate Positive Reinforcement"],
        checklist: [
          "Arrange room for knee-to-knee before patient enters",
          "Place stickers/small toys in visible reach as reward anchors",
          "Ask single guardian to accompany — others to wait outside",
          "Prepare restorative materials before patient is seated — no tray lay-up in front of child",
          "Have Molt mouth prop / bite block ready if restoration planned"
        ],
        escalation: [
          { title: "Step 1: Desensitisation Visit", desc: "First visit: exam only. No treatment. Build trust with tactile desensitisation and positive end." },
          { title: "Step 2: Behaviour Shaping", desc: "2nd visit: reinforce correct behaviour with stickers. Attempt simple exam/prophylaxis." },
          { title: "Step 3: Papoose Board (Written Consent)", desc: "Active restraint with paediatric Papoose board for essential treatment. Requires written consent. Brief parent thoroughly before use." },
          { title: "Step 4: Oral Premedication", desc: "Oral Midazolam 0.5 mg/kg (max 15 mg) or Triclofos 50 mg/kg. Monitor vitals. Emergency kit mandatory." },
          { title: "Step 5: GA Referral", desc: "Multiple extractions/pulpectomies in Frankl 1 toddler = GA at accredited hospital. Do not attempt multiple procedures under oral sedation alone." }
        ],
        drugs: [
          { name: "Midazolam oral", dose: "0.5 mg/kg (max 15mg)", note: "30–45 min before procedure. Monitor O₂ sat." },
          { name: "Triclofos sodium", dose: "50 mg/kg oral", note: "Slower onset (45–60 min). Milder sedation. Common first-line in India." },
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Max 1.8 mL cartridge typically for toddlers under 15 kg." }
        ],
        drugNote: "Shobha Tandon (3rd Ed.): Triclofos is frequently used in Indian setting due to cost and availability. Midazolam gives more reliable sedation but requires monitoring equipment. N₂O-O₂ is ideal but infrastructure often lacking in private clinics.",
        scriptEn: "[Child's name], we're going to count your teeth today! Look at this big bright light — can you count how many? [To parent]: Please hold both hands gently but firmly on the tummy. We'll be done in two minutes. If she cries, that's perfectly okay — just hold the hands steady.",
        scriptHi: "[बच्चे के नाम], आज हम तुम्हारे दाँत गिनेंगे! देखो यह कितनी बड़ी रोशनी है! [माँ से]: आप इनके दोनों हाथ पेट पर ऐसे पकड़ लें। दो मिनट में हो जाएगा। रोएं तो घबराएं नहीं।",
        scriptNote: "*Goal: Give parent a task. Use a time anchor. Normalise crying.",
        parentTactics: "For anxious transmitting parents: ask them to maintain a neutral, smiling expression — avoid 'beta dard nahi hoga' which signals anticipation of pain. For joint-family context: designate ONE family member as 'captain' — their job is to brief others outside and maintain quiet.",
        failures: [
          "Explaining procedures verbally to a 2-year-old — they cannot process abstract reassurance",
          "Working without a bite block — risk of finger injury and incomplete treatment",
          "Stopping mid-procedure during crying (if safe to continue, continue with steady voice)",
          "Allowing grandmother/extra adults in the operatory",
          "Showing the extraction forceps or LA syringe to the child at any point"
        ],
        flagActions: "Severe ECC (Type III): SDF 38% application is first-line in cooperative-failure toddlers — no LA, no drilling, high arrest rate (81% Marwah). Apply to all carious surfaces, isolate with cotton, dry, apply 2 drops, wait 60 sec. Warn parents re: tooth staining. Document in records."
      }),
      restoration: buildRecord({
        success: "55%",
        duration: "25–35 min",
        durationTip: "Plan for max 2 surfaces in one sitting. Toddler fatigue hits at 15 min operative time.",
        protocol: "Physical Stabilisation + TSD + Immediate Reinforcement",
        stratTitle: "Stabilisation, Bite Block, Micro-Step Restorations",
        stratDesc: "Never attempt restoration in a definitely-negative toddler without prior desensitisation visit. If proceeding (urgent decay/pain), use parenteral LA (topical first, then slow infiltration), deploy Molt mouth prop immediately after mouth opens to prevent biting. Use GIC (glass ionomer) wherever possible — faster than composite, requires less isolation, acid-etch tolerated without rubber dam in emergency. Praise extravagantly between every 20-second work segment.",
        cultural: "Parents often expect treatment to be completed in one visit regardless of behavior — set realistic expectations pre-treatment: 'Aaj hum sirf ek chota sa kaam karenge, poori taiyaari next visit ke liye.' This manages expectations and reduces mid-chair pressure from parents.",
        techniques: ["Tell-Show-Do","Physical Stabilisation (parental)","Mouth Prop (Molt)","GIC Preference (fast set)","Positive Reinforcement","Voice Control"],
        checklist: [
          "Prepare GIC (RMGIC preferred) before child is seated",
          "Topical LA for 90 seconds on dry mucosa before injection",
          "Have Molt mouth prop (size appropriate) immediately ready",
          "Keep rubber dam as option — deploy only if child tolerates",
          "Have sticker reward visible throughout procedure"
        ],
        escalation: [
          { title: "Step 1: GIC Interim Restoration (ART)", desc: "Hand excavation + GIC — no drilling if tolerated. Interim tx, review in 3 months." },
          { title: "Step 2: SDF + Interim Filling", desc: "SDF arrest + Resin Modified GIC over top. Buys 6–12 months while desensitisation continues." },
          { title: "Step 3: Sedation-Assisted Restoration", desc: "Oral midazolam or triclofos + LA + rubber dam. Plan multiple surfaces in same visit." },
          { title: "Step 4: GA", desc: "Multiple surfaces + definitely negative + failure of sedation = GA referral." }
        ],
        drugs: [
          { name: "Midazolam oral", dose: "0.5 mg/kg (max 15mg)", note: "Gold standard for toddler sedation. Requires monitoring." },
          { name: "Triclofos sodium", dose: "50 mg/kg oral", note: "Widely available in India. 45–60 min onset." },
          { name: "Lignocaine 2% + Adr 1:80,000", dose: "4.4 mg/kg", note: "Slow infiltration. Always aspirate." }
        ],
        drugNote: "India context: N₂O-O₂ (Entonox) is available in large dental colleges and hospital-based practices but rarely in private clinics. If available, N₂O is preferred over oral sedation for toddler restorations — faster offset, safer profile.",
        scriptEn: "[Child's name], we're going to use our magic water brush to clean your tooth — it tickles a little! [After each step] Waah! You are SO brave! [To parent]: Keep holding the hands firmly — we're making wonderful progress.",
        scriptHi: "[नाम], हम अपने जादू वाले पानी के ब्रश से तुम्हारे दाँत साफ करेंगे — थोड़ा सा गुदगुदी होगी! [बाद में]: वाह! तुम बहुत बहादुर हो! [माँ से]: हाथ पकड़े रहें — बहुत अच्छा जा रहा है।",
        scriptNote: "*Never stop the positive narration. Voice modulation (soft, continuous, upbeat) is your most powerful tool for a toddler.",
        parentTactics: "For overprotective parents: assign them the specific task of 'holding hands on tummy' — gives them agency. If parent is crying themselves, ask assistant to take the parent aside briefly while you continue with a calm face.",
        failures: [
          "Working without a mouth prop in a toddler restoration",
          "Attempting composite (long procedure, multiple steps) over GIC in a Frankl 1 toddler",
          "Attempting 3+ surfaces in a single unplanned visit",
          "Allowing parent to say 'beta dard nahi hoga' — introduces fear expectation",
          "Stopping drill mid-preparation during a cry — increases subsequent anxiety"
        ],
        flagActions: "Severe ECC: prioritise anterior aesthetics last — address painful/abscessed teeth first (pulpectomy or extraction). For asthmatic children: avoid rubber dam if triggering anxiety, use cotton roll isolation + high volume suction. Lignocaine plain (no adrenaline) is safe for asthmatics."
    }),
    xray: buildRecord({
      success: "90%",
      duration: "5-10 min",
      steps: [
        "TSD: show sensor/film on parent finger first",
        "Place lead apron and thyroid collar before exposure",
        "Use child-sized XCP holder or bite-block",
        "Start with bite-wing before periapical",
        "Positive reinforcement after each film",
        "Defer non-urgent views if child refuses — document in notes"
      ],
      drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
      parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
      parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
      clinicalFlags: [
        "Confirm lead apron and thyroid collar placed before exposure",
        "Use paediatric kVp/mA settings",
        "Document films attempted vs completed",
        "If refused: note in record, reattempt next visit",
        "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
      ],
      flagActions: ["defer_if_refused","document_refusal","reassure_parent_radiation_safe"]
    })
  },
    negative: {
      exam: buildRecord({
        success: "88%",
        techniques: ["Tell-Show-Do","Desensitisation","Positive Reinforcement","Distraction","Parent-Facilitated Comfort"],
        checklist: [
          "Show instruments on examiner's hand first before approaching child",
          "Keep overhead light away from face initially — ask child to 'count the bulbs'",
          "Have stickers/reward prominently visible",
          "Begin with counting fingers, then teeth, using finger only"
        ],
        escalation: [
          { title: "Step 1: Peer Modelling", desc: "If sibling or cousin is cooperative, let anxious toddler watch their exam first." },
          { title: "Step 2: Distraction Tech", desc: "Tablet with favourite cartoon on ceiling/held by assistant. Audio headphones with preferred rhyme." },
          { title: "Step 3: Positive Behaviour Shaping", desc: "Schedule 3–4 desensitisation visits before any operative work." }
        ],
        drugs: [],
        drugNote: "No pharmacological intervention for Frankl 2 toddler at exam stage. Desensitisation is always first line.",
        scriptEn: "[Child's name], shall we play a counting game? I'm going to count how many teeth you have — I bet you have lots! Can you open wide like a big lion? ROAAAR! [To parent]: Just hold one hand and smile at her/him. No need to say anything — just your smile is enough.",
        scriptHi: "[नाम], क्या हम दाँत गिनने का खेल खेलें? एक बड़े शेर की तरह मुँह खोलो — रोआर! [माँ से]: बस एक हाथ पकड़ें और मुस्कुराते रहें — आपकी मुस्कान ही काफी है।",
        scriptNote: "*Use roar/lion metaphor — wide mouth, no negative connotation.",
        parentTactics: "For anxious transmitting parents: ask them explicitly to not use words, just smile and make eye contact with the child. Their emotional state is directly transmitted. A calm parent smile is worth more than 10 verbal reassurances.",
        failures: [
          "Opening mouth with fingers before establishing trust",
          "Using sharp instruments (explorer) before mirror",
          "Asking open-ended questions like 'Are you scared?' — confirms fear",
          "Rushing the exam before rapport is established"
        ],
        flagActions: "Gag reflex: apply topical LA to posterior soft palate. Distraction (pressing a point on back of hand) can reduce gag. Start with anterior teeth only on first visit."
    }),
    xray: buildRecord({
      success: "90%",
      duration: "5-10 min",
      steps: [
        "TSD: show sensor/film on parent finger first",
        "Place lead apron and thyroid collar before exposure",
        "Use child-sized XCP holder or bite-block",
        "Start with bite-wing before periapical",
        "Positive reinforcement after each film",
        "Defer non-urgent views if child refuses — document in notes"
      ],
      drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
      parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
      parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
      clinicalFlags: [
        "Confirm lead apron and thyroid collar placed before exposure",
        "Use paediatric kVp/mA settings",
        "Document films attempted vs completed",
        "If refused: note in record, reattempt next visit",
        "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
      ],
      flagActions: ["defer_if_refused","document_refusal","reassure_parent_radiation_safe"]
    })
  },
    positive: {
      restoration: buildRecord({
        success: "82%",
        duration: "20–25 min",
        durationTip: "Toddler fatigue still applies — limit operative time to 12 min. Cooperativeness can drop without warning.",
        protocol: "TSD + Positive Reinforcement + Mouth Prop",
        stratTitle: "Sustained TSD with Constant Praise Loop",
        stratDesc: "A Frankl 3 toddler is a clinical opportunity — but do not take it for granted. Maintain the TSD narrative throughout and keep praise specific and frequent: 'You kept so still for Mr. Water Toothbrush!' Use GIC as primary material — faster set, less technique sensitive. Deploy Molt mouth prop as standard — toddlers cannot maintain mouth opening reliably even when willing. Finish faster than the child expects and end on an extravagant high.",
        cultural: "A cooperative toddler in India often signals a well-prepared parent. Reinforce this: 'Aapne ghar pe bahut acchi taiyaari karyi — yeh hamare kaam ko bahut asaan banata hai.' This cements the parent as an ally and ensures cooperation at future visits.",
        techniques: ["TSD","Positive Reinforcement","Mouth Prop (Molt)","GIC Material Preference","Parent Acknowledgement"],
        checklist: [
          "Prepare GIC before patient is seated — no mix-in front of child",
          "Topical LA 90 sec + slow infiltration as standard",
          "Deploy Molt mouth prop after LA — do not rely on cooperative child to hold open",
          "Sticker reward visible throughout as motivator"
        ],
        escalation: [
          { title: "Step 1: Reinforce Existing Cooperation", desc: "Explicit verbal praise for each completed micro-step sustains cooperation." },
          { title: "Step 2: Mouth Prop", desc: "If fatigue drops jaw position, use Molt prop to secure working field." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard. Max 1 cartridge for toddlers <15 kg." }
        ],
        drugNote: "No pharmacological sedation needed for Frankl 3 toddler restoration. Standard LA is sufficient.",
        scriptEn: "[Name], you are SO good at this! We're going to clean one little tooth today with our water toothbrush. First the magic sleepy drops — just a tiny tickle! Then clean, clean, clean, and we're DONE! And then you get a sticker! Ready? Open like a lion — ROAR! Brilliant!",
        scriptHi: "[नाम], तुम तो बहुत अच्छे हो इसमें! आज हम एक छोटे दाँत को water toothbrush से साफ करेंगे। पहले magic sleepy drops — बस थोड़ी सी गुदगुदी! फिर साफ, साफ, साफ — और sticker! तैयार? शेर की तरह मुँह खोलो — दहाड़!",
        scriptNote: "*Name the reward (sticker) explicitly and tie it to completion. Toddlers respond to concrete, predictable outcomes.",
        parentTactics: "For cooperative parents: give them a small script — 'When I nod at you, say [child's name], you are SO brave!' Make them an active reinforcer, not a passive observer.",
        failures: [
          "Not using a mouth prop — cooperative toddlers still close on instruments unpredictably",
          "Over-length session — fatigue can convert Frankl 3 to Frankl 1 in under 5 minutes",
          "Skipping topical LA — even cooperative children have painful memories if injection hurts"
        ],
        flagActions: "Severe ECC in Frankl 3 toddler: take advantage of cooperativeness — complete as much as possible, prioritising most symptomatic teeth. GIC restorations are preferable over composite for speed."
    }),
    xray: buildRecord({
      success: "90%",
      duration: "5-10 min",
      steps: [
        "TSD: show sensor/film on parent finger first",
        "Place lead apron and thyroid collar before exposure",
        "Use child-sized XCP holder or bite-block",
        "Start with bite-wing before periapical",
        "Positive reinforcement after each film",
        "Defer non-urgent views if child refuses — document in notes"
      ],
      drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
      parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
      parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
      clinicalFlags: [
        "Confirm lead apron and thyroid collar placed before exposure",
        "Use paediatric kVp/mA settings",
        "Document films attempted vs completed",
        "If refused: note in record, reattempt next visit",
        "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
      ],
      flagActions: ["defer_if_refused","document_refusal","reassure_parent_radiation_safe"]
    })
  },
    definitely_positive: {
      restoration: buildRecord({
        success: "95%",
        duration: "20–25 min",
        durationTip: "Efficient session possible. However — toddler fatigue is not eliminated by cooperativeness. Keep under 20 min.",
        protocol: "Standard TSD + Full LA + GIC/Composite",
        stratTitle: "Efficient Evidence-Based Care with Reinforcement Maintenance",
        stratDesc: "A Frankl 4 toddler is rare and represents an exceptional opportunity. Maintain the cooperative attitude with consistent positive reinforcement — do not stop praising simply because the child is behaving well. Complete comprehensive assessment and treatment in one sitting if possible. Use rubber dam if feasible (explain as 'tooth raincoat'). Composite is appropriate if isolation is achievable. Reinforce heavily at end: 'You were the best patient I have had all week — I'm going to tell everyone!'",
        cultural: "Parents of Frankl 4 toddlers often have done exceptional preparation — dental-positive books, positive role modelling, previous good experience. Document this and credit the parent explicitly. This parent will reliably produce cooperative children at future visits.",
        techniques: ["TSD","Positive Reinforcement","Rubber Dam (if tolerated)","Composite Restoration","Full Transparency"],
        checklist: [
          "Standard LA protocol — do not rush even on cooperative child",
          "Attempt rubber dam — explain as tooth raincoat",
          "Complete comprehensive charting and radiographs if clinically needed",
          "Reinforce extravagantly at end — give best reward in the box"
        ],
        escalation: [{ title: "Step 1: Sustain Rapport", desc: "Maintain TSD narrative. Do not drop engagement just because child is cooperative." }],
        drugs: [{ name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard." }],
        drugNote: "No sedation required for Frankl 4 toddler. Standard LA.",
        scriptEn: "You are absolutely brilliant — you are going to make this so easy! We're cleaning your teeth today, step by step, and I'll tell you everything we do. Sleepy drops first — tiny tickle! Then all sorted. At the end you get first pick from the prize box — you've earned it!",
        scriptHi: "[नाम], तुम बिल्कुल amazing हो! आज हम दाँत ठीक करेंगे — सब कुछ बताता/बताती हूँ। Magic sleepy drops — छोटी सी tickle! फिर सब ठीक। अंत में prize box में से पहले तुम choose करोगे — तुमने deserve किया है!",
        scriptNote: "*Definitely Positive children are energised by feeling special and capable. 'First pick from the box' is a powerful intrinsic motivator.",
        parentTactics: "Cooperative parent: brief them to maintain their positive approach at home — no casual 'dentist' threats, no dramatic pre-visit buildup, just matter-of-fact normalisation.",
        failures: [
          "Abandoning TSD mid-procedure — complacency breaks rapport even in Frankl 4",
          "Not completing available treatment — this window may not repeat",
          "Failing to document what techniques worked for next visit's clinician"
        ],
        flagActions: "Routine case with cooperative child — standard clinical protocols apply. If any medical flags present, apply relevant protocol modifications."
    }),
    xray: buildRecord({
      success: "90%",
      duration: "5-10 min",
      steps: [
        "TSD: show sensor/film on parent finger first",
        "Place lead apron and thyroid collar before exposure",
        "Use child-sized XCP holder or bite-block",
        "Start with bite-wing before periapical",
        "Positive reinforcement after each film",
        "Defer non-urgent views if child refuses — document in notes"
      ],
      drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
      parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
      parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
      clinicalFlags: [
        "Confirm lead apron and thyroid collar placed before exposure",
        "Use paediatric kVp/mA settings",
        "Document films attempted vs completed",
        "If refused: note in record, reattempt next visit",
        "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
      ],
      flagActions: ["defer_if_refused","document_refusal","reassure_parent_radiation_safe"]
    })
  }
  },

  // ── PRESCHOOL (3–6 years) ────────────────────────────────────────
  preschool: {
    definitely_negative: {
      restoration: buildRecord({
        success: "65%",
        duration: "30–40 min",
        durationTip: "Operative time max 20 min. Preschooler attention fatigue after 15 min in chair.",
        protocol: "Voice Control + TSD + Physical Stabilisation if needed",
        stratTitle: "Directive TSD with Firm Voice Control",
        stratDesc: "Preschoolers at this stage have receptive language. Use this. Frame every instrument with a child-friendly name: high-speed = 'Mr. Water Toothbrush,' slow-speed = 'Spinny Wind Machine,' LA syringe = 'Sleepy Drops with Magic Pillow,' suction = 'Hungry Mr. Straw.' NEVER ask open-ended permission questions ('Can I start?' 'Is it okay?'). Instead use directive statements: 'Now open big like a lion — good! Now I'm going to put the sleepy pillow — keep opening.' Deploy firm voice control (Wright, Marwah Ch.12): lower pitch, authoritative tone, not harsh. 'Stop. Open. Well done.' Maintain steady narrative throughout.",
        cultural: "In joint-family Indian settings, the child may have been told 'dentist will cut/hurt you' as a disciplinary threat by grandparents. Counteract proactively: 'Hamara office ek magic workshop hai — yahan kuch bhi hurt nahi karta.' If child has been bribed with food to cooperate, use this: 'Jab yahan ka kaam ho jata hai, tum apni mummy ke saath ice cream khaoge.'",
        techniques: ["Tell-Show-Do","Voice Control (Wright)","Positive Reinforcement","Distraction","Rubber Dam (tooth raincoat)","Child-Friendly Metaphors"],
        checklist: [
          "Hide LA syringe behind head — prepare in advance",
          "Lay out rubber dam with colourful frame — introduce as 'tooth raincoat'",
          "Cover all metal instruments; introduce only one at a time",
          "Have reward sticker prominently visible on tray",
          "Position assistant at left side to block parent line-of-sight from active instruments"
        ],
        escalation: [
          { title: "Step 1: Contingency Management", desc: "Offer specific, pre-agreed reward for each completed step. Stickers, star chart, toy from 'treasure box.'" },
          { title: "Step 2: Voice Control (Firm)", desc: "If child is testing limits: firm, lower pitch — 'Stop. Look at me. Open.' Not harsh, but authoritative." },
          { title: "Step 3: Distraction Technology", desc: "TV/tablet on ceiling, noise-cancelling headphones with preferred show. Reduces treatment time 30% (Marwah Ch.18)." },
          { title: "Step 4: N₂O-O₂ Anxiolysis", desc: "If available: 30–50% N₂O in O₂. Onset 3–5 min. Child remains conversational. Most appropriate pharmacological step for Frankl 2 preschoolers." },
          { title: "Step 5: Oral Midazolam", desc: "0.5 mg/kg oral, 30 min pre-procedure. Monitor SpO₂ and HR continuously." }
        ],
        drugs: [
          { name: "N₂O-O₂ (Entonox)", dose: "30–50% N₂O", note: "Ideal pharmacological first-line. Titrate to effect." },
          { name: "Midazolam oral", dose: "0.5 mg/kg (max 15mg)", note: "Pre-procedure sedation. Requires monitoring." },
          { name: "Lignocaine 2% + Adr 1:80,000", dose: "4.4 mg/kg", note: "Standard LA. Topical first (90 sec). Slow deposition." },
          { name: "Benzocaine topical 20%", dose: "60–90 sec dry mucosa", note: "Pre-injection. Never inject." }
        ],
        drugNote: "India context (Shobha Tandon): Topical EMLA (Lignocaine + Prilocaine) is an alternative to benzocaine gel for pre-injection — longer onset (60 min under occlusion) but more effective depth of analgesia for needle-phobic children. Not practical for routine use without prior application.",
        scriptEn: "Okay [name], I'm Dr. [name] and this is my magic workshop! Today we're going to give your tooth a special shield — it's called a filling. First let me show you my tools — this is Mr. Water Toothbrush [demonstrate on their finger]. Good! Now open big like a lion — ROAR! Perfect. I'm going to put some magic sleepy drops that make the tooth go to sleep for a bit. You'll feel a little tickle. Keep still and keep opening — brilliant!",
        scriptHi: "[नाम], मैं Dr. [नाम] हूँ और यह मेरी magic workshop है! आज हम तुम्हारे दाँत को एक special shield देंगे। पहले देखो यह Mr. Water Toothbrush — [हाथ पर दिखाएँ]। अब शेर की तरह मुँह खोलो — दहाड़! बहुत बढ़िया! अब मैं कुछ magic sleepy drops डालूँगा जो दाँत को सुला देंगे। थोड़ी सी गुदगुदी होगी — बिल्कुल हिलना मत।",
        scriptNote: "*Directive, not requesting. Never ask 'Can I?' — always tell 'Now I will.' This is the single biggest technique shift for Frankl 1–2 preschoolers.",
        parentTactics: "For overprotective mother: 'Aap bahut achhi mummy hain — aaj apka kaam hai Riya ka haath pakad ke rakhna aur muskurate rehna. Aap mujh par trust karein.' This gives her a task and delegates clinical authority to you. For educated-demanding parent: give them the clinical rationale briefly ('GIC is faster, requires less isolation, equally durable in primary teeth') before they ask.",
        failures: [
          "Saying 'this won't hurt' — immediate trust breach when it does",
          "Asking 'are you scared?' or 'does it hurt?' mid-procedure unnecessarily",
          "Showing LA syringe before injection — any metallic glint causes immediate fear response",
          "Allowing parent to answer on child's behalf when you ask the child a question",
          "Using negative language: 'don't cry,' 'don't move,' 'it's nothing' — all fail",
          "Attempting composite multi-step procedure in Frankl 1 preschooler — use GIC"
        ],
        flagActions: "ECC severe: prioritise symptomatic teeth. For a child with rampant caries + Frankl 1 + preschool age — the most time-efficient, evidence-based plan is: (1) SDF all surfaces this visit with counselling, (2) schedule sedation-assisted comprehensive Tx, (3) preventive counselling for parents. Asthma: use lignocaine plain for LA, avoid rubber dam triggers, have Salbutamol MDI in emergency kit."
      }),
      exam: buildRecord({
        success: "78%",
        duration: "20–25 min",
        durationTip: "Allow 5 min rapport building. Don't rush opening. Exam itself: 5–8 min.",
        protocol: "TSD + Distraction + Rapport Building",
        stratTitle: "TSD with Hand Demonstration & Rapport Anchoring",
        stratDesc: "Begin every examination with a demonstration on the examiner's own hand or back of child's hand. Instruments become friendly characters. 'This is Mr. Mirror — he shows faces! Can you see your smile?' Allow child to touch each instrument. Use air-water syringe on their palm: 'Cool wind and water — feel it!' Once trust is built on hands, transition to the mouth. Keep exam rapid once you gain access.",
        cultural: "Urban Indian preschoolers (especially from Tier-1/2 cities) increasingly arrive with YouTube-based dental fear from cartoon 'scary dentist' videos. Ask directly: 'Did you watch any video about dentist? What happened in it?' Counter with direct narrative reframe.",
        techniques: ["TSD","Hand Demonstration","Distraction","Positive Reinforcement","Hand Mirror (perceived control)"],
        checklist: [
          "Show mirror, probe blunt end, air-water on examiner's hand before approaching child",
          "Invite child to hold a hand mirror — they can 'help' count teeth",
          "Begin with counting incisors (least threatening) before molars",
          "Do radiograph only if clinically essential — defer to second visit if child is Frankl 1–2"
        ],
        escalation: [
          { title: "Step 1: Distraction Tech", desc: "Tablet with favourite show. Reduces exam anxiety immediately." },
          { title: "Step 2: Defer to Second Visit", desc: "If Frankl 1 — complete radiographs and detailed charting at visit 2 after desensitisation." }
        ],
        drugs: [],
        drugNote: "No pharmacological intervention for preschool exam. NP techniques should be fully exhausted first.",
        scriptEn: "[Name], today we're going to be tooth detectives! Look — this is Mr. Mirror. He shows funny faces [hold mirror to child's face]. Can you make a funny face for him? Now open wide and we'll count your teeth — 1, 2, 3... wow! You have so many! You're doing SO well.",
        scriptHi: "[नाम], आज हम 'दाँत जासूस' बनेंगे! देखो यह Mr. Mirror है — वो funny faces दिखाता है। अब शेर की तरह मुँह खोलो और हम दाँत गिनेंगे — 1, 2, 3... वाह! इतने सारे! तुम बहुत अच्छे हो।",
        scriptNote: "*Framing the exam as a game/detective mission gives agency and removes clinical threat perception.",
        parentTactics: "Brief all parents before child enters: 'Please do not use the word 'injection', 'dard', 'daant,' or 'cut' in the clinic. If child asks, say 'the doctor will tell you.' This is important for the outcome of today's visit.'",
        failures: [
          "Attempting radiographs in the same visit as a first exam on a Frankl 1–2 child",
          "Parent using the word 'injection' or 'dard' in earshot of child",
          "Probing aggressively at first visit — builds sharp instrument fear",
          "Proceeding without rapport phase — 'quick look' exams train avoidance"
        ],
        flagActions: "Gag reflex at exam: apply topical LA to soft palate. Have child press acupressure point on back of hand (between thumb and index). Start with anterior teeth. Acclimate slowly."
      }),
      pulpectomy: buildRecord({
        success: "60%",
        duration: "45–55 min",
        durationTip: "Highest time pressure procedure. Plan across 2 visits if child Frankl 1–2. LA onset essential before access.",
        protocol: "LA + Rubber Dam + Incremental Disclosure + Voice Control",
        stratTitle: "Multi-Visit Pulpectomy with LA Masking & Non-Verbal Management",
        stratDesc: "Pulpectomy in a preschooler requires perfect LA before access — an inadequate block is the single most common cause of behaviour failure. Use 2% lignocaine + adrenaline 1:80,000, topical first 90 sec, slow deposition (1 mL/min). Never mention the word 'injection' — 'sleepy drops' or 'magic medicine.' Deploy rubber dam immediately after LA — do not explain each step, maintain continuous narrative distraction. Canals in primary teeth: straight files, no WL (radiograph at separate visit), obturate with ZOE/KRI paste. Use absorbent points generously.",
        cultural: "Parents of preschoolers with pulp involvement often feel guilty (poor oral hygiene, prolonged feeding). Do not amplify guilt. Say: 'Ab hum is dant ko theek kar denge — yeh hota hai, aur hum iska perfect solution kar denge.' This is a practical cultural management technique to maintain parent cooperation throughout a long procedure.",
        techniques: ["LA Masking (TSD for injection)","Rubber Dam Mandatory","Voice Control","Incremental Disclosure","Continuous Narrative Distraction"],
        checklist: [
          "Topical LA (benzocaine/lignocaine gel) on dry mucosa for 90 sec before injection",
          "Keep syringe concealed — prepare outside, pass behind patient head",
          "Rubber dam clamp: apply with LA in place, use butterfly clamp for molars",
          "Have pre-measured ZOE paste ready before access",
          "Keep assistant on left side managing parent + suction simultaneously"
        ],
        escalation: [
          { title: "Step 1: 2-Visit Protocol", desc: "Visit 1: Access + pulp extirpation + canal measurement + dressing (Ca(OH)₂ or CresopheneFC). Visit 2: Obturation. Behaviour is usually better on visit 2." },
          { title: "Step 2: N₂O-O₂", desc: "30–50% N₂O-O₂ during procedure if available. Dramatically reduces movement and anxiety." },
          { title: "Step 3: Oral Sedation", desc: "Midazolam 0.5 mg/kg + LA for single-visit comprehensive plan under monitoring." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr 1:80,000", dose: "4.4 mg/kg", note: "Infiltration for maxilla. Inferior alveolar block for mandibular molars." },
          { name: "Benzocaine gel 20%", dose: "Topical, 90 sec", note: "Pre-injection. Mandatory." },
          { name: "ZOE paste (obturating)", dose: "Canal-length calibrated", note: "Do not overfill beyond apex. Risk of succedaneous tooth damage." },
          { name: "Midazolam oral (if sedation)", dose: "0.5 mg/kg max 15mg", note: "Pre-procedure. SpO₂ monitoring mandatory." }
        ],
        drugNote: "KRI paste (iodoform + Ca(OH)₂) is now the preferred obturating material in Indian dental colleges per Marwah 5th Ed. — better antimicrobial, resorbs with root. ZOE is still widely used in practice but inferior in resorption kinetics.",
        scriptEn: "We're going to give your tooth a little holiday — some magic sleepy drops first so it goes to sleep, then we fix it nicely. You won't feel a thing once the tooth is sleeping. I'll tell you a story while we work. [During procedure] You're being SO brave — I've never seen anyone this brave. What's your favourite cartoon? [Distract continuously.]",
        scriptHi: "हम तुम्हारे दाँत को एक छोटी holiday देंगे — पहले magic sleepy drops ताकि वो सो जाए, फिर हम उसे ठीक कर देंगे। [काम के दौरान] तुम बहुत बहादुर हो — अच्छा बताओ, तुम्हारा favourite cartoon कौनसा है?",
        scriptNote: "*Distraction during procedure is non-negotiable. Silence amplifies every sound and sensation. Keep talking.",
        parentTactics: "Give the parent a specific task before you start: 'Your job today is to hold their left hand and look at their face with a calm smile. Don't look at what I'm doing — just watch their face. If they look at you, you smile and say 'you're doing great.' Nothing else.' This prevents unsolicited verbal interference.",
        failures: [
          "Proceeding to access without adequate LA — most common cause of Frankl 1 after pulpectomy",
          "Mentioning the word 'injection,' 'drilling,' or 'nerve'",
          "Working without rubber dam — aspiration risk + poor isolation + behavioural deterioration",
          "Overfilling ZOE past apex — damage to permanent successor + painful",
          "Attempting single-visit pulpectomy in a distressed Frankl 1 without sedation"
        ],
        flagActions: "Asthma: LA plain (no adrenaline). Thalassaemia: check Hb before elective procedure; if <10 g/dL, defer. Sickle cell: avoid tourniquet/rubber band — no clinical significance for dental chair but note for future reference. Special needs/ASD: dimmer lights, reduce instrument sounds, allow child to hold a familiar object from home."
      }),
      extraction: buildRecord({
        success: "70%",
        duration: "20–30 min",
        durationTip: "Most stressful procedure for child AND parent. Set pre-procedure expectations firmly.",
        protocol: "LA Masking + Closed Technique + Parental Script",
        stratTitle: "Closed Extraction Technique with Full LA Protocol",
        stratDesc: "Extraction ranks highest in anxiety-inducing procedures across Indian child populations (JISPPD study, Ghaziabad 2022). Mandatory full LA protocol: topical 90 sec → slow infiltration → test before proceeding. Wait minimum 5 min post-injection for full effect. Do NOT let child know extraction is happening until final moment — 'I'm going to wiggle this sleepy tooth loose — it already wants to come out!' Luxation before delivery should be done gently with wrist motion. Deliver in under 10 seconds of active force. Have gauze ready immediately — place in socket and instruct biting before child processes what happened. Praise extravagantly. 'You just helped your tooth go to the Tooth Fairy! It was ready to leave!'",
        cultural: "The Indian concept of the Tooth Fairy is not universal — in North India, the ritual is throwing the tooth on the roof and saying 'chuhiya le jaa, sona wala dant de jaa.' Use this: 'Yeh dant chuhiya ke paas jaega aur woh tumhe naya golden dant degi!' This is culturally resonant and reduces post-extraction distress.",
        techniques: ["Full LA Protocol","Closed Extraction Technique","Narrative Masking","Immediate Post-Extraction Distraction","Cultural Framing (Tooth Mouse/Chuhiya)"],
        checklist: [
          "Full LA — topical 90s → infiltration → palatal/lingual supplemental → test",
          "Luxate fully before delivery — never force without luxation",
          "Have gauze cut and ready before delivery",
          "Post-extraction: place gauze, immediate praise, reveal reward sticker",
          "Brief parent pre-procedure: 'Some bleeding is normal and safe — please stay calm'",
          "Give written post-operative instructions in Hindi/local language"
        ],
        escalation: [
          { title: "Step 1: Topical + Slow LA + Test", desc: "Never proceed to extraction without confirmed anaesthesia. Test with blunt instrument." },
          { title: "Step 2: Supplemental LA", desc: "For mandibular: lingual infiltration + buccal long buccal. For maxilla: palatal infiltration mandatory." },
          { title: "Step 3: Intraligamentary LA", desc: "High success in resistant cases. Use 30G short needle. Painful if not done correctly — require co-operative child." },
          { title: "Step 4: Sedation", desc: "For multi-extraction Frankl 1 preschooler: oral midazolam or GA referral." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr 1:80,000", dose: "4.4 mg/kg", note: "Standard. Full block required." },
          { name: "Benzocaine 20% topical", dose: "90 sec pre-injection", note: "Mandatory." },
          { name: "Ibuprofen (post-op)", dose: "5–10 mg/kg 6 hrly x 2 days", note: "Safe in children >6 mo. Preferred over paracetamol for dental pain." },
          { name: "Paracetamol (alternative)", dose: "10–15 mg/kg 6 hrly", note: "If NSAID contraindicated (asthma, allergy)." }
        ],
        drugNote: "Post-op instruction in India: many parents attempt to apply home remedies (haldi, clove oil, hing) on the socket. Advise them specifically: no home paste, no spitting, no hot food for 24 hours. Provide written Hindi instructions.",
        scriptEn: "Your tooth is already getting sleepy! Can you feel it? [test] Perfect, it's fully asleep. Now I'm going to wiggle it gently — this tooth has been wanting to go on a holiday. Keep still and open... [deliver] All done! You were incredible! Now this sleepy tooth is going to the chuhiya — and she'll send you a shiny new one! [give reward sticker immediately]",
        scriptHi: "तुम्हारा दाँत तो सो गया है! [check LA] बिल्कुल सो गया। अब मैं इसे धीरे से हिलाऊँगा — यह दाँत तो holiday जाना चाहता था। बिल्कुल हिलना मत... [निकालें] हो गया! तुम बहुत बहादुर हो! यह दाँत अब चुहिया के पास जाएगा और वो तुम्हें नया दाँत भेजेगी! [तुरंत sticker दें]",
        scriptNote: "*Speed of delivery once fully anaesthetised = less anticipation anxiety. The longer you pause, the more fear escalates.",
        parentTactics: "Pre-brief parent: 'Some blood is completely normal — please stay calm and do not gasp or say 'koon aa gaya' in front of your child. Your calm reaction is everything.' Give them the post-op gauze to hold for the child — gives them agency during the most stressful moment.",
        failures: [
          "Proceeding without confirmed LA — extraction pain is traumatising and creates Frankl 1 for life",
          "Telling child in advance that tooth is coming out — maximises anticipation anxiety",
          "Parent gasping at blood — immediate escalation of child distress",
          "Leaving child uninstructed with loose gauze — they spit it out, bleed, panic",
          "No post-op written instructions — increases callback and parent distress"
        ],
        flagActions: "Sickle cell / Thalassaemia: check recent Hb, liaise with paediatrician, minimal trauma technique, post-op haemostasis essential. ASD/special needs: social story before appointment ('first we wait, then chair, then doctor counts teeth, then done'), sensory preparation, dim lights, no sudden movements."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    },
    negative: {
      restoration: buildRecord({
        success: "82%",
        duration: "30–35 min",
        durationTip: "20 min operative time target. First 10 min rapport + LA → 20 min work window.",
        protocol: "TSD + N₂O Option + Positive Reinforcement",
        stratTitle: "Tell-Show-Do with Metaphor Language & Incremental Trust",
        stratDesc: "Frankl 2 preschoolers have anxiety but respond to patient TSD. Never skip the demonstration phase. Use the instrument on back of hand first. High-speed = 'Mr. Wind Toothbrush.' Air-water = 'Water pistol.' Suction = 'Juice straw.' LA = 'Magic sleep drops — like in Doraemon!' Keep a running cheerful narrative throughout. Praise every 20 seconds: 'Brilliant! You're the bravest patient I've seen today!' Use contingency rewards: 'When we finish this step, you get to choose a sticker.'",
        cultural: "Doraemon, Chhota Bheem, and Motu-Patlu are universally known cartoon characters across India. Use them: 'This is Doraemon's special machine that cleans teeth — Doraemon uses it on Nobita all the time!' This cultural framing dramatically reduces instrument fear.",
        techniques: ["TSD","Metaphor Language (Doraemon/Chhota Bheem)","Contingency Reinforcement","Voice Modulation","N₂O-O₂ (if available)"],
        checklist: [
          "Demonstrate all instruments on child's hand before mouth",
          "Connect to child's favourite cartoon characters in language",
          "Topical LA 90 sec before injection, keep syringe hidden",
          "Rubber dam as 'tooth raincoat' — show child, let them touch it",
          "Have sticker chart visible — fill a star after each completed step"
        ],
        escalation: [
          { title: "Step 1: Distraction + Star Chart", desc: "Earn stars for each step (open mouth, keep still, rinse). Exchange for prize at end." },
          { title: "Step 2: N₂O-O₂", desc: "If available, 30% N₂O is appropriate and transforms Frankl 2 into cooperative patient within 5 min." },
          { title: "Step 3: Oral Premedication", desc: "For repeat-failure visits: oral midazolam 0.5 mg/kg 30 min pre-procedure." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard." },
          { name: "N₂O-O₂ (if available)", dose: "30% N₂O titration", note: "Most appropriate first pharmacological step." }
        ],
        drugNote: "Practical India note: Most private clinics in India do not have piped N₂O. Portable N₂O units are available (~₹40,000–60,000). For high-volume paediatric practices, the investment pays back in significantly reduced treatment time and chair stress.",
        scriptEn: "Okay [name], today we're going to use Chhota Bheem's special water toothbrush — Bheem uses it every day to keep his teeth super strong! First let me show you on your hand — see, just a tiny tickle of wind and water! Good! Now open like Bheem would — big and brave! [post-step] You just did what Bheem does! That's incredible!",
        scriptHi: "[नाम], आज हम Chhota Bheem के special water toothbrush से तुम्हारे दाँत साफ करेंगे — Bheem रोज़ यही use करता है! पहले अपने हाथ पर देखो — बस हवा और पानी की tickle! अब Bheem की तरह मुँह खोलो — बड़ा और बहादुर! [step के बाद] तुमने वही किया जो Bheem करता है!",
        scriptNote: "*Character identification makes the procedure aspirational rather than threatening.",
        parentTactics: "For cooperative parents: give them a cue word — 'When I look at you and nod, you say 'you're doing so well!' in their language.' This makes praise feel more real. For detached parents: ask them to hold the child's hand and make brief eye contact at key moments — even minimal engagement helps.",
        failures: [
          "Skipping demonstration on hand — going straight to mouth",
          "Using adult clinical language (restoration, caries, preparation)",
          "Giving empty praise ('good boy/girl') — be specific: 'You kept still for the whole water toothbrush step!'",
          "Letting child decide whether to continue mid-procedure — authority must stay with dentist"
        ],
        flagActions: "Gag reflex: apply topical LA to posterior soft palate + distraction (acupressure on back of hand) + headphones with favourite audio. Prefer RMGIC for restorations — less technique sensitive, faster set, acid-etch not needed."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    },
    positive: {
      restoration: buildRecord({
        success: "92%",
        duration: "25–30 min",
        durationTip: "Efficient session possible. Use time well — can complete 2 restorations.",
        protocol: "TSD + Positive Reinforcement + Transparency",
        stratTitle: "Transparent TSD with Age-Appropriate Explanation",
        stratDesc: "Frankl 3 preschoolers are a clinical gift. Maintain the cooperative attitude with consistent positive reinforcement, transparent step-by-step disclosure, and genuine praise. Never assume cooperation will continue without effort — sustain the rapport throughout. Allow questions and answer in simple language. 'Good question! This is the water pillow — it keeps the tooth clean while I work.'",
        cultural: "Indian children who are cooperative often have a parent who prepared them well at home. Acknowledge this directly: 'Aapne bahut achha preparation karaya — iska poora credit aapko hai.' This strengthens parent-dentist alliance and ensures future cooperation.",
        techniques: ["TSD","Positive Reinforcement","Transparency","Contingency Reinforcement"],
        checklist: [
          "Standard LA protocol — no rushing even on cooperative child",
          "Rubber dam deployment — explain as 'tooth raincoat'",
          "Composite or GIC based on clinical need",
          "Praise genuinely and specifically throughout"
        ],
        escalation: [
          { title: "Step 1: Maintain Rapport", desc: "Don't get complacent — keep the TSD narrative active even on cooperative patients." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard." }
        ],
        drugNote: "Cooperative children rarely need pharmacological assistance. N₂O may still be offered for longer procedures to enhance comfort.",
        scriptEn: "You're doing so well — I can tell you've done this before! I'm going to show you each thing as we go. [show rubber dam] This is your tooth's raincoat — keeps everything dry. [post-restoration] Brilliant. You helped me do my best work today!",
        scriptHi: "तुम बहुत अच्छे हो — मैं बता सकता/सकती हूँ कि तुम यह पहले कर चुके हो! [rubber dam दिखाएं] यह तुम्हारे दाँत का raincoat है — ताकि सब कुछ dry रहे। [बाद में] शाबाश! आज तुमने मेरा काम आसान कर दिया!",
        scriptNote: "*Acknowledge the child's competence — preschoolers respond powerfully to being told they are capable.",
        parentTactics: "Cooperative parent: brief them to maintain their supportive approach and give them specific praise ('Jo aap ghaar mein prepare karke laaye, uski wajah se aaj yeh visit itna smooth raha'). This reinforces the behaviour for future visits.",
        failures: [
          "Taking cooperation for granted and abandoning TSD midway",
          "Skipping praise because 'they're already cooperating' — praise sustains cooperation",
          "Working faster than child can process — sudden movements break trust"
        ],
        flagActions: "Routine case — standard clinical caution applies. If any flags present, apply relevant protocol from other sections."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    }
  },

  // ── SCHOOL-AGE (6–9 years) ────────────────────────────────────────
  schoolage: {
    definitely_negative: {
      restoration: buildRecord({
        success: "75%",
        duration: "30–35 min",
        durationTip: "School-age children respond well to authoritative frameworks. No more than 40 min.",
        protocol: "Voice Control + Authoritative Directive + Contingency Management",
        stratTitle: "Firm Directives + Rational Explanation + Contingency Rewards",
        stratDesc: "School-age children understand cause-and-effect. Explain briefly and rationally: 'There's a tiny sugar bug in this tooth. My water toothbrush removes it in 10 minutes, then your tooth is protected forever.' Use counting distraction: 'I'm counting to 10 and then we take a 5-second rest — ready? 1... 2...' Deploy firm, confident voice control without aggression. Address resistance directly: 'You are old enough and smart enough to do this. I know you can. Let's go.' Peer comparison (appropriately used): 'Your classmates come here all the time — it's not a big deal to them anymore.'",
        cultural: "School-age children in India are strongly influenced by peer standing and academic identity. Framing treatment as something 'smart, capable children handle' activates their self-concept. Use their school performance as a parallel: 'Tumne exam mein kitne marks laaye? Yeh exam se bhi asaan hai!'",
        techniques: ["Voice Control (firm)","Rational Brief Explanation","Counting Distraction","Contingency Rewards","Peer Comparison (careful use)"],
        checklist: [
          "Brief patient alone if parent is anxious — ask parent to step outside briefly",
          "Explain procedure in 30 seconds: what, why, how long",
          "Set explicit expectations: 'You will feel nothing after the sleepy drops. Keep still.'",
          "Have clearly visible reward (not a sticker at this age — certificate/star badge works better)"
        ],
        escalation: [
          { title: "Step 1: One-on-One Brief", desc: "Speak to child alone for 60 seconds without parent — this often shifts behaviour dramatically." },
          { title: "Step 2: Structured Countdown", desc: "Formal counting with rest intervals. Child controls the rest: 'Say 'rest' and I stop for 5 seconds.'" },
          { title: "Step 3: N₂O-O₂", desc: "Appropriate and effective. School-age children understand and accept the mask well." },
          { title: "Step 4: Oral Midazolam", desc: "For severe dental anxiety with prior traumatic history. 0.5 mg/kg." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard LA." },
          { name: "N₂O-O₂", dose: "30–40% N₂O", note: "Very effective in school-age. Child can verbally communicate." },
          { name: "Ibuprofen post-op", dose: "5–10 mg/kg 6 hrly", note: "For post-procedure discomfort." }
        ],
        drugNote: "School-age children rarely require oral sedation for single-tooth restoration. N₂O is the most proportionate pharmacological intervention. Reserve oral sedation for children with documented prior traumatic dental experience or procedural anxiety disorders.",
        scriptEn: "Okay [name], let me tell you exactly what's happening — there's a tiny cavity bug in your back tooth. My job is to remove it in about 10 minutes. First I'll put some magic gel that makes the gum go to sleep — no pain after that, I promise. I'll count to 10 and then give you a 5-second break whenever you want. Deal? [wait for nod] Let's go.",
        scriptHi: "[नाम], मैं तुम्हें exactly बताता/बताती हूँ — तुम्हारे पिछले दाँत में एक छोटा कीड़ा है। मेरा काम है उसे 10 मिनट में निकालना। पहले एक magic gel लगाऊँगा जो मसूड़े को सुला देगा — उसके बाद कुछ feel नहीं होगा। मैं 10 तक count करूँगा और जब चाहो 5 second break लो। Deal? [wait] चलो।",
        scriptNote: "*The word 'Deal' activates the school-age child's sense of agency and agreement. They honour deals.",
        parentTactics: "For educated-demanding parents: give them a brief evidence-based rationale before they ask ('GIC here because it's faster and does not require extensive isolation, making it appropriate for this child today'). Ask them to step outside for the actual treatment — school-age children behave differently with parents out of direct line-of-sight.",
        failures: [
          "Treating school-age child as a toddler — they find it infantilising and resist more",
          "Over-explaining — 30-second brief is enough, not a lecture",
          "Allowing parent to stay in direct eyeline — parent anxiety transfers directly",
          "Using ultimatums ('if you don't open, we'll do it without anaesthesia') — breach of trust",
          "Not giving the child any signal of control (counting, 'raise hand if discomfort')"
        ],
        flagActions: "LA refusal (needle phobia): needle-free LA systems (Comfort-in, Anutra infiltration) are available in India at major dental colleges. Intraligamentary LA with very slow delivery is an alternative. Topical EMLA under occlusion for 30–60 min pre-procedure significantly reduces injection pain (Marwah Ch.15)."
      }),
      extraction: buildRecord({
        success: "78%",
        duration: "25–35 min",
        durationTip: "Full LA + test before proceeding. Don't be rushed by school-age children claiming they're 'fine.'",
        protocol: "Full LA + Rational Brief + Signal System",
        stratTitle: "Rational Preparation + Hand Signal System + Full LA",
        stratDesc: "School-age children need to feel in control during extraction. Establish a hand signal before starting: 'If anything is uncomfortable, raise your left hand and I will stop. But once we start, keep open and keep still.' This gives them an exit that most children never actually use. Provide rational brief explanation: 'This tooth is loose/infected and needs to come out so the new one can grow in properly — like making room for the next chapter.' Full LA protocol mandatory. Wait 5 min post-injection. Test before proceeding.",
        cultural: "For school-age Indian children, the cultural tooth disposal narrative can be continued: 'Yeh dant roof pe phenko — chuhiya aayegi aur naya golden dant laayegi!' This is still effective at this age and completely normalises the extraction outcome.",
        techniques: ["Full LA Protocol","Rational Explanation","Hand Signal Control System","Narrative Masking","Cultural Framing"],
        checklist: [
          "Establish left hand signal before starting — explicitly",
          "Full LA: topical → infiltration → test",
          "Closed technique with full luxation before delivery",
          "Immediate gauze placement + praise before child processes",
          "Written post-op in Hindi/regional language",
          "Ibuprofen prescription with dose instruction for parent"
        ],
        escalation: [
          { title: "Step 1: Confirm LA Fully", desc: "Test before any extraction. 'Can you feel this? [blunt instrument]' Proceed only on 'no feeling.'" },
          { title: "Step 2: N₂O-O₂", desc: "30–40% N₂O for anxious school-age patients with prior traumatic extraction experience." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Full block. Test before proceeding." },
          { name: "Ibuprofen post-op", dose: "5–10 mg/kg 6 hrly x 2 days", note: "Standard post-extraction." },
          { name: "Amoxicillin (if infected)", dose: "20–40 mg/kg/day div TDS x 5 days", note: "Only if periapical infection signs present." }
        ],
        drugNote: "Post-extraction antibiotic prescription is over-used in Indian dental practice. Per Marwah 5th Ed. and current evidence: antibiotics are NOT indicated for routine extractions in healthy children. Reserve for: swelling, trismus, fever, immunocompromised, or spreading infection.",
        scriptEn: "Okay [name], I'm going to explain exactly what's going to happen — no surprises. Step 1: magic gel on the gum, 60 seconds. Step 2: tiny pinch that you'll barely feel — the gum goes to sleep. Step 3: I wiggle the tooth loose — you'll feel pressure, not pain. Step 4: done. I'll tell you each step as we do it. If anything is uncomfortable, raise your left hand. Ready?",
        scriptHi: "[नाम], मैं तुम्हें exactly बताऊँगा/बताऊँगी — कोई surprise नहीं। Step 1: magic gel, 60 seconds। Step 2: छोटा सा pinch — मसूड़ा सो जाएगा। Step 3: मैं दाँत हिलाऊँगा — दबाव feel होगा, दर्द नहीं। Step 4: हो गया। अगर uncomfortable हो तो बायाँ हाथ उठाओ। तैयार?",
        scriptNote: "*Step-by-step transparency at school age = dramatically reduced anxiety vs vague reassurance.",
        parentTactics: "Ask parent to step outside during extraction — school-age children consistently behave better without parental observation. Brief them: 'We'll call you in as soon as we're done — it'll be faster this way.'",
        failures: [
          "Proceeding without confirmed complete anaesthesia in school-age child — traumatic and trust-destroying",
          "Not giving hand signal control — leaves child without agency",
          "Parent in the room for extraction — school-age children 'perform' distress for parents",
          "Overprescribing antibiotics post-extraction"
        ],
        flagActions: "Sickle cell: minimal trauma extraction, haemostasis packing (absorbable gelatin sponge), post-op monitoring. Asthma: lignocaine plain (no adrenaline) if high bronchospasm risk. Ensure reliever inhaler (Salbutamol) is available in operatory."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    },
    negative: {
      restoration: buildRecord({
        success: "88%",
        duration: "28–32 min",
        durationTip: "Moderate anxiety school-age children are very manageable with the right approach.",
        protocol: "TSD + Rational Brief + Autonomy + N₂O Option",
        stratTitle: "Brief Rational TSD with Autonomy Scaffolding",
        stratDesc: "Frankl 2 school-age children respond best to feeling respected and in control. Brief them factually in 3–4 sentences. Offer the hand signal. Give them a star chart or treat at the end. 'You're 7 — you're old enough to understand that the sleepy drops remove all discomfort. After that you won't feel a thing.' This rational framing works because school-age children want to be seen as capable.",
        cultural: "Academic framing resonates strongly with Indian school-age children: 'Yeh ek 5-minute task hai — tumhara homework usee zyaada time leta hoga!'",
        techniques: ["Rational Brief Explanation","TSD","Autonomy Scaffolding","Counting Distraction","Positive Reinforcement"],
        checklist: [
          "Brief patient alone for 60 seconds before starting",
          "Establish hand signal",
          "Standard LA protocol",
          "Explain each step as you do it — transparency builds trust"
        ],
        escalation: [
          { title: "Step 1: N₂O-O₂", desc: "30–40% N₂O if available. Works very well for Frankl 2 school-age." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard." }
        ],
        drugNote: "Frankl 2 school-age rarely requires sedation. TSD + hand signal + N₂O (if available) is sufficient for vast majority of cases.",
        scriptEn: "You seem a bit nervous — that's totally normal and makes complete sense. I'll tell you everything before I do it. Nothing will surprise you. After the sleepy drops, you won't feel anything from the tooth. I need you to keep still — you raise your hand if discomfort. I'll take a 5-second break. Sound like a plan?",
        scriptHi: "लगता है थोड़ी घबराहट है — यह बिल्कुल normal है। मैं हर step पहले बताऊँगा/बताऊँगी। Sleepy drops के बाद कुछ भी feel नहीं होगा। बस हिलना मत — और अगर कुछ हो तो हाथ उठाओ। Deal?",
        scriptNote: "*Validate the anxiety without amplifying it. Then immediately redirect to the action plan.",
        parentTactics: "Frankl 2 school-age: ask parent to step 2–3 feet back. Do not send out completely — the child knows they're there. Ask parent to give one thumbs-up at start, then stay neutral.",
        failures: [
          "Dismissing anxiety: 'Don't be silly, it's nothing' — invalidates the child's experience",
          "Skipping the hand signal for an anxious school-age child",
          "Detailed graphic description of procedure (drilling into enamel) — creates visual anxiety"
        ],
        flagActions: "Gag reflex at school-age: acupressure point (L14 — between thumb and index finger) + audio distraction. Patients with gag can usually manage with correct positioning (upright or slightly tilted) and rapid technique."
      }),
      exam: buildRecord({
        success: "88%",
        duration: "15–20 min",
        durationTip: "School-age children cooperate well for examination once rapport is established. Do not rush the initial rapport phase.",
        protocol: "TSD + Transparency + Hand Signal (Marwah Ch.12; McDonald & Avery Ch.18)",
        stratTitle: "Transparent Examination with Autonomy",
        stratDesc: "Brief the school-age child factually before any instrument enters. Name each instrument as you show it. 'This mirror just shows — it doesn't do anything. This little explorer checks if teeth are hard or soft. This is the suction — it drinks water.' Offer a hand signal. School-age children who feel in control cooperate at very high rates for examination. Keep exam sequential: soft tissue → incisors → premolars → molars. Comment positively on what you find as you go.",
        cultural: "Academic framing works well: 'We're going to do a dental health check — like a report card for your teeth.' Indian school-age children are conditioned to assessments and respond well to grading language. 'Your gums get an A! Your back teeth are getting a B — let's work on that.' Marwah notes this positive reinforcement technique is highly effective in Indian school-going cohorts.",
        techniques: ["TSD","Transparency","Hand Signal","Positive Reinforcement","Sequential Examination"],
        checklist: [
          "Name and show every instrument before using it",
          "Establish hand signal before any clinical contact",
          "Begin with soft tissue — least threatening",
          "Radiograph only if clinically essential — brief child first",
          "Chart findings verbally as you go — gives sense of progress"
        ],
        escalation: [
          { title: "Step 1: Defer Radiograph", desc: "If Frankl 2 and first visit — complete clinical exam, defer radiograph to visit 2 after rapport established." },
          { title: "Step 2: Acupressure for Gag", desc: "L14 point (between thumb and index) pressed firmly reduces gag reflex for radiograph." }
        ],
        drugs: [],
        drugNote: "No pharmacological intervention for examination. TSD + hand signal is sufficient in almost all school-age cases.",
        scriptEn: "Hi [Name] — before I use anything, I'm going to show you each tool and what it does. This is my rule: I never do anything without explaining it first. Sound fair? Great. First, this mirror — it only looks, never touches hard. This tiny explorer — feels if teeth are soft. Now open wide — we'll do a dental health check. I'll tell you your scores as we go.",
        scriptHi: "हाय [नाम] — कुछ भी use करने से पहले मैं हर tool दिखाऊँगा और बताऊँगा। यह मेरा rule है: बिना explain किए कुछ नहीं। ठीक है? यह mirror — बस देखता है। यह tiny explorer — check करता है दाँत hard हैं या soft। मुँह खोलो — dental health check करते हैं। जैसे-जैसे check होगा, score बताऊँगा।",
        scriptNote: "*Pre-briefing every tool removes the fear of the unknown. School-age children's anxiety is largely anticipatory — address it before it forms.",
        parentTactics: "Ask parent to sit in waiting area or 2 feet back. Direct all communication to child. For educated/demanding parents: 'We find children are more comfortable and cooperative when I speak with them directly — you'll get a full briefing at the end.' This is professionally framed and rarely challenged.",
        failures: [
          "Starting examination without briefing the child",
          "Probing aggressively at first visit — teaches instrument fear",
          "Directing all questions to parent instead of child",
          "Attempting radiographs without prior rapport on first visit"
        ],
        flagActions: "MIH detected at exam (chalky white/yellow-brown enamel on first molars/incisors): flag prominently. Hypomineralised teeth are hypersensitive even to air. Warn child before air syringe use: 'This might feel a bit cold on that tooth — raise your hand.' Document MIH severity per EAPD index (0-3 per tooth). Refer to AAPD MIH guidelines 2024."
      }),
      pulpectomy: buildRecord({
        success: "82%",
        duration: "35–45 min",
        durationTip: "School-age children are more cooperative than preschoolers for pulpectomy — the key challenge is adequate LA. Allow full onset time.",
        protocol: "LA Masking + Rational Explanation + Rubber Dam (Marwah Ch.15; AAPD Pulp Therapy Guidelines 2024)",
        stratTitle: "Rational LA Masking with Full Transparency",
        stratDesc: "School-age children can understand and accept pulpectomy when explained at their level. 'There's a nerve inside this tooth that's been bothering it — we're going to fix the inside so it doesn't hurt anymore. First we make the tooth completely numb.' Topical LA mandatory → slow infiltration → test before access. Rubber dam as 'tooth raincoat — keeps everything clean and dry.' Maintain continuous calm narration. School-age children tolerate the procedure well once numb. AAPD 2024: ZOE and KRI paste are both acceptable obturating materials for primary teeth. Marwah 5th Ed. now recommends KRI paste as preferred.",
        cultural: "Frame pulpectomy as problem-solving: 'This tooth sent us a message that it needed help. We listened, and now we're fixing it.' Indian school-age children respond to being cast as collaborative partners in their own healthcare — a significant cultural shift from younger age groups where the dentist maintains full authority.",
        techniques: ["Full LA Protocol","Rubber Dam","Rational Explanation","Continuous Narration","Hand Signal"],
        checklist: [
          "Topical LA 90 sec before infiltration — mandatory",
          "Syringe concealed — prepare and pass out of eyeline",
          "Test anaesthesia with blunt probe before any access",
          "Rubber dam placed before access opening",
          "Have KRI paste / ZOE pre-mixed before starting"
        ],
        escalation: [
          { title: "Step 1: 2-Visit Protocol", desc: "Visit 1: access + extirpation + Ca(OH)₂ dressing. Visit 2: obturation. Child anxiety is lower on second visit." },
          { title: "Step 2: N₂O-O₂", desc: "30–40% N₂O transforms school-age pulpectomy behaviour. Highly recommended if available." },
          { title: "Step 3: Intraligamentary LA", desc: "For mandibular molars with inadequate block — intraligamentary supplemental injection at PDL with 30G short needle." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr 1:80,000", dose: "4.4 mg/kg", note: "Block for mandible. Infiltration for maxilla. Full onset required." },
          { name: "Benzocaine topical 20%", dose: "90 sec pre-injection", note: "Mandatory." },
          { name: "KRI Paste (iodoform+Ca(OH)₂)", dose: "Canal length calibrated", note: "Preferred obturating material per Marwah 5th Ed. Resorbs with root." },
          { name: "Ca(OH)₂ dressing (Metapex/Apexcal)", dose: "Interim dressing", note: "For 2-visit protocol between appointments." }
        ],
        drugNote: "MIH teeth: LA may be inadequate due to inflammatory mediators in hypomineralised pulp. Try articaine 4% if available. Intraligamentary or intraosseous supplemental injections may be needed. Nelson's Pediatric Antimicrobial: if acute infection / swelling present — amoxicillin 40 mg/kg/day in 3 divided doses x 5 days (first line). Metronidazole 7.5 mg/kg TDS if anaerobic suspected.",
        scriptEn: "So your tooth has been sending pain signals — the nerve inside is inflamed. We're going to fix that today by treating the inside of the tooth. First step: completely numb it. You'll feel the gel, then a brief pressure. After that, you'll feel nothing from the tooth — guaranteed. Let's start with the gel on your gum. [Apply topical.] 60 seconds…",
        scriptHi: "तुम्हारे दाँत ने दर्द के signals भेजे — अंदर का nerve inflamed है। आज हम अंदर से ठीक करेंगे। पहला step: पूरा numb करना। Gel feel होगा, फिर थोड़ा pressure। उसके बाद दाँत से कुछ feel नहीं — guaranteed। चलो gel से शुरू करते हैं।",
        scriptNote: "*Using medical language at age-appropriate level builds trust with school-age children. They feel respected, not talked down to.",
        parentTactics: "Brief parent: 'This procedure takes 35–45 minutes. Please remain in the waiting area — [name] will do much better with direct communication. I'll come out at the end to debrief you fully.' For anxious parents: 'The tooth is infected and needs treatment today to prevent spread. This is the correct procedure.'",
        failures: [
          "Proceeding without confirmed LA — most common cause of procedure failure",
          "Using 'drill' or 'nerve removal' language — triggers fear",
          "Not testing anaesthesia before access",
          "Working without rubber dam — aspiration risk + poor outcome",
          "Attempting single-visit pulpectomy in Frankl 1 without sedation"
        ],
        flagActions: "MIH: document severity. LA may need supplementation — articaine if available. Thalassaemia/sickle cell: check Hb >10 g/dL before elective procedure. ASD: dim procedural lights, reduce high-speed noise exposure, allow child to hold familiar object. Pre-agree a break signal."
      }),
      sdf: buildRecord({
        success: "95%",
        duration: "10–15 min",
        durationTip: "SDF is one of the fastest, most atraumatic procedures in pediatric dentistry. No LA needed. Ideal for Frankl 1-2 school-age children with multiple carious lesions.",
        protocol: "SDF 38% Application — AAPD 2024 / Marwah 5th Ed. Ch.20",
        stratTitle: "Atraumatic SDF with Informed Consent on Staining",
        stratDesc: "Silver Diamine Fluoride 38% arrests active carious lesions without LA or drilling. Arrest rate: 81% primary teeth (Marwah). Apply to isolated dry tooth surfaces with microbrush — 30 seconds per surface, blot excess. Critical: inform child and parent that treated lesions will turn BLACK permanently. For school-age children, this must be framed carefully — 'The silver makes the sugar bugs go away, but it leaves a dark mark on that spot. It won't show when you smile — it's the back/inside surface.' Per AAPD 2024: SDF is appropriate for arresting caries in primary and permanent teeth, especially in children who cannot tolerate conventional treatment.",
        cultural: "Staining is the main barrier to SDF acceptance in Indian families — especially for aesthetic-conscious urban parents. Address proactively: 'Yeh kaala nishan ek sign hai ki medicine kaam kar rahi hai — jaise haldi se nishan. Kuch time mein permanent ho jaata hai.' Compare to common cultural experiences with turmeric staining to normalise it.",
        techniques: ["SDF 38% Application","Moisture Control","Parental Informed Consent on Staining","Atraumatic Approach"],
        checklist: [
          "Informed consent for staining — documented",
          "Petroleum jelly on adjacent soft tissue to prevent staining",
          "Isolate tooth with cotton rolls",
          "Dry surface thoroughly before application",
          "Apply with microbrush, 30 sec per surface, blot excess",
          "Do not rinse — patient swallows trace amounts (safe per AAPD)"
        ],
        escalation: [
          { title: "Step 1: Staining Concern", desc: "If parent refuses due to staining — offer Hall Technique SSC for posterior teeth as alternative arrest + restoration." },
          { title: "Step 2: Definitive Restoration", desc: "SDF arrests but does not restore. Plan RMGIC/composite restoration at subsequent visit once child is cooperative." }
        ],
        drugs: [
          { name: "SDF 38% (Advantage Arrest / Riva Star)", dose: "1 drop per 5 teeth", note: "Single application. Reapply every 6–12 months for continued arrest." },
          { name: "Fluoride varnish 5% NaF", dose: "0.25 mL per application", note: "Can be applied at same visit for additional caries prevention." }
        ],
        drugNote: "SDF is widely available in India (Riva Star — SDI, Advantage Arrest). Cost-effective. No cold chain required. Appropriate for AYUSH / rural settings where drilling infrastructure is limited. JISPPD studies from India show comparable arrest rates to international literature.",
        scriptEn: "Today we're going to put a special silver medicine on your teeth — it fights the sugar bugs and makes your teeth very hard and strong. It takes about 30 seconds per tooth and there's NO needle and NO drilling. The only thing is: the spots where we put the medicine will turn a dark colour — that's how you know it's working. It'll be on the inside/back of your teeth so nobody will see it when you smile.",
        scriptHi: "आज हम तुम्हारे दाँतों पर एक special silver medicine लगाएँगे — यह sugar bugs को खत्म करती है और दाँत बहुत hard और strong बनाती है। हर दाँत पर 30 second — कोई injection नहीं, कोई drilling नहीं। बस एक बात: जहाँ medicine लगेगी वो dark हो जाएगी — इसका मतलब medicine काम कर रही है। यह पीछे की side पर है, smile में नहीं दिखेगा।",
        scriptNote: "*For school-age: explain the mechanism simply — they can understand and this builds compliance. The staining consent conversation must happen before application.",
        parentTactics: "For concerned parents: show them peer-reviewed AAPD/JISPPD summary — 81% arrest rate, no side effects, WHO essential medicine. 'This is evidence-based treatment used globally including AIIMS, KEM, and Nair Hospital. The alternative — drilling — requires your child to be cooperative and takes 30+ minutes. SDF takes 10 minutes with no needle.' For aesthetic objection: 'The dark marks are on chewing surfaces — not visible when smiling. And they will be replaced with a white filling at the next appointment when your child is ready.'",
        failures: [
          "Not warning parent/child about staining before application — destroys trust",
          "Applying to wet tooth surface — dramatically reduces efficacy",
          "Applying to pulpally involved teeth — SDF is for caries arrest, not pulp therapy",
          "Not isolating adjacent tissues — risk of gum/skin staining",
          "Not scheduling follow-up — SDF without monitoring is incomplete care"
        ],
        flagActions: "Silver allergy (rare): do not apply SDF. Use fluoride varnish alone or ART technique. Fluorosis: SDF on fluorotic pitting — efficacy may be lower. Document baseline caries status with photographs before first application to track arrest at follow-up."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    },
    positive: {
      restoration: buildRecord({
        success: "96%",
        duration: "20–25 min",
        durationTip: "Frankl 3 school-age: cooperative with standard approach. No need for extended rapport building.",
        protocol: "Standard TSD + LA (Marwah Ch.12; McDonald & Avery Ch.18)",
        stratTitle: "Efficient Standard Protocol with Positive Reinforcement",
        stratDesc: "Frankl 3 school-age children accept treatment with minimal persuasion. Brief TSD, standard LA protocol, straightforward work. The key is maintaining their cooperation by respecting their intelligence — brief them factually, move efficiently, praise specifically. Over-explaining or being overly performative can actually make Frankl 3 children less cooperative by making them feel the dentist is nervous. Calm, clinical confidence is the main communication tool.",
        cultural: "Indian school-age Frankl 3 children from educated families often respond to being framed as 'responsible' — 'You're helping us by keeping still and this will all go much faster.' Academic framing and sense of contribution work well. Pinkham (5th Ed.) notes that school-age children in this category can be excellent dental patients with appropriate practitioner communication.",
        techniques: ["Standard TSD","LA Protocol","Brief Explanation","Positive Reinforcement","Efficient Work"],
        checklist: [
          "Brief TSD — don't over-explain to a cooperative child",
          "Standard LA: topical + slow infiltration + test",
          "Keep parent present at a distance — child knows support is available",
          "Specific praise: 'You kept your mouth open perfectly' — not just 'good job'"
        ],
        escalation: [
          { title: "Step 1: N₂O-O₂", desc: "If any anxiety emerges during procedure — 30% N₂O available as instant support." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard." }
        ],
        drugNote: "Frankl 3 school-age: no sedation needed. Standard LA is sufficient.",
        scriptEn: "Hi [name]! Today we're doing [procedure] — takes about 20 minutes. I'll explain each step as I go. Ready? First the numbing gel, then a quick injection, then we fix the tooth. Any questions? Great — let's go.",
        scriptHi: "[नाम] हाय! आज [procedure] करेंगे — लगभग 20 minute। हर step बताता जाऊँगा। तैयार? पहले gel, फिर injection, फिर दाँत ठीक। कोई सवाल? बढ़िया — चलते हैं।",
        scriptNote: "*Efficient, direct, confident. Frankl 3 children do not need extended ritual — they need clinical confidence.",
        parentTactics: "Parent can remain at back of room. Brief communication: 'Your child is cooperative — I'll take it from here and give you a full summary at the end.'",
        failures: [
          "Over-managing a cooperative child — makes them feel something scary is coming",
          "Excessive performative praise — 'You're the bravest child EVER!' feels fake at school-age"
        ],
        flagActions: "Standard clinical flags apply. MIH: warn child before air syringe on hypomineralised surface. Asthma: LA plain (no adrenaline if severe), rubber dam cautiously."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    },
    definitely_positive: {
      restoration: buildRecord({
        success: "99%",
        duration: "20–25 min",
        durationTip: "Fastest cohort — maximise efficiency. Definitely positive school-age patients are a gift. Move at clinical pace.",
        protocol: "Direct Clinical Approach (Marwah Ch.12)",
        stratTitle: "Direct, Efficient, Respectful",
        stratDesc: "Definitely positive school-age children require minimal behavior management. Treat them with the same respect you would an adult patient. Briefly explain what you are doing, move efficiently, and deliver specific praise at the end. The biggest mistake is spending 10 minutes on behavior management for a child who was never going to be a problem. Pinkham (5th Ed.): cooperative patients remain cooperative as long as the clinician is competent, calm, and punctual. Procedural pain due to inadequate LA is the most common way to convert a Frankl 4 to Frankl 1.",
        cultural: "Definitely positive school-age children in India are often from dental-positive family environments — parents who have good dental health themselves and model non-fearful attitudes. Reinforce this with the parent: 'Your child's attitude toward dentistry is a direct result of how you've framed it at home — this makes our job easy and their dental health excellent. Well done.'",
        techniques: ["Direct Approach","Full Explanation","Standard LA","Efficient Work"],
        checklist: [
          "Standard LA — do not skip; even Frankl 4 children will become Frankl 1 if they feel pain",
          "Explain procedure briefly — one sentence per step",
          "Move at clinical pace — do not artificially slow down",
          "Specific functional praise at close: 'You kept your tongue out of the way the whole time — that's actually impressive'"
        ],
        escalation: [],
        drugs: [
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard. Never skip LA even for Frankl 4." }
        ],
        drugNote: "No sedation. Standard LA. Most efficient visit type in pediatric practice.",
        scriptEn: "Hi [name] — ready? We're doing [procedure] today, about 20 minutes. Numbing gel, quick injection, then work. You know the routine. Let me know if you need a break — left hand up. Otherwise let's move. Open please.",
        scriptHi: "[नाम] तैयार? आज [procedure] — 20 minute। Gel, injection, फिर काम। तुम्हें पता है कैसे होता है। Break चाहिए तो बाया हाथ। Otherwise चलते हैं। खोलो।",
        scriptNote: "*Efficiency is the highest form of respect for a cooperative patient. Don't make them sit through rituals designed for anxious patients.",
        parentTactics: "Parent in waiting room is ideal. Brief: 'Your child is wonderful — we'll be done in 20 minutes.' No further coaching needed.",
        failures: [
          "Skipping LA because 'child is so cooperative' — catastrophic if procedure causes pain",
          "Over-explaining and ritual-managing a Frankl 4 — wastes their time and yours"
        ],
        flagActions: "Standard clinical flags apply. No behavior management flags for Frankl 4 school-age."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHindi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    }
  },
  // ── PRE-TEEN (9–12 years) ────────────────────────────────────────
  preteen: {
    negative: {
      restoration: buildRecord({
        success: "90%",
        duration: "30–35 min",
        durationTip: "Pre-teens are highly manageable — respect their autonomy and they cooperate well.",
        protocol: "Informed Consent Discussion + Autonomy + Transparency",
        stratTitle: "Peer-Level Communication + Full Transparency + Autonomy",
        stratDesc: "Pre-teens respond best to being treated as near-adults. Speak to them directly, not through the parent. Use near-adult language: 'There's enamel decay in your first molar — I need to remove it and place a composite filling. Takes about 25 minutes. You'll be numb from the injection, which takes 30 seconds. After that — nothing.' Allow questions. Give them the hand signal. Offer music/earphones. Pre-teens with dental anxiety often have a specific trigger (previous painful experience, peer story, online content) — identify and directly address it.",
        cultural: "Indian pre-teens are heavily influenced by social media and YouTube. Some will arrive having watched 'painful dental procedure' videos. Ask directly: 'Did you watch anything about this online? What did it show?' Address specifically. Reframe: 'That video was not typical — our technique is different because we ensure full anaesthesia before any work.'",
        techniques: ["Near-Adult Communication","Full Transparency","Autonomy","Hand Signal","Music Distraction","Identify Specific Trigger"],
        checklist: [
          "Speak to pre-teen first, parent second",
          "Ask about prior dental experiences and any specific fears",
          "Offer music/earphones during procedure",
          "Full LA — test before proceeding",
          "Explain composite vs GIC option briefly and let them have input"
        ],
        escalation: [
          { title: "Step 1: Identify Specific Trigger", desc: "Ask the pre-teen what specifically they fear. Address that one thing directly." },
          { title: "Step 2: N₂O-O₂", desc: "Pre-teens accept and benefit from N₂O. Explain: 'It makes you feel relaxed, like floating — you're still awake and in control.'" }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard. Test before." },
          { name: "N₂O-O₂", dose: "30% N₂O titration", note: "Very effective, well-tolerated by pre-teens." }
        ],
        drugNote: "Pre-teens rarely require oral sedation for standard restorations. Oral midazolam is appropriate only for severe documented anxiety with prior traumatic dental experience — and should be accompanied by parent informed consent documentation.",
        scriptEn: "So [name] — tell me, what's your biggest worry about today? [listen]. Okay, I hear that. Here's what's actually going to happen: [clear factual explanation]. You're going to be in control the whole time — raise your left hand if you need a 5-second break. I'll be completely straight with you: there will be a small injection, 30 seconds, a bit of pressure. After that? Zero pain. I'll let you know every step before I do it.",
        scriptHi: "[नाम], बताओ — आज किस बात की सबसे ज़्यादा chinta है? [सुनें]। ठीक है, मैं समझता/समझती हूँ। यह actually होगा: [clear explanation]। तुम पूरे time control में रहोगे — बायाँ हाथ उठाओ अगर 5 second break चाहिए। मैं directly बताऊँगा/बताऊँगी: एक छोटा injection होगा, 30 second, थोड़ा pressure — उसके बाद कुछ नहीं। हर step पहले बताऊँगा/बताऊँगी।",
        scriptNote: "*Asking 'what's your biggest worry' acknowledges them as individuals and gives you a specific target to address. Pre-teens respond powerfully to being heard.",
        parentTactics: "Ask parent to remain seated in waiting area for the actual procedure. Brief the pre-teen: 'Your mum/dad is right outside. We'll call them in when we're done.' Pre-teens often cooperate much better when parents are not visibly present. Document this in notes.",
        failures: [
          "Talking to parent instead of pre-teen — immediate disengagement",
          "Dismissing their concern ('you're almost a teenager, this is nothing')",
          "Not offering music/distraction to a pre-teen",
          "Treating them identically to a preschooler — loss of credibility"
        ],
        flagActions: "MIH (Molar Incisor Hypomineralisation) — increasingly common in Indian pre-teens. Hypomineralised enamel is hypersensitive: local anaesthesia may be less effective. Use articaine 4% (if available) or intraligamentary supplemental injection. Be honest with patient: 'This tooth is extra sensitive because the enamel formed differently — we may need extra anaesthesia.' MIH included in Marwah 5th Ed. Ch.21."
      }),
      pulpectomy: buildRecord({
        success: "88%",
        duration: "35–45 min",
        durationTip: "Pre-teens are excellent pulpectomy patients when fully informed. Identify MIH early — LA may require supplementation.",
        protocol: "Adult-Level Explanation + Full LA + Rubber Dam (AAPD Pulp Therapy 2024; Marwah Ch.15)",
        stratTitle: "Near-Adult Pulp Therapy Protocol with Full Informed Consent",
        stratDesc: "Pre-teen pulpectomy patients respond best to adult-level explanations delivered directly. 'This tooth has an infected nerve. We're going to remove the nerve tissue, clean the canal system, and seal it. After full anaesthesia you won't feel anything — only vibration from the files.' AAPD 2024: formocresol pulpotomy remains acceptable but KRI paste (Marwah 5th Ed.) is preferred for pulpectomy obturation. Obtain clear verbal consent from the pre-teen directly before obtaining parental consent. Rubber dam is mandatory — do not negotiate. The pre-teen may question it: 'This dam keeps water and debris away from your throat — it's a safety device.'",
        cultural: "Pre-teens from urban Indian families often independently Google their diagnosis before arriving. Ask: 'Did you look this up online? What did you find?' Address any misinformation directly. Honesty about what pulpectomy involves — including that files will be used inside the tooth — builds more lasting trust than euphemisms. McDonald & Avery (10th Ed.): adolescent patients who are fully informed show higher cooperation rates and lower post-procedural anxiety.",
        techniques: ["Adult-Level Informed Consent","Full LA Protocol","Rubber Dam","Music Distraction","Autonomy","Intraligamentary Supplemental LA if needed"],
        checklist: [
          "Speak to pre-teen directly — explain procedure in medical terms with translation",
          "Topical LA 90 sec → slow infiltration → wait 5 min → test",
          "Rubber dam placed before access — explain purpose",
          "Have KRI paste pre-mixed before starting",
          "Offer earphones with music of their choice during procedure"
        ],
        escalation: [
          { title: "Step 1: Supplemental LA for MIH", desc: "Articaine 4% or intraligamentary injection if standard block insufficient. Be transparent: 'Your tooth needs a little extra medicine — that's common with this type of enamel.'" },
          { title: "Step 2: 2-Visit Protocol", desc: "If procedure is long or child signals fatigue: Ca(OH)₂ interim dressing, complete obturation at visit 2." },
          { title: "Step 3: N₂O-O₂", desc: "Pre-teens accept N₂O well — describe accurately: 'It makes you feel relaxed and a bit floaty, you stay awake and in control.'" }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr 1:80,000", dose: "4.4 mg/kg", note: "Full block. Test before access." },
          { name: "Articaine 4% + Adr 1:100,000", dose: "5 mg/kg", note: "For MIH teeth or inadequate block. Use with caution re: max dose." },
          { name: "KRI Paste (iodoform + Ca(OH)₂)", dose: "Canal length calibrated", note: "Preferred obturating material (Marwah 5th Ed., AAPD 2024)." },
          { name: "Ibuprofen post-op", dose: "5–10 mg/kg 6-hrly x 2 days", note: "Pre-teen can swallow tablets. Safe and effective for post-procedure pain." }
        ],
        drugNote: "Nelson's Pediatric Antimicrobial: acute dentoalveolar abscess with swelling — Amoxicillin 40 mg/kg/day in 3 doses x 5 days. If penicillin allergic: Azithromycin 10 mg/kg/day OD x 3 days. If anaerobic component: add Metronidazole 7.5 mg/kg TDS. Always drain before antibiotics — antibiotics alone do not resolve abscess.",
        scriptEn: "[Name], I want to explain exactly what's happening and what we're going to do. Your tooth has a nerve inside that's been getting inflamed — probably from the decay reaching deep. We're going to treat the inside of the tooth today: remove the affected nerve tissue, clean the space, and seal it. After the anaesthetic, which takes about 3 minutes to work, you'll feel zero pain from the tooth — just vibration from the instruments. I'm going to put this rubber dam on — it keeps your throat safe and clean. Music on?",
        scriptHi: "[नाम], मैं exactly explain करना चाहता/चाहती हूँ। तुम्हारे दाँत के अंदर जो nerve है वो inflamed हो गई है — शायद cavity से। आज हम अंदर treat करेंगे: affected nerve निकालेंगे, space clean करेंगे, seal करेंगे। Anaesthetic के बाद — जो 3 minute में काम करता है — दाँत से कुछ feel नहीं होगा, बस instruments की vibration। यह rubber dam throat को safe रखता है। Music लगाऊँ?",
        scriptNote: "*Medical accuracy + pre-teen autonomy = highest cooperation. Never euphemise with pre-teens — they see through it and lose trust.",
        parentTactics: "Ask parent to wait outside. Brief them before: 'I'll explain everything to [name] directly and get their agreement — this builds better long-term dental health behaviour. I'll come out at the end for a full summary.' For concerned parents: 'The pulp is irreversibly inflamed — conservative treatment is no longer possible. Pulpectomy is the evidence-based standard of care per AAPD 2024 guidelines.'",
        failures: [
          "Using baby language with a pre-teen — immediate credibility loss",
          "Proceeding to access without confirmed LA — most common cause of procedure trauma",
          "Skipping rubber dam — unacceptable risk to both child and clinician",
          "Allowing parent to be primary conversation partner — the pre-teen disengages",
          "Not addressing MIH-related LA inadequacy before starting"
        ],
        flagActions: "MIH: document per EAPD index. LA supplementation likely needed — warn patient honestly. Congenital heart disease: antibiotic prophylaxis per AHA protocol before procedure. Cleft palate: rubber dam application technique may need modification around palatal anatomy."
      }),
      extraction: buildRecord({
        success: "92%",
        duration: "20–30 min",
        durationTip: "Pre-teens are highly manageable for extraction with full LA and honest briefing. Do not underestimate anxiety — validate it.",
        protocol: "Full LA + Closed Technique + Autonomy (Marwah Ch.17; McDonald & Avery Ch.21)",
        stratTitle: "Fully Informed Extraction with Autonomy and Hand Signal",
        stratDesc: "Pre-teens respond best to complete transparency about extraction. 'I'm going to remove this tooth. After full anaesthesia, you'll feel pressure — like someone pressing firmly — but absolutely no pain. The procedure itself takes less than 2 minutes once you're numb. Here is a signal: left hand up means stop.' Test anaesthesia before any attempt to luxate. Closed technique: luxate fully with elevator before delivery. Speed of extraction once numb reduces anxiety — do not hesitate with delivery. Post-extraction: give child the tooth in a gauze 'parcel' — pre-teens often want to keep it. Full written post-op instructions.",
        cultural: "Indian pre-teens may have siblings or friends who've had extractions and exaggerated the experience ('so much blood,' 'he was crying for hours'). Address peer misinformation: 'What did your friend tell you? Let me give you the accurate version.' Direct information from a clinical authority figure is more trusted by pre-teens than peer anecdote — use this. McDonald & Avery (10th Ed.) notes pre-teens as one of the most clinician-responsive age groups when treated with respect.",
        techniques: ["Full LA Protocol","Test Before Extraction","Closed Technique","Hand Signal","Post-Op Written Instructions","Peer Misinformation Correction"],
        checklist: [
          "Topical 90 sec → infiltration → supplemental (lingual/palatal) → test before luxation",
          "Address any peer stories pre-procedure",
          "Closed technique: full luxation before delivery",
          "Have gauze ready before delivery",
          "Written post-op instructions in Hindi + English",
          "Arrange follow-up at [date] — space management assessment if permanent tooth"
        ],
        escalation: [
          { title: "Step 1: Intraligamentary LA", desc: "For resistant anaesthesia: 30G short needle at PDL, slow pressure injection. Highly effective supplemental technique." },
          { title: "Step 2: N₂O-O₂", desc: "If significant pre-procedural anxiety: 30% N₂O brings pre-teen to a workable state within 5 minutes." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr 1:80,000", dose: "4.4 mg/kg", note: "Full block. Supplemental always for mandibular molars." },
          { name: "Ibuprofen", dose: "5–10 mg/kg 6-hrly x 2 days", note: "Post-extraction. Superior to paracetamol for dental pain." },
          { name: "Paracetamol", dose: "10–15 mg/kg 6-hrly", note: "If NSAID contraindicated (asthma)." }
        ],
        drugNote: "Space management post-extraction in pre-teens is critical — assess whether space maintainer is needed based on root development of successor and arch length. Marwah Ch.19: if >1/3 of permanent root has formed, space maintenance is less critical. If less than 1/3 — space maintainer recommended.",
        scriptEn: "[Name] — I'll be completely straight with you. We're taking this tooth out today. Here's how it works: gel on the gum for 60 seconds, then the anaesthetic injection — 30 seconds of pressure and brief sting, then nothing. We wait 3 minutes. Then I test: can you feel this? If numb — out it comes. If not — more medicine. The removal itself: 2 minutes of pressure, then done. Left hand up if you need a pause at any point. Questions?",
        scriptHi: "[नाम] — directly बताता/बताती हूँ। आज यह दाँत निकलेगा। यह कैसे होगा: मसूड़े पर gel 60 second, फिर injection — 30 second pressure, brief sting, फिर कुछ नहीं। 3 minute wait। फिर test: feel हो रहा है? Numb है तो निकाल देते हैं। 2 minute pressure — फिर done। कुछ हो तो बाया हाथ। सवाल?",
        scriptNote: "*Step-by-step preview of the entire procedure reduces the unknown. Pre-teens who know every step in advance show significantly lower anxiety during the procedure — validated by Pinkham 5th Ed.",
        parentTactics: "Parent in waiting room preferred. Pre-brief: 'I've explained everything to [name] directly — they have full information and have agreed to proceed. I'll be out in 25 minutes.' If parent insists on being present: they sit at head-end, silent, no commentary. Written post-op instructions go to both child and parent.",
        failures: [
          "Not testing anaesthesia before luxation — unacceptable",
          "Allowing parent to narrate or comment during extraction",
          "Not addressing peer misinformation proactively",
          "No post-op written instructions — increases callbacks",
          "Not assessing space management need post-extraction"
        ],
        flagActions: "Permanent tooth extraction in pre-teen: assess orthodontic implications before extracting — consult with orthodontics if time permits. Space maintainer often needed for premolar region. Congenital heart disease: AHA antibiotic prophylaxis protocol before extraction. Cleft: surgeon liaise."
      }),
      exam: buildRecord({
        success: "98%",
        duration: "15–20 min",
        durationTip: "Pre-teen examination is straightforward. Focus on clinical thoroughness — MIH screening, periodontal assessment, space analysis.",
        protocol: "Adult-Level Clinical Examination + Direct Communication (McDonald & Avery Ch.1; Marwah Ch.3)",
        stratTitle: "Comprehensive Clinical Exam with Direct Pre-Teen Communication",
        stratDesc: "Examine pre-teens as you would a young adult. Direct all communication to the patient — not the parent. Comprehensive exam: TMJ screening, soft tissue, periodontal probing, dentition, MIH screening (EAPD index), caries risk assessment, space analysis. Pre-teens benefit from a brief summary at the end: 'Here's what I found, here's what it means, here's what we'll do.' This builds dental health literacy. Per McDonald & Avery (10th Ed.): the pre-teen examination is an opportunity to establish lifelong dental behaviour — invest in communication quality.",
        cultural: "Pre-teens in Grade 5–7 Indian schools are increasingly aware of aesthetics — crooked teeth, discolouration, spacing. They may have specific aesthetic concerns that the parent hasn't mentioned. Always ask the pre-teen: 'Is there anything about your smile or teeth that bothers you?' Often reveals MIH staining concerns, spacing issues, or tooth colour anxiety that drives the real reason for the visit.",
        techniques: ["Adult-Level Communication","Direct Patient-First Communication","Comprehensive Clinical Assessment","MIH Screening","Caries Risk Assessment"],
        checklist: [
          "Speak to pre-teen first — ask about chief complaint and aesthetic concerns",
          "TMJ screen — joint sounds, range of motion, pain on palpation",
          "Full periodontal probing — pre-teens can develop early gingivitis",
          "MIH screening: examine all first permanent molars and incisors for enamel defects",
          "Caries risk classification (low/moderate/high) using AAPD caries risk tool",
          "Space analysis if mixed dentition — Moyers or Tanaka-Johnston"
        ],
        escalation: [],
        drugs: [],
        drugNote: "No pharmacological intervention for examination. Note fluoride varnish application can be done at same visit — 5% NaF, 0.25 mL, 1–4 surfaces. Per AAPD 2024: fluoride varnish recommended every 6 months for high caries-risk children.",
        scriptEn: "Hi [name] — have a seat. I want to talk with you first, before I do any examination. What's going on with your teeth? Is there anything that's been bothering you, anything about your smile you'd like to change? [Listen.] Okay. I'm going to do a full check today — teeth, gums, jaw. At the end I'll give you a complete summary and we'll make a plan together. Sound good?",
        scriptHi: "हाय [नाम] — बैठो। पहले तुमसे बात करना है, examination से पहले। दाँतों में क्या हो रहा है? कुछ परेशान कर रहा है, या smile में कुछ change करना चाहते हो? [सुनें।] ठीक है। आज full check करूँगा/करूँगी — दाँत, मसूड़े, jaw। अंत में complete summary दूँगा/दूँगी और plan बनाएँगे। ठीक है?",
        scriptNote: "*Starting with the pre-teen's own concerns gives them ownership of the appointment. This is the most powerful engagement tool for this age group.",
        parentTactics: "Ask parent to be seated separately. After examination: debrief both parent and pre-teen together. Share the caries risk category with both: 'We've assessed [name] as moderate caries risk based on diet, oral hygiene, and enamel quality. Here's what that means and what we recommend.' This dual briefing models appropriate health communication for the pre-teen.",
        failures: [
          "Speaking only to parent — pre-teen feels invisible, disengages",
          "Not doing MIH screen — increasingly prevalent and easily missed",
          "Skipping periodontal probing — pre-teens can have significant gingivitis",
          "Not addressing aesthetic concerns the pre-teen mentioned"
        ],
        flagActions: "MIH found: photograph, document EAPD severity score per tooth, begin discussion about management options (desensitisation, GIC seal, SSC, composite, resin infiltration). Periodontal issue: oral hygiene instruction directed at pre-teen — not parent. 'You clean your own teeth now — here's what to change.' Space issue: refer for mixed dentition space analysis and orthodontic opinion if indicated."
      }),
      sdf: buildRecord({
        success: "90%",
        duration: "10–15 min",
        durationTip: "SDF in pre-teens: staining concern is highest in this aesthetic-conscious age group. Informed consent conversation is critical.",
        protocol: "SDF 38% with Full Informed Consent on Staining (AAPD 2024; Marwah Ch.20)",
        stratTitle: "SDF with Aesthetic-Sensitive Counselling for Pre-Teen",
        stratDesc: "Pre-teens are the most aesthetically sensitive age group for SDF staining. Informed consent must be thorough and direct. 'The silver in this medicine will permanently darken any decayed spots it touches — that's how it kills the bacteria. If the cavity is on a visible surface, we need to discuss whether this is acceptable to you, or whether we should take a different approach.' For posterior/non-visible lesions: SDF is ideal — fast, no needle, high arrest rate. For anterior/visible lesions in pre-teens: offer alternatives (resin infiltration — Icon, composite) or accept SDF with clear documentation. AAPD 2024: pre-teen should be part of the treatment decision.",
        cultural: "Aesthetic self-consciousness peaks in pre-teen years. Indian pre-teens are additionally influenced by social media standards and peer appearance. Do not dismiss staining concern: 'You are absolutely right to think about how this looks — it's your smile.' Then give them information to make their own choice. This autonomy-respecting approach is more effective than directing the decision.",
        techniques: ["Full Informed Consent","Patient Autonomy in Treatment Decision","SDF Application","Staining Counselling","Alternative Discussion"],
        checklist: [
          "Staining consent conversation: direct, clear, documented",
          "Assess tooth visibility before deciding SDF vs alternative",
          "For visible anterior lesions: discuss Icon (resin infiltration), composite, or delayed SDF",
          "Petroleum jelly on adjacent soft tissue",
          "Dry tooth thoroughly before application",
          "Photograph pre- and post-application for follow-up comparison"
        ],
        escalation: [
          { title: "If Aesthetic Concern: Alternative", desc: "Resin infiltration (Icon — DMG) for smooth surface enamel lesions: no staining, good arrest rate, single visit. Higher cost." },
          { title: "If Refuses Both: Monitor", desc: "Caries risk monitoring with fluoride varnish every 6 months. Document informed refusal." }
        ],
        drugs: [
          { name: "SDF 38%", dose: "1 drop per 5 teeth", note: "For posterior/non-visible lesions. Reapply every 6–12 months." },
          { name: "Fluoride Varnish 5% NaF", dose: "0.25 mL per application", note: "Apply at same visit or as sole treatment if SDF declined." }
        ],
        drugNote: "AAPD 2024 Caries Management by Risk Assessment (CAMBRA): for high-risk pre-teen — SDF + fluoride varnish + dietary counselling. For MIH-affected hypomineralised enamel: SDF shows reduced penetration — document and monitor closely. Icon resin infiltration may be preferred for MIH pitting.",
        scriptEn: "[Name] — I want to explain this medicine and let you make an informed choice. This is silver diamine fluoride — it's very effective at stopping decay without drilling or needles. The only catch: wherever it touches a cavity, that spot turns permanently dark. For the back teeth — it won't show. For any front-facing surfaces, that's something you'd see, and you'd see it. What do you think? I have alternatives if the staining would bother you.",
        scriptHi: "[नाम] — यह medicine explain करके तुम्हें choose करने देना चाहता/चाहती हूँ। यह SDF है — बिना drilling, बिनা injection, cavity रोकने में बहुत effective। एक बात: जहाँ cavity पर लगेगी, वो permanently dark हो जाएगी। पीछे के दाँत — दिखेगा नहीं। आगे की side हो तो दिखेगा। तुम्हें क्या लगता है? अगर staining पसंद नहीं तो दूसरा option भी है।",
        scriptNote: "*Pre-teen autonomy in treatment decisions improves compliance, reduces regret, and builds dental health agency — per Pinkham 5th Ed.",
        parentTactics: "Include pre-teen in all discussions about SDF. Parent should confirm but not override the pre-teen's choice on a visible tooth. Document: 'Treatment discussed with patient and parent. Patient consent obtained. Staining risk explained and accepted/declined.'",
        failures: [
          "Applying SDF to a visible anterior tooth without explicit pre-teen consent on staining",
          "Dismissing pre-teen's aesthetic concern as vanity",
          "Not offering alternatives — pre-teen should know their options",
          "Applying to wet surface — efficacy failure"
        ],
        flagActions: "MIH anterior tooth with staining: SDF may worsen appearance. Resin infiltration or conservative composite preferred. Document MIH EAPD severity. Fluorosis: discuss separately — SDF does not treat fluorosis staining and may compound appearance concern."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    },
    definitely_negative: {
      restoration: buildRecord({
        success: "82%",
        duration: "30–40 min",
        durationTip: "Definitely negative pre-teen is uncommon — usually linked to specific prior trauma or severe dental phobia. Identification and direct discussion of the specific fear is the core management strategy.",
        protocol: "Identify Specific Fear + Systematic Desensitisation + N₂O Option (Pinkham 5th Ed.; McDonald & Avery Ch.18)",
        stratTitle: "Fear Identification + Graduated Exposure + Autonomy",
        stratDesc: "Definitely negative pre-teens are rare — Frankl 1 at this age usually indicates either a severely traumatic prior dental experience, undiagnosed dental phobia (MDAS >19), or underlying anxiety disorder. The management starts before any clinical procedure: sit face-to-face, instruments out of view, no clinical posturing. Ask directly: 'Has something happened at a dentist before that made you feel this way?' Listen without minimising. Then: 'What specifically are you most afraid of? The needle? The sound? Losing control?' Name it and address only that specific fear. Pinkham (5th Ed.): specific fear identification and graduated exposure is the evidence-based first-line for pre-teen dental phobia. N₂O 30–40% significantly reduces anxiety as pharmacological support. Refer for clinical psychology if severe phobia is preventing necessary care.",
        cultural: "Pre-teen dental phobia in India often has a specific trigger: a poorly managed extraction or pulpectomy at a local clinic, often without adequate LA. Indian children in this category have frequently had genuine painful experiences — their fear is rational, not unfounded. Never dismiss it as 'overreacting.' McDonald & Avery (10th Ed.): validated prior pain experience in children is the strongest predictor of adult dental phobia — this appointment is critically important.",
        techniques: ["Fear Identification (Direct)","Systematic Desensitisation","Tell-Show-Feel-Do","N₂O-O₂","Hand Signal + Control","Graduated Exposure Protocol","Referral to Psychology if Severe"],
        checklist: [
          "De-clinicalise the room before patient enters — instruments covered/hidden",
          "Sit face-to-face, eye level, no white coat if possible",
          "Ask specifically: what happened before? What exactly are you scared of?",
          "Establish hand signal before any clinical contact",
          "Do NOT attempt clinical procedure at first visit if Frankl 1 — desensitisation visit only",
          "N₂O 30–40% if consented before any procedure",
          "MDAS score (Modified Dental Anxiety Scale) — if >19, consider psychology referral"
        ],
        escalation: [
          { title: "Step 1: Desensitisation Visit Only", desc: "First visit: no clinical procedure. Build rapport. Identify fear. Show instruments. Stop there. Second visit: instrument contact on hand. Third: in mouth. Fourth: minor procedure." },
          { title: "Step 2: N₂O-O₂ 30–40%", desc: "Once rapport established — N₂O is transformative for pre-teen phobia. Explain: 'It makes you feel relaxed and floating — you stay awake and in full control.'" },
          { title: "Step 3: Oral Midazolam + LA", desc: "0.5 mg/kg (max 15 mg) for severe documented phobia with necessary treatment. SpO₂ monitoring mandatory. Informed consent documented." },
          { title: "Step 4: Refer", desc: "Clinical psychology / CBT referral if systemic dental phobia is preventing necessary care. AIIMS Delhi has a dental anxiety clinic. Referral pathway: HOD Pediatric Dentistry → Psychiatry liaison." }
        ],
        drugs: [
          { name: "N₂O-O₂", dose: "30–40% N₂O titration", note: "First pharmacological choice. Well tolerated, rapidly reversible." },
          { name: "Midazolam oral", dose: "0.5 mg/kg max 15 mg", note: "For definitive Frankl 1 with necessary treatment. SpO₂ monitoring." },
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Once sedation state achieved." }
        ],
        drugNote: "Pre-teen oral midazolam: document fully. Parental written consent mandatory. SpO₂ and HR monitoring for 30 min post-procedure. No food 2 hrs before. Recovery space and escort home required. Per DCI 2022: conscious sedation in children must be performed by trained personnel with resuscitation equipment available.",
        scriptEn: "[Name] — before we do anything, I want to understand what's happened before. I can tell this is really hard for you, and I respect that. Can you tell me: what's the worst part of being here? [Listen completely.] Thank you for telling me that. That's a completely valid reason to feel this way. Here's what we're going to do today — nothing you're afraid of. We're just going to talk and get to know each other. I won't touch your mouth unless you say it's okay. Deal?",
        scriptHi: "[नाम] — कुछ करने से पहले, मैं समझना चाहता/चाहती हूँ क्या हुआ था पहले। मैं देख सकता/सकती हूँ कि यह बहुत मुश्किल है, और मैं इसे respect करता/करती हूँ। बताओ: यहाँ आने में सबसे मुश్కिल क्या है? [पूरा सुनें।] Thank you। यह बिल्कुल valid reason है। आज क्या होगा — जो भी तुम्हें डर लगता है वो नहीं होगा। बस बात करेंगे। जब तक तुम न कहो, मुँह नहीं छूऊँगा/छूऊँगी। Deal?",
        scriptNote: "*For Frankl 1 pre-teen: the first visit should contain zero clinical procedure. The goal is trust-building only. This is not wasted time — it is the entire foundation of all future successful treatment.",
        parentTactics: "Brief parent separately and privately: 'Your child has significant dental anxiety — likely linked to a prior experience. This is a recognised clinical condition. Rushing treatment today will make future care impossible. We need 2–3 desensitisation visits before any procedure. I want to explain what we'll do and why.' For frustrated parents ('Just do the filling!'): 'Forcing a phobic child through treatment creates adult dental phobia — we have strong evidence for this. The graduated approach leads to better treatment outcomes. Please trust the process.'",
        failures: [
          "Attempting any clinical procedure at the first visit for a Frankl 1 pre-teen",
          "Dismissing the fear: 'You're almost a teenager — this is nothing'",
          "Involving parent in clinical room without agreement from pre-teen",
          "Not doing MDAS scoring — missing severe phobia that needs referral",
          "Using restraint of any kind — legally and ethically unacceptable in a non-urgent situation at this age"
        ],
        flagActions: "MDAS score >19: refer to psychology / psychiatry liaison. Document referral. Continue desensitisation in parallel. For urgent dental need (abscess, pain) in Frankl 1 pre-teen: N₂O + oral midazolam after consent, or refer to GA facility at a nearby dental hospital with GA capability. Congenital heart disease: antibiotic prophylaxis before any invasive procedure — do not defer for behavior alone."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    },
    positive: {
      restoration: buildRecord({
        success: "97%",
        duration: "25–30 min",
        durationTip: "Frankl 3 pre-teen: cooperative with factual explanation. Efficient clinical work preferred.",
        protocol: "Standard Adult-Style Protocol (Marwah Ch.12; McDonald & Avery Ch.18)",
        stratTitle: "Adult-Style Approach with Patient as Active Partner",
        stratDesc: "Frankl 3 pre-teens are nearly-adult cooperative patients. Brief them at adult level, work at clinical pace, give them autonomy and control. They accept LA, rubber dam, and standard procedures without special behavior management techniques. The main task is maintaining their cooperation by not boring them with over-explanation or patronising them with childish framing. Per McDonald & Avery (10th Ed.): positive pre-teen patients respond best to being treated as intelligent participants in their care — not passive recipients of procedures.",
        cultural: "Frankl 3 pre-teens from Indian educational backgrounds often have positive attitudes shaped by family — parents who attend dental care regularly. Reinforce this: 'Your attitude toward dental treatment is excellent — that's a real asset for your long-term health.' Praise is effective at this age when specific and genuine.",
        techniques: ["Direct Adult Communication","Standard LA Protocol","Full Transparency","Specific Genuine Praise","Efficient Work"],
        checklist: [
          "Standard LA: topical + infiltration + test",
          "Brief factual explanation of each step",
          "Offer music/distraction of their choice",
          "Specific functional praise: 'You held perfectly still through the injection'"
        ],
        escalation: [
          { title: "N₂O if Needed", desc: "Offer as option — 'some people find it makes the whole thing easier, others prefer without.' Let them decide." }
        ],
        drugs: [
          { name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard." }
        ],
        drugNote: "No sedation needed for Frankl 3 pre-teen. Standard LA protocol.",
        scriptEn: "Ready [name]? Procedure today: [name it]. I'll explain each step. Standard LA first — gel, then injection. You'll feel pressure for 30 seconds. After that: nothing from the tooth. Left hand if you need a break. Questions? Great — let's go.",
        scriptHi: "तैयार [नाम]? आज [procedure]। हर step बताऊँगा। Standard LA — gel, फिर injection, 30 second pressure। उसके बाद कुछ नहीं। Break चाहिए तो बाया हाथ। सवाल? बढ़िया — चलते हैं।",
        scriptNote: "*Direct and efficient. Frankl 3 pre-teens do not need extended rituals.",
        parentTactics: "Parent in waiting room. Child leads consent discussion. Brief parent at end.",
        failures: [
          "Over-managing a cooperative pre-teen — condescending",
          "Skipping LA because 'they seem fine' — never acceptable"
        ],
        flagActions: "Standard flags apply. MIH: warn before air on hypomineralised surface. Document findings."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    },
    definitely_positive: {
      restoration: buildRecord({
        success: "99%",
        duration: "20–25 min",
        durationTip: "Fastest, most efficient pre-teen cohort. Maximise clinical output. They are assets to your schedule.",
        protocol: "Direct Clinical Approach (Marwah Ch.12; Pinkham 5th Ed.)",
        stratTitle: "Direct, Efficient, Mutual Respect",
        stratDesc: "Definitely positive pre-teens are among the most pleasant patients in pediatric dentistry. They are curious, cooperative, and often interested in their own dental care. Treat them as intelligent partners. Brief procedure in one sentence. Work efficiently. Answer any questions they have with genuine medical accuracy. They often ask good questions: 'Why is my tooth black there?' 'Will the filling last forever?' 'Is that a real diamond bur?' Answer accurately — they retain this information and it builds lifelong dental literacy. Per Pinkham (5th Ed.): definitely positive adolescent patients who receive respectful, accurate communication from their dentist show the highest rates of adult dental attendance.",
        cultural: "Indian definitely-positive pre-teens often aspire to health professions. Dental curiosity is common: 'Can I see the X-ray?' 'What's that instrument called?' Engage with this — show them the radiograph, explain what you see. This turns a routine appointment into an educational experience and builds a long-term patient-practitioner relationship. These children may become future dental professionals in 10 years.",
        techniques: ["Direct Approach","Full Clinical Accuracy","Answer Questions Genuinely","Educational Engagement","Efficient Work"],
        checklist: [
          "Introduce yourself and greet as a peer",
          "Standard LA — never skip",
          "Answer any questions accurately and fully",
          "Show radiograph if available — brief them on findings",
          "At close: oral health advice in adult language"
        ],
        escalation: [],
        drugs: [{ name: "Lignocaine 2% + Adr", dose: "4.4 mg/kg", note: "Standard." }],
        drugNote: "No sedation. Standard LA. Efficient visit.",
        scriptEn: "Hi [name] — good to see you. [Procedure] today — about 20 minutes. Standard: gel, injection, wait, work. You know the routine. Any questions before we start? [Answer fully if asked.] Great — open please.",
        scriptHi: "हाय [नाम] — अच्छा लगा मिलकर। आज [procedure] — 20 minute। Standard: gel, injection, wait, work। कोई सवाल? [पूरा answer करें।] बढ़ियা — खोलो।",
        scriptNote: "*Brevity and respect. The definitely positive pre-teen's time is as valuable as yours.",
        parentTactics: "Parent in waiting room. This patient runs their own appointment. Debrief parent at end with pre-teen present — all three in the conversation together.",
        failures: [
          "Patronising a definitely-positive pre-teen with baby scripts",
          "Ignoring their questions — missed opportunity and missed trust",
          "Skipping LA because cooperative"
        ],
        flagActions: "All standard flags. MIH found: excellent opportunity for patient education — they will understand and engage with the EAPD severity grading and treatment rationale."
      }),
      xray: buildRecord({
        success: "90%",
        duration: "5-10 min",
        steps: [
          "TSD: show sensor/film on parent finger first",
          "Place lead apron and thyroid collar before exposure",
          "Use child-sized XCP holder or bite-block",
          "Start with bite-wing before periapical",
          "Positive reinforcement after each film",
          "Defer non-urgent views if child refuses — document in notes"
        ],
        drugs: "Routine radiograph: no premedication needed. Exception (critical view, extreme refusal): Hydroxyzine 0.5-1 mg/kg oral 45-60 min prior (max 50 mg) — Marwah 5th Ed.",
        parentScript: "We are taking a quick picture of the teeth. The small piece sits on the back teeth for just a few seconds. It will feel a little funny but will not hurt at all.",
        parentScriptHi: "Hum daanton ki ek jaldi si tasveer lenge. Yeh chota sa piece sirf kuch seconds ke liye rakha jayega. Thodi ajeeb lagega par dard bilkul nahi hoga.",
        clinicalFlags: [
          "Confirm lead apron and thyroid collar placed before exposure",
          "Use paediatric kVp/mA settings",
          "Document films attempted vs completed",
          "If refused: note in record, reattempt next visit",
          "Radiation dose 2 bitewings 0.005 mSv — safe to reassure parent"
        ],
        flagActions: ["defer_if_refused", "document_refusal", "reassure_parent_radiation_safe"]
      })
    }
  }
};

// ═══════════════════════════════════════════════════════════════
// EMERGENCY & TRAUMA MATRIX DATA
// ═══════════════════════════════════════════════════════════════
// This data provides clinical workflows, drug calculations, and parent
// scripts for 15 emergency/trauma situations that were returning empty
// strings in the main matrix lookup system.
// Sources: Marwah 5th Ed., Tandon 3rd Ed., Andreasen Traumatic Dental
// Injuries 3rd Ed., AAPD Guidelines 2024, DCI Emergency Protocols 2022
// ═══════════════════════════════════════════════════════════════

const emergencyMatrixData = {
  // CATEGORY A: DENTAL TRAUMA PROTOCOLS
  "avulsion_permanent_tooth": {
    clinicalWorkflow: "1. Verify extra-oral dry time (<60 mins = high prognosis; >60 mins = poor prognosis).\n2. Handle tooth by crown only; do not touch root surface.\n3. Flush root socket with sterile saline.\n4. Replant tooth gently under manual pressure.\n5. Apply flexible splint (Orthodontic wire/Composite) for 2 weeks per Marwah 5th Ed.",
    drugCalculation: "Amoxicillin: 20-40 mg/kg/day divided every 8 hours. Paracetamol: 10-15 mg/kg every 4-6 hours PRN.",
    parentScript: "Explain the critical risk of ankylosis and external root resorption. Emphasize strict soft diet compliance for 2 weeks and meticulous oral hygiene."
  },
  "avulsion_primary_tooth": {
    clinicalWorkflow: "1. DO NOT REPLANT (high risk of damaging underlying permanent tooth bud per Tandon 3rd Ed).\n2. Clinically and radiographically evaluate socket to rule out complete intrusion or root fractures.\n3. Achieve hemostasis with direct gauze pressure.",
    drugCalculation: "Paracetamol: 10-15 mg/kg every 4-6 hours PRN for pain management.",
    parentScript: "Reassure parents that primary tooth avulsions are left un-replanted to protect the permanent successor. Discuss future space maintainer evaluation if necessary."
  },
  "intrusion_permanent_tooth": {
    clinicalWorkflow: "1. Determine degree of intrusion radiographically.\n2. Intrusion < 3mm: Await spontaneous re-eruption.\n3. Intrusion 3-7mm: Surgical or orthodontic repositioning.\n4. Intrusion > 7mm: Immediate surgical repositioning and initiation of endodontic therapy within 2 weeks.",
    drugCalculation: "Ibuprofen: 5-10 mg/kg every 6-8 hours. Amoxicillin coverage indicated if soft tissue lacerations exist.",
    parentScript: "Inform parents that pulp necrosis occurs in up to 96% of mature intruded teeth. Long-term monitoring via recall visits is mandatory."
  },
  "intrusion_primary_tooth": {
    clinicalWorkflow: "1. Take a 90-degree occlusal radiograph to verify root direction.\n2. If root apex is displaced labially (away from permanent tooth bud): Await spontaneous re-eruption (2-3 months).\n3. If root apex is displaced palatally (towards permanent bud): Extract immediately to prevent development defects.",
    drugCalculation: "Paracetamol: 10-15 mg/kg every 4-6 hours.",
    parentScript: "Explain that the main clinical goal is protecting the underlying permanent tooth. Regular radiographic follow-ups are required to track re-eruption."
  },
  "subluxation_injury": {
    clinicalWorkflow: "1. Diagnose by increased mobility without displacement.\n2. Check for gingival crevice bleeding.\n3. Monitor pulp vitality. No splinting required unless mobility is severe.\n4. Soft diet instruction for 1-2 weeks.",
    drugCalculation: "Paracetamol: 10-15 mg/kg every 4-6 hours PRN.",
    parentScript: "Advise parents to watch for signs of pulp necrosis, such as tooth discoloration, swelling, or a recurring gum boil."
  },
  "crown_root_fracture_exposed_pulp": {
    clinicalWorkflow: "1. Evaluate restorability.\n2. If restorable and vital pulp (immature root): Perform Partial Pulpotomy (Cvek Pulpotomy) using MTA or Biodentine.\n3. If non-vital or unrestorable: Perform extraction or complete pulpectomy based on root development status.",
    drugCalculation: "Amoxicillin: 20-40 mg/kg/day. Ibuprofen: 5-10 mg/kg every 6-8 hours.",
    parentScript: "Detail the treatment path. Explain that maintaining root development (apexogenesis) is critical for tooth survival."
  },
  
  // CATEGORY B: ACUTE OROFACIAL SPACE INFECTIONS
  "acute_canine_space_infection": {
    clinicalWorkflow: "1. Identify source tooth (usually primary canine/maxillary incisor).\n2. Establish drainage immediately through pulp extirpation or extra-oral/intra-oral incision.\n3. Monitor for eyelid closure or loss of nasolabial fold.",
    drugCalculation: "Amoxicillin + Clavulanic Acid (Augmentin): 30-40 mg/kg/day divided into 3 doses. Ibuprofen for pain.",
    parentScript: "Urgent Warning: If swelling spreads to the eye or causes severe lethargy, proceed immediately to the nearest pediatric emergency department."
  },
  "buccal_space_cellulitis": {
    clinicalWorkflow: "1. Assess facial asymmetry, trismus, and skin erythema.\n2. Initiate immediate antibiotic therapy.\n3. Perform extraction or pulpectomy of the causative primary molar to establish patency and drain the infection.",
    drugCalculation: "Augmentin: 40 mg/kg/day divided every 8 hours. Metronidazole: 15-30 mg/kg/day if anaerobic coverage is indicated.",
    parentScript: "Explain that antibiotics control the spread, but physical treatment of the causative tooth is required to clear the infection permanently."
  },
  "submandibular_space_infection": {
    clinicalWorkflow: "1. Evaluate airway patency and check for elevation of the tongue.\n2. Secure prompt intra-oral/extra-oral surgical drainage.\n3. Maintain aggressive hydration therapy protocols.",
    drugCalculation: "Empiric aggressive antibiotic coverage: Augmentin combined with Metronidazole at appropriate pediatric bodyweight ratios.",
    parentScript: "CRITICAL: Monitor breathing closely. Any difficulty swallowing or changes in speech require emergency hospitalization."
  },
  "acute_periapical_abscess_systemic": {
    clinicalWorkflow: "1. Diagnose via localized fluctuant swelling with fever (>38.5°C) or lymphadenopathy.\n2. Perform immediate intra-oral incision for drainage or extract the causative primary tooth.\n3. Debride necrotic debris under copious irrigation.",
    drugCalculation: "Amoxicillin: 40 mg/kg/day. Paracetamol: 15 mg/kg every 4 hours for pyrexia control.",
    parentScript: "Emphasize completion of the entire antibiotic course, even if facial swelling subsides rapidly within 24-48 hours."
  },
  "ludwigs_angina_early_referral": {
    clinicalWorkflow: "1. Recognize symptoms: Bilateral firm, indurated swelling of submandibular, sublingual, and submental spaces.\n2. High risk of immediate airway compromise.\n3. ADMINISTER INITIAL DOSE OF ANTIBIOTICS AND REFER IMMEDIATELY TO AN ORAL SURGEON / MULTI-SPECIALTY HOSPITAL.",
    drugCalculation: "Immediate stat emergency dose based on weight. Do not delay transport for calculated prescriptions.",
    parentScript: "Emergency briefing: This is a fast-spreading facial infection that threatens the child's airway. Immediate specialized inpatient care is required."
  },
  
  // CATEGORY C: EMERGENCY SEDATION, MEDICATION RESCUE & LACERATIONS
  "acute_irreversible_pulpitis_emergency": {
    clinicalWorkflow: "1. Isolate tooth using a rubber dam.\n2. Perform immediate emergency pulp extirpation (access opening and coronal tissue removal).\n3. Place a sterile cotton pellet dampened with non-phenolic medicament.\n4. Seal with high-quality temporary dressing (Cavit).",
    drugCalculation: "Ibuprofen: 10 mg/kg stat for immediate relief of acute dental pain.",
    parentScript: "Explain that removing the hot nerve provides immediate relief. Schedule the follow-up appointment within 7 days to complete the pulpectomy line."
  },
  "midazolam_sedation_emergency_rescue": {
    clinicalWorkflow: "1. Stop dental treatment immediately.\n2. Assess airway, breathing, and circulation (ABCs).\n3. If respiratory depression occurs: Maintain open airway via jaw-thrust; administer 100% supplemental oxygen.\n4. Administer Flumazenil (Antidote): 0.01 mg/kg intravenously if IV line is patent.",
    drugCalculation: "Emergency Flumazenil dosing matrix: 0.01 mg/kg. Max single dose 0.2mg.",
    parentScript: "Explain calmly to the parent that the child is experiencing an extended reaction to the sedative, and standard recovery safety steps are actively being managed."
  },
  "anaphylactic_shock_chairside_protocol": {
    clinicalWorkflow: "1. Place patient in supine position with legs elevated.\n2. Call for emergency medical services immediately.\n3. Administer 1:1000 Epinephrine (Adrenaline) intramuscularly (IM) into anterolateral thigh.\n4. Dosing: <6 years: 0.15 mg; 6-12 years: 0.30 mg.",
    drugCalculation: "Epinephrine 1:1000 IM injection. Maintain oxygen saturation >95% via high-flow mask.",
    parentScript: "Inform the parent that an acute allergic reaction has occurred, an antidote has been administered, and emergency medical personnel are en route for monitoring."
  },
  "traumatic_soft_tissue_laceration": {
    clinicalWorkflow: "1. Cleanse tissue margins thoroughly with saline to clear debris.\n2. Achieve local hemostasis via direct compression.\n3. Evaluate depth: Superficial mucosal cuts require no sutures. Deep lacerations require closure using 4-0 or 5-0 resorbable materials.",
    drugCalculation: "Paracetamol for pain management. Topical antiseptic gel application 3 times daily.",
    parentScript: "Instruct parents to monitor for secondary infections. Ensure soft foods are served and caution against accidental lip/cheek biting while local anesthesia remains active."
  }
};

// ─── HELPER FUNCTIONS ──────────────────────────────────────────
function buildRecord(r) { return r; }

function getFallback(ageGroup, behavior, procedure) {
  // ═══════════════════════════════════════════════════════════════
  // PRIORITY 1: Check Emergency Matrix Data FIRST
  // ═══════════════════════════════════════════════════════════════
  if (emergencyMatrixData[procedure]) {
    const emergencyData = emergencyMatrixData[procedure];
    
    // Build a standardized record from emergency data
    const emergencyRecord = {
      success: "Emergency Protocol",
      duration: "Variable — depends on clinical presentation",
      durationTip: "Emergency protocols require immediate assessment and intervention.",
      protocol: emergencyData.clinicalWorkflow || "Emergency protocol",
      stratTitle: "Emergency/Trauma Protocol",
      stratDesc: emergencyData.clinicalWorkflow || "",
      cultural: "Emergency situations require immediate intervention and clear parent communication.",
      techniques: ["Emergency Assessment", "Immediate Intervention", "Parent Communication"],
      checklist: emergencyData.clinicalWorkflow ? emergencyData.clinicalWorkflow.split('\n').filter(s => s.trim()) : [],
      escalation: [
        { title: "Immediate Assessment", desc: "Evaluate severity and urgency." },
        { title: "Emergency Intervention", desc: emergencyData.clinicalWorkflow || "Follow emergency protocol." }
      ],
      drugs: [],
      drugNote: emergencyData.drugCalculation || "Emergency dosing based on weight.",
      scriptEn: emergencyData.parentScript || "This is an emergency. I will explain the immediate steps.",
      scriptHi: "यह एक emergency है। मैं तुरंत के steps बताऊँगा/बताऊँगी।",
      scriptNote: "*Emergency communication: Clear, direct, calm.",
      parentTactics: emergencyData.parentScript || "Emergency briefing: explain urgency clearly.",
      failures: ["Delaying intervention", "Inadequate parent communication"],
      flagActions: "All medical flags apply with elevated urgency."
    };
    
    return { record: emergencyRecord, usedFallback: false, fallbackAge: null, isEmergency: true };
  }
  
  // ═══════════════════════════════════════════════════════════════
  // PRIORITY 2: Standard Age/Behavior Matrix Lookup
  // ═══════════════════════════════════════════════════════════════
  let usedFallback = false;
  let fallbackAge = null;
  
  const age = INDIA_MATRIX[ageGroup];
  if (!age) {
    usedFallback = true;
    fallbackAge = 'preschool';
    return { record: INDIA_MATRIX['preschool']['negative']['restoration'], usedFallback, fallbackAge };
  }
  
  const beh = age[behavior] || age['negative'] || age[Object.keys(age)[0]];
  if (!beh) {
    usedFallback = true;
    fallbackAge = 'preschool';
    return { record: INDIA_MATRIX['preschool']['negative']['restoration'], usedFallback, fallbackAge };
  }
  
  const record = beh[procedure] || beh['restoration'] || beh[Object.keys(beh)[0]] || INDIA_MATRIX['preschool']['negative']['restoration'];
  
  // Check if we had to use a fallback procedure
  if (!beh[procedure]) {
    usedFallback = true;
    fallbackAge = ageGroup; // Using same age group but different procedure
  }
  
  return { record, usedFallback, fallbackAge };
}

// ─── SETTINGS ───────────────────────────────────────────────────
const PROVIDER_META = {
  offline: {
    badge: '<span class="provider-badge offline"><i class="fa-solid fa-database"></i> No internet required</span>',
    keyLabel: '', keyPlaceholder: '', keyHint: ''
  },
  google: {
    badge: '<span class="provider-badge free"><i class="fa-solid fa-circle-check"></i> Free tier available</span>',
    keyLabel: 'Google AI Studio Key',
    keyPlaceholder: 'AIza...',
    keyHint: 'Get a free key at aistudio.google.com — no credit card needed.'
  },
  qwen: {
    badge: '<span class="provider-badge free"><i class="fa-solid fa-circle-check"></i> 1M free tokens/month (3 mo)</span>',
    keyLabel: 'Alibaba DashScope Key',
    keyPlaceholder: 'sk-...',
    keyHint: 'Sign up at dashscope.aliyuncs.com — international endpoint used.'
  },
  anthropic: {
    badge: '<span class="provider-badge paid"><i class="fa-solid fa-credit-card"></i> Paid — charged per token</span>',
    keyLabel: 'Anthropic API Key',
    keyPlaceholder: 'sk-ant-...',
    keyHint: 'Get your key at console.anthropic.com. Usage billed per token.'
  }
};

function toggleApiInput() {
  const p = document.getElementById('apiProvider').value;
  const meta = PROVIDER_META[p] || PROVIDER_META.offline;
  const wrapper = document.getElementById('apiKeyWrapper');
  document.getElementById('providerHint').innerHTML = meta.badge;
  if (p === 'offline') {
    wrapper.style.display = 'none';
  } else {
    wrapper.style.display = 'flex';
    document.getElementById('apiKeyLabel').textContent = meta.keyLabel;
    document.getElementById('apiKey').placeholder = meta.keyPlaceholder;
    document.getElementById('apiKeyHint').textContent = meta.keyHint;
  }
}

// ─── STATE ──────────────────────────────────────────────────────
let state = {
  provider: localStorage.getItem('pp_provider') || 'offline',
  apiKey: localStorage.getItem('pp_key') || ''
};
document.getElementById('apiProvider').value = state.provider;
document.getElementById('apiKey').value = state.apiKey;
toggleApiInput(); // sets hint + shows/hides key wrapper on load

// ─── UPDATE PROCEDURES BY AGE ───────────────────────────────────
function updateProcedures() {
  const age = document.getElementById('ageGroup').value;
  const proc = document.getElementById('procedure');
  const current = proc.value;

  const options = {
    infant: [
      { value: 'exam', label: 'Examination / Oral Health Assessment' },
      { value: 'sdf', label: 'SDF / Fluoride Application' },
      { value: 'extraction', label: 'Natal/Neonatal Tooth Extraction' }
    ],
    toddler: [
      { value: 'exam', label: 'Examination / Prophylaxis' },
      { value: 'restoration', label: 'Restoration (GIC/Composite)' },
      { value: 'extraction', label: 'Extraction' },
      { value: 'sdf', label: 'SDF / ART' }
    ],
    preschool: [
      { value: 'exam', label: 'Examination / Prophylaxis' },
      { value: 'restoration', label: 'Restoration (GIC/Composite)' },
      { value: 'pulpectomy', label: 'Pulpectomy / Pulpotomy' },
      { value: 'extraction', label: 'Extraction' },
      { value: 'sdf', label: 'SDF / ART' },
      { value: 'spacemaintainer', label: 'Space Maintainer' },
      { value: 'xray', label: 'Radiograph' }
    ],
    schoolage: [
      { value: 'exam', label: 'Examination / Prophylaxis' },
      { value: 'restoration', label: 'Restoration (GIC/Composite)' },
      { value: 'pulpectomy', label: 'Pulpectomy / Pulpotomy' },
      { value: 'extraction', label: 'Extraction' },
      { value: 'sdf', label: 'SDF / ART' },
      { value: 'spacemaintainer', label: 'Space Maintainer' },
      { value: 'xray', label: 'Radiograph' }
    ],
    preteen: [
      { value: 'exam', label: 'Examination / Prophylaxis' },
      { value: 'restoration', label: 'Restoration (GIC/Composite)' },
      { value: 'extraction', label: 'Extraction' },
      { value: 'xray', label: 'Radiograph' },
      { value: 'spacemaintainer', label: 'Space Maintainer' }
    ]
  };

  const list = options[age] || options['preschool'];
  proc.innerHTML = list.map(o =>
    `<option value="${o.value}"${o.value === current ? ' selected' : ''}>${o.label}</option>`
  ).join('');
}
// Run once on load to match default age group
updateProcedures();
function selectRadio(el, name, value) {
  document.querySelectorAll(`input[name="${name}"]`).forEach(r => {
    r.closest('.radio-card')?.classList.remove('selected');
  });
  el.classList.add('selected');
  el.querySelector('input[type="radio"]').checked = true;
}

// ─── MODAL ──────────────────────────────────────────────────────
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal-bg').forEach(m => {
  m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); });
});

// ─── TABS ───────────────────────────────────────────────────────
const MOBILE_TAB_META = {
  'tab-strategy': { label: 'Strategy', index: 1, total: 7 },
  'tab-escalation': { label: 'Escalation Ladder', index: 2, total: 7 },
  'tab-drugs': { label: 'Drug Reference', index: 3, total: 7 },
  'tab-parent': { label: 'Parent Script', index: 4, total: 7 },
  'tab-flags': { label: 'Clinical Flags', index: 5, total: 7 },
  'tab-chairscript': { label: 'Bilingual Parent Kit', index: 6, total: 7 },
  'tab-parentkit': { label: 'Parent Kit', index: 7, total: 7 }
};

function updateMobilePanelChrome(id) {
  const meta = MOBILE_TAB_META[id];
  if (!meta) return;
  const label = document.getElementById('mobilePanelLabel');
  const count = document.getElementById('mobilePanelCount');
  if (label) label.textContent = meta.label;
  if (count) count.textContent = `${meta.index} / ${meta.total}`;
  document.querySelectorAll('#mobilePanelDots .mobile-dot').forEach((dot, index) => {
    dot.classList.toggle('active', index === meta.index - 1);
  });
  document.querySelectorAll('#outputState .tabs.no-print .tab[data-tab]').forEach(tab => {
    tab.classList.toggle('active', tab.dataset.tab === id);
  });
}

function showTab(id, element) {
  document.querySelectorAll('#outputState .tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('#outputState .tab').forEach(t => {
    t.classList.remove('active');
    t.classList.remove('tab-special');
  });
  document.getElementById(id)?.classList.add('active');
  if (element) {
    element.classList.add('active');
    // Add tab-special class to Parent Kit tab
    if (element.dataset.tab === 'tab-parentkit') {
      element.classList.add('tab-special');
    }
  }
  updateMobilePanelChrome(id);
  if (id === 'tab-drugs') {
    const wt = parseFloat(document.getElementById('childWeight')?.value);
    if (wt && wt >= 3 && wt <= 60) {
      setTimeout(() => highlightDrugTables(wt), 50);
    }
  }
  if (window.matchMedia('(max-width: 640px)').matches) {
    const shell = document.querySelector('.tab-panels-shell');
    const panel = document.getElementById(id);
    if (shell && panel) {
      shell.scrollTo({ left: panel.offsetLeft, behavior: 'smooth' });
    }
  }
}
function showRefTab(id, element) {
  document.querySelectorAll('#refModal .tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('#refModal .tab').forEach(t => t.classList.remove('active'));
  document.getElementById(id)?.classList.add('active');
  if (element) element.classList.add('active');
}

function syncMobilePanelFromScroll() {
  const shell = document.querySelector('.tab-panels-shell');
  if (!shell || !window.matchMedia('(max-width: 640px)').matches) return;
  const panels = Array.from(shell.querySelectorAll('.tab-panel'));
  if (!panels.length) return;
  const shellRect = shell.getBoundingClientRect();
  let bestPanel = panels[0];
  let bestVisible = -1;
  for (const panel of panels) {
    const rect = panel.getBoundingClientRect();
    const visible = Math.max(0, Math.min(rect.right, shellRect.right) - Math.max(rect.left, shellRect.left));
    if (visible > bestVisible) {
      bestVisible = visible;
      bestPanel = panel;
    }
  }
  if (bestPanel?.id) updateMobilePanelChrome(bestPanel.id);
}

// ─── WEIGHT-BASED DRUG CALCULATOR ──────────────────────────────────────────
function initWeightCalculator() {
  const weightInput = document.getElementById('childWeight');
  if (!weightInput) return;

  // Load saved weight from localStorage
  const savedWeight = localStorage.getItem('pp_childWeight');
  if (savedWeight) {
    weightInput.value = savedWeight;
    highlightDrugTables(parseFloat(savedWeight));
  }

  // Listen for weight input changes
  weightInput.addEventListener('input', function() {
    const weight = parseFloat(this.value);
    if (weight && weight >= 3 && weight <= 60) {
      localStorage.setItem('pp_childWeight', weight);
      highlightDrugTables(weight);
    } else {
      clearDrugHighlights();
    }
  });

  // Copy button handler
  document.getElementById('btnCopyDoses')?.addEventListener('click', copyAllDoses);
}

function highlightDrugTables(weight) {
  const tables = ['tblAmox', 'tblCefad', 'tblMetro', 'tblPara', 'tblIbupro'];
  const drugNames = {
    'tblAmox': 'Amoxicillin + Clavulanic Acid',
    'tblCefad': 'Cefadroxil',
    'tblMetro': 'Metronidazole',
    'tblPara': 'Paracetamol',
    'tblIbupro': 'Ibuprofen'
  };
  
  const matches = {};
  
  tables.forEach(tableId => {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const rows = table.querySelectorAll('tbody tr');
    let foundMatch = false;
    
    rows.forEach(row => {
      const min = parseFloat(row.dataset.min);
      const max = parseFloat(row.dataset.max);
      
      if (weight >= min && weight < max) {
        // Highlight matching row
        row.style.background = 'var(--amber-bg)';
        row.style.borderLeft = '3px solid var(--amber)';
        row.style.opacity = '1';
        
        // Add checkmark icon to first cell
        const firstCell = row.querySelector('td:first-child');
        if (firstCell && !firstCell.querySelector('.weight-check')) {
          const check = document.createElement('i');
          check.className = 'fa-solid fa-circle-check weight-check';
          check.style.cssText = 'color:var(--green);margin-right:5px;font-size:11px;';
          firstCell.insertBefore(check, firstCell.firstChild);
        }
        
        // Extract dose info for summary
        const cells = row.querySelectorAll('td');
        if (cells.length >= 3) {
          matches[tableId] = {
            name: drugNames[tableId],
            dose: cells[1].textContent.trim(),
            frequency: cells[2].textContent.trim()
          };
        }
        
        foundMatch = true;
      } else {
        // Dim non-matching rows
        row.style.background = '';
        row.style.borderLeft = '';
        row.style.opacity = '0.4';
        
        // Remove checkmark if exists
        const check = row.querySelector('.weight-check');
        if (check) check.remove();
      }
    });
  });
  
  // Update summary strip
  updateDosageSummary(weight, matches);
}

function clearDrugHighlights() {
  const tables = ['tblAmox', 'tblCefad', 'tblMetro', 'tblPara', 'tblIbupro'];
  
  tables.forEach(tableId => {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
      row.style.background = '';
      row.style.borderLeft = '';
      row.style.opacity = '1';
      
      const check = row.querySelector('.weight-check');
      if (check) check.remove();
    });
  });
  
  // Hide summary
  document.getElementById('dosageSummary').style.display = 'none';
  localStorage.removeItem('pp_childWeight');
}

function updateDosageSummary(weight, matches) {
  const summary = document.getElementById('dosageSummary');
  const summaryWeight = document.getElementById('summaryWeight');
  const summaryContent = document.getElementById('summaryContent');
  
  if (!summary || Object.keys(matches).length === 0) {
    summary.style.display = 'none';
    return;
  }
  
  summaryWeight.textContent = weight;
  
  // Build summary content - focus on the 4 main drugs
  const mainDrugs = ['tblAmox', 'tblMetro', 'tblPara', 'tblIbupro'];
  let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">';
  
  mainDrugs.forEach(tableId => {
    if (matches[tableId]) {
      const m = matches[tableId];
      html += `<div style="font-size:11px;">
        <strong style="color:var(--text);">${m.name}:</strong>
        <div style="font-family:var(--mono);color:var(--green);margin-top:2px;">${m.dose} — ${m.frequency}</div>
      </div>`;
    }
  });
  
  html += '</div>';
  summaryContent.innerHTML = html;
  summary.style.display = 'block';
}

function copyAllDoses() {
  const weight = document.getElementById('childWeight').value;
  if (!weight) {
    toast('No weight entered');
    return;
  }
  
  // Get all highlighted doses
  const tables = [
    { id: 'tblAmox', name: 'Amoxicillin + Clavulanic Acid' },
    { id: 'tblMetro', name: 'Metronidazole' },
    { id: 'tblPara', name: 'Paracetamol' },
    { id: 'tblIbupro', name: 'Ibuprofen' }
  ];
  
  let text = `Pediatric Drug Doses for ${weight}kg Child:\n\n`;
  
  tables.forEach(table => {
    const tableEl = document.getElementById(table.id);
    if (!tableEl) return;
    
    const highlightedRow = Array.from(tableEl.querySelectorAll('tbody tr'))
      .find(row => row.style.borderLeft);
    
    if (highlightedRow) {
      const cells = highlightedRow.querySelectorAll('td');
      if (cells.length >= 3) {
        text += `${table.name}\n`;
        text += `Dose: ${cells[1].textContent.trim()}\n`;
        text += `Frequency: ${cells[2].textContent.trim()}\n\n`;
      }
    }
  });
  
  text += '---\nAlways confirm with current BNFc or hospital formulary.';
  
  navigator.clipboard.writeText(text).then(() => {
    toast('📋 All doses copied to clipboard!');
  }).catch(err => {
    console.error('Clipboard error:', err);
    toast('Failed to copy');
  });
}

window.addEventListener('load', () => {
  updateMobilePanelChrome(document.querySelector('#outputState .tab-panel.active')?.id || 'tab-strategy');
  const shell = document.querySelector('.tab-panels-shell');
  if (shell) shell.addEventListener('scroll', syncMobilePanelFromScroll, { passive: true });
  
  // Initialize weight calculator
  initWeightCalculator();
});

function saveApiSettings() {
  state.provider = document.getElementById('apiProvider').value;
  state.apiKey = document.getElementById('apiKey').value.trim();
  localStorage.setItem('pp_provider', state.provider);
  localStorage.setItem('pp_key', state.apiKey);
  closeModal('settingsModal');
  toast('Settings saved.');
}

// ─── TOAST ──────────────────────────────────────────────────────
function toast(msg) {
  const el = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2800);
}

// ─── COPY ───────────────────────────────────────────────────────
function copyParentScript() {
  const en = document.getElementById('outParentScriptEn').textContent.trim();
  const hi = document.getElementById('outParentScriptHi').textContent.trim();
  const txt = `[English]\n${en}\n\n[Hindi]\n${hi}`;
  navigator.clipboard.writeText(txt).then(() => {
    toast('Both scripts copied to clipboard!');
  }).catch(err => {
    console.error('Clipboard error:', err);
    toast('Failed to copy to clipboard');
  });
}

// ─── GENERATE ───────────────────────────────────────────────────
async function generatePlan(e) {
  try {
    e.preventDefault();
    const patientName = document.getElementById('patientName').value;
    const ageGroup = document.getElementById('ageGroup').value;
    const procedure = document.getElementById('procedure').value;
    const behavior = document.querySelector('input[name="behavior"]:checked');
    if (!behavior) { toast('Please select a behavior profile'); return; }
    
    const parentProfile = document.getElementById('parentProfile').value;
    const visitHistory = document.getElementById('visitHistory').value;
    const flags = [...document.querySelectorAll('input[name="flag"]:checked')].map(f => f.value);

    // Hide any previous error
    document.getElementById('aiErrorDisplay').style.display = 'none';

    // Disable button and show loading state
    const generateBtn = document.getElementById('generateBtn');
    const btnText = document.getElementById('generateBtnText');
    const originalText = btnText.textContent;
    generateBtn.disabled = true;
    generateBtn.style.opacity = '0.6';
    generateBtn.style.cursor = 'not-allowed';
    btnText.innerHTML = '<i class="fa-solid fa-spinner fa-spin" style="margin-right:6px;"></i> Generating...';

    // Show loading
    document.getElementById('emptyState').style.display = 'none';
    document.getElementById('outputState').style.display = 'none';
    document.getElementById('loadingState').style.display = 'block';
    
    // Scroll to loading state on mobile
    document.getElementById('loadingState').scrollIntoView({ behavior: 'smooth' });

    const bar = document.getElementById('progressBar');
    bar.style.width = '0%';
    const loadMsgs = ['Matching behavior profile...','Loading clinical matrix...','Applying Indian cultural context...','Preparing parent scripts...'];
    let step = 0;
    const interval = setInterval(() => {
      step++;
      bar.style.width = `${step * 25}%`;
      if (step < loadMsgs.length) document.getElementById('loadingMsg').textContent = loadMsgs[step];
      if (step >= 4) clearInterval(interval);
    }, 300);

    await new Promise(r => setTimeout(r, 1400));
    clearInterval(interval);

    if (state.provider !== 'offline' && state.apiKey.trim()) {
      try {
        // FIXED: Invokes the unified multi-provider router instead of old callClaudeApi
        await callAiEngine(patientName, ageGroup, procedure, behavior.value, parentProfile, visitHistory, flags);
        
        // Success - clear any errors
        document.getElementById('aiErrorDisplay').style.display = 'none';
        
      } catch(err) {
        console.error('AI Engine Error:', err);
        
        // Build user-friendly error message
        let errorMsg = '';
        const errStr = err.message || err.toString();
        
        if (errStr.includes('401') || errStr.includes('authentication') || errStr.includes('api key')) {
          errorMsg = 'Invalid API key — please check your key in Settings and try again.';
        } else if (errStr.includes('429') || errStr.includes('rate limit')) {
          errorMsg = 'Rate limit exceeded — your API key has reached its limit. Try again later or use a different key.';
        } else if (errStr.includes('network') || errStr.includes('fetch') || errStr.includes('Failed to fetch')) {
          errorMsg = 'Network error — please check your internet connection and try again.';
        } else if (errStr.includes('timeout')) {
          errorMsg = 'Request timeout — the AI service took too long to respond. Please try again.';
        } else if (errStr.includes('No response') || errStr.includes('undefined')) {
          errorMsg = 'No response received from AI service — please try again.';
        } else {
          errorMsg = 'AI service error: ' + errStr.substring(0, 100);
        }
        
        // Display error visibly to user
        document.getElementById('aiErrorMessage').textContent = errorMsg;
        document.getElementById('aiErrorDisplay').style.display = 'block';
        
        // Also show toast for quick notification
        toast('AI call failed — using offline matrix.');
        
        // Fallback to offline matrix
        const fallbackResult = getFallback(ageGroup, behavior.value, procedure);
        const record = (typeof fallbackResult === 'object' && fallbackResult.record) ? fallbackResult.record : fallbackResult;
        const usedFallback = fallbackResult.usedFallback || false;
        const fallbackAge = fallbackResult.fallbackAge || null;
        renderPlan(record, patientName, ageGroup, procedure, behavior.value, parentProfile, visitHistory, flags, usedFallback, fallbackAge);
      }
    } else {
      // FIXED: Standardized fallback parameter signatures to prevent UI data leaking
      const fallbackResult = getFallback(ageGroup, behavior.value, procedure);
      const record = (typeof fallbackResult === 'object' && fallbackResult.record) ? fallbackResult.record : fallbackResult;
      const usedFallback = fallbackResult.usedFallback || false;
      const fallbackAge = fallbackResult.fallbackAge || null;
      renderPlan(record, patientName, ageGroup, procedure, behavior.value, parentProfile, visitHistory, flags, usedFallback, fallbackAge);
    }

    document.getElementById('loadingState').style.display = 'none';
    document.getElementById('outputState').style.display = 'flex';
    document.getElementById('tab-strategy').classList.add('active');
    
    // Re-enable button
    generateBtn.disabled = false;
    generateBtn.style.opacity = '1';
    generateBtn.style.cursor = 'pointer';
    btnText.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> ' + originalText;
    
    // AUTO-SAVE patient inputs to Supabase (non-blocking)
    PedoPlanDB.savePatient({
      name        : patientName,
      age_group   : ageGroup,
      procedure   : procedure,
      behavior    : behavior.value,
      parent_profile : parentProfile,
      visit_history  : visitHistory,
      flags       : flags.join(',')
    }).catch(e => console.warn('Patient save skipped:', e));

    // Scroll to output on mobile
    document.getElementById('outputState').scrollIntoView({ behavior: 'smooth' });
  } catch(err) {
    console.error('generatePlan error:', err);
    
    // Show error to user
    document.getElementById('aiErrorMessage').textContent = 'Error generating plan: ' + (err.message || 'Please check your inputs and try again.');
    document.getElementById('aiErrorDisplay').style.display = 'block';
    
    toast('Error generating plan. Please check your inputs.');
    
    document.getElementById('loadingState').style.display = 'none';
    document.getElementById('emptyState').style.display = 'flex';
    
    // Re-enable button
    const generateBtn = document.getElementById('generateBtn');
    const btnText = document.getElementById('generateBtnText');
    if (generateBtn) {
      generateBtn.disabled = false;
      generateBtn.style.opacity = '1';
      generateBtn.style.cursor = 'pointer';
      btnText.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> Generate Clinical Game Plan';
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// BILINGUAL OBJECTION-HANDLING SCRIPTS (Hindi/English)
// ═══════════════════════════════════════════════════════════════
// Pre-written front-desk scripts for common high-friction procedures
// WhatsApp-ready Hindi translations included

const BILINGUAL_OBJECTION_SCRIPTS = {
  // Pulpectomy / Pulpotomy: "Why root canal on milk tooth?"
  pulpectomy: `\n\n### 💬 FRONT-DESK SCRIPT: "Why do a root canal on a milk tooth?"\n\n**English:**  
"Milk teeth hold the space for permanent teeth. If we pull it out early, the space shrinks, and the permanent tooth will come out crooked, requiring expensive braces later. The infection can also damage the permanent tooth bud sitting right underneath it."\n\n**Hindi (WhatsApp Ready):**  
"दूध के दांत पक्के दांतों के लिए जगह बनाकर रखते हैं। अगर हम इसे अभी निकाल देंगे, तो जगह सिकुड़ जाएगी और पक्के दांत टेढ़े-मेढ़े आएंगे। इसके अलावा, इसका infection मसूड़े के नीचे बन रहे नए पक्के दांत को हमेशा के लिए खराब कर सकता है। इसलिए इस दांत को बचाना बहुत जरूरी है।"\n\n**Key Points:**  
- Space maintenance prevents orthodontic issues (₹30,000-50,000 braces cost)  
- Infection risk to permanent tooth successor  
- Premature loss = future complications`,

  // SDF Application: "Will it stain?"
  sdf: `\n\n### 💬 FRONT-DESK SCRIPT: "Will the SDF medicine stain the tooth?"\n\n**English:**  
"This medicine is magical for stopping cavities without drilling, but it will turn the decayed part of the tooth permanently black. The healthy part stays white. This black stain is proof that the decay has stopped."\n\n**Hindi (WhatsApp Ready):**  
"यह दवाई बिना मशीन चलाए दांत की सड़न को वहीं रोक देती है। लेकिन यह दवाई लगने के बाद दांत का सड़ा हुआ हिस्सा हमेशा के लिए काला हो जाएगा। जो हिस्सा सही है, वह सफेद ही रहेगा। यह कालापन इस बात का सबूत है कि कीड़ा अब आगे नहीं बढ़ेगा।"\n\n**Key Points:**  
- No drilling, no anesthesia, no pain  
- Cost-effective (₹200-500 vs ₹2000-3000 filling)  
- 81% arrest rate (Marwah 5th Ed.)  
- Staining only on decayed areas, not healthy tooth structure`,

  // SSC (Stainless Steel Crown): "Why steel cap instead of filling?"
  ssc: `\n\n### 💬 FRONT-DESK SCRIPT: "Why steel cap instead of filling?"\n\n**English:**  
"Cement fillings fall out 40-60% of the time in baby teeth because children chew hard and grind their teeth. Steel crowns last until the tooth naturally falls out at age 10-12, so no repeat visits or re-infection. It's the DCI 2022 gold standard for back baby teeth."\n\n**Hindi (WhatsApp Ready):**  
"Cement filling बच्चों में 40-60% बार टूट जाती है क्योंकि बच्चे ज़ोर से चबाते हैं और दांत पीसते हैं। Steel crown तब तक रहता है जब तक दांत natural रूप से 10-12 साल में गिरता है, तो दोबारा visit या infection नहीं होता। यह DCI 2022 का gold standard है baby teeth के पीछे के दांतों के लिए।"\n\n**Key Points:**  
- Cement filling failure rate: 40-60% in primary molars  
- SSC longevity: until natural exfoliation (8-10 years)  
- Prevents re-infection and repeat procedures  
- DCI 2022 guideline for primary molars`,

  // Extraction: "Can't we just save it?"
  extraction: `\n\n### 💬 FRONT-DESK SCRIPT: "Can't we just save the tooth?"\n\n**English:**  
"We always try to save teeth when possible. However, when the infection has spread too far, saving it would mean the infection keeps spreading to the bone and the permanent tooth underneath. In this case, removing it is the safest option. We'll use a space maintainer to hold the gap open."\n\n**Hindi (WhatsApp Ready):**  
"हम हमेशा दांत बचाने की कोशिश करते हैं। लेकिन जब infection बहुत ज़्यादा फैल गया हो, तो दांत बचाने का मतलब है infection हड्डी और नीचे के पक्के दांत में फैलता रहेगा। इस case में, इसे निकालना सबसे सुरक्षित option है। हम space maintainer लगाएंगे ताकि जगह बनी रहे।"\n\n**Key Points:**  
- Infection spread risk to bone and permanent successor  
- Space maintainer prevents orthodontic complications  
- Extraction when pulp therapy contraindicated  
- Safety prioritized over preservation`
};

// ─── RENDER PLAN ────────────────────────────────────────────────
function renderPlan(rec, name, ageGroup, procedure, behavior, parentProfile, visitHistory, flags, usedFallback = false, fallbackAge = null) {
  document.getElementById('planModeLabel').textContent = 'India Clinical Matrix Active (DCI 2022)';

  // Reset parent kit for new patient
  pkState.generated = false;
  pkState.data = null;
  document.getElementById('pkContent').style.display = 'none';
  document.getElementById('pkEmpty').style.display = 'block';
  document.getElementById('pkLoading').style.display = 'none';

  const ageLabels = { infant:'Infant (0–18 mo)', toddler:'Toddler (1.5–3 yr)', preschool:'Pre-school (3–6 yr)', schoolage:'School-age (6–9 yr)', preteen:'Pre-teen (9–12 yr)' };
  const procLabels = { exam:'Examination/Prophylaxis', restoration:'Restoration (GIC/Composite)', pulpectomy:'Pulpectomy/Pulpotomy', extraction:'Extraction', sdf:'SDF/ART', spacemaintainer:'Space Maintainer', xray:'Radiograph' };
  const behLabels = { definitely_negative:'Frankl 1 — Definitely Negative', negative:'Frankl 2 — Negative', positive:'Frankl 3 — Positive', definitely_positive:'Frankl 4 — Definitely Positive' };
  const parentLabels = { overprotective:'Overprotective Mother', anxious_transmitter:'Anxiety-Transmitting Parent', joint_family:'Joint Family Context', cooperative:'Cooperative', detached:'Detached Parent', educated_demanding:'Educated but Demanding' };
  const visitLabels = { first:'First Visit', negative:'Prior Trauma', neutral:'Neutral History', positive:'Positive History' };

  // Header
  document.getElementById('outPatientName').textContent = name;
  document.getElementById('outDate').textContent = new Date().toLocaleDateString('en-IN', { day:'numeric', month:'long', year:'numeric' });

  // ═══════════════════════════════════════════════════════════════
  // FALLBACK UI BADGE INTERFACE
  // ═══════════════════════════════════════════════════════════════
  // Remove any existing fallback banner first
  const existingBanner = document.querySelector('.fallback-banner');
  if (existingBanner) existingBanner.remove();
  
  if (usedFallback && fallbackAge) {
    const fallbackAgeLabel = ageLabels[fallbackAge] || fallbackAge;
    const warningHtml = `
      <div class="fallback-banner" style="
        background: #fff7e6;
        border: 1px solid #F5A623;
        border-radius: 8px;
        padding: 12px;
        margin: 16px 0;
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: 0 2px 4px rgba(245, 166, 35, 0.1);
      ">
        <span style="font-size: 18px;">⚠️</span>
        <div style="flex: 1;">
          <h4 style="
            color: #a86b00;
            font-size: 13px;
            font-weight: 600;
            margin: 0;
            font-family: var(--sans);
          ">
            Baseline Reference Protocol Active
          </h4>
          <p style="
            color: #4a4a6a;
            font-size: 11.5px;
            margin: 4px 0 0 0;
            line-height: 1.6;
            font-family: var(--sans);
          ">
            An exact combination match was not found in the custom lookup matrix. This evidence-based baseline protocol is loaded from <strong>Marwah 5th Ed.</strong> guidelines (adapted from <strong>${fallbackAgeLabel}</strong> protocols). Customize chairside as required for the specific patient presentation.
          </p>
        </div>
      </div>
    `;
    document.getElementById('outTagsRow').insertAdjacentHTML('afterend', warningHtml);
  }

  // Tags
  const behBadgeClass = { definitely_negative:'badge-red', negative:'badge-amber', positive:'badge-green', definitely_positive:'badge-blue' };
  const parentBadgeClass = { overprotective:'badge-red', anxious_transmitter:'badge-amber', joint_family:'badge-amber', cooperative:'badge-green', detached:'badge-neutral', educated_demanding:'badge-blue' };
  const visitBadgeClass = { first:'badge-amber', negative:'badge-red', neutral:'badge-neutral', positive:'badge-green' };
  let tagsHtml = `
    <span class="badge badge-neutral">${ageLabels[ageGroup]||ageGroup}</span>
    <span class="badge badge-neutral">${procLabels[procedure]||procedure}</span>
    <span class="badge ${behBadgeClass[behavior]||'badge-neutral'}">${behLabels[behavior]||behavior}</span>
    <span class="badge ${parentBadgeClass[parentProfile]||'badge-neutral'}">${parentLabels[parentProfile]||parentProfile}</span>
    <span class="badge ${visitBadgeClass[visitHistory]||'badge-neutral'}">${visitLabels[visitHistory]||visitHistory}</span>
  `;
  flags.forEach(f => { tagsHtml += `<span class="badge badge-red"><i class="fa-solid fa-flag" style="font-size:8px;"></i> ${f}</span>`; });
  document.getElementById('outTagsRow').innerHTML = tagsHtml;

  // Time
  document.getElementById('outDuration').textContent = rec.duration || '—';
  document.getElementById('outDurationTip').textContent = rec.durationTip || '';
  document.getElementById('outProtocolName').textContent = rec.protocol || '—';

  // Strategy
  document.getElementById('outStrategyTitle').textContent = rec.stratTitle || '—';
  document.getElementById('outStrategyDesc').textContent = rec.stratDesc || '—';

  // Cultural
  document.getElementById('outCulturalInsight').innerHTML = `<span class="insight-tag"><i class="fa-solid fa-om" style="margin-right:4px;"></i>India-Specific Context</span>${rec.cultural||'No specific cultural notes for this combination.'}`;

  // Techniques
  let techHtml = '';
  (rec.techniques||[]).forEach(t => { techHtml += `<span class="tech-tag">${t}</span>`; });
  document.getElementById('outTechniques').innerHTML = techHtml || '—';

  // Checklist
  let clHtml = '';
  (rec.checklist||[]).forEach(item => {
    clHtml += `<li><div class="check-icon"><i class="fa-solid fa-check"></i></div><span>${item}</span></li>`;
  });
  document.getElementById('outChecklist').innerHTML = clHtml;

  // Escalation
  let escHtml = '';
  (rec.escalation||[]).forEach(step => {
    escHtml += `
      <div class="ladder-step">
        <div class="step-num">${(rec.escalation.indexOf(step)+1)}</div>
        <div class="step-content"><strong>${step.title}</strong> — ${step.desc}</div>
      </div>`;
  });
  document.getElementById('outEscalationLadder').innerHTML = escHtml || '<div style="color:var(--text3);font-size:12px;padding:12px 0;">Standard NP protocol — no pharmacological escalation expected for this profile.</div>';

  // Drug table
  let drugHtml = '';
  (rec.drugs||[]).forEach(d => {
    drugHtml += `<div class="drug-row"><div class="drug-name">${d.name}</div><div class="drug-dose">${d.dose}</div><div class="drug-note">${d.note}</div></div>`;
  });
  document.getElementById('outDrugTable').innerHTML = drugHtml || '<div style="color:var(--text3);font-size:12px;padding:8px 0;">No pharmacological agents for this profile.</div>';
  document.getElementById('outDrugNote').innerHTML = `<span class="insight-tag">India Formulary Note</span>${rec.drugNote||'Standard DCI-approved drug protocol applies.'}`;

  // Highlight static drug tables based on weight
  const _wt = parseFloat(document.getElementById('patientWeight')?.value);
  if (_wt && _wt > 0) {
    setTimeout(() => {
      highlightDrugTables(_wt);
      const note = document.getElementById('staticDosageNote');
      if (note) note.textContent = `Child weight: ${_wt} kg — highlighted rows show correct dose.`;
    }, 100);
  }

  // Parent script - BASE CONTENT
  let parentScriptEn = rec.scriptEn || '—';
  let parentScriptHi = rec.scriptHi || '—';
  let parentScriptNote = rec.scriptNote || '';
  let parentTactics = rec.parentTactics || '—';

  // ============= CONTEXT OVERLAYS: PARENT TYPE =============
  switch(parentProfile) {
    case 'anxious_transmitter':
      const anxiousOverlay = `\n\n### 👥 PARENT MANAGEMENT OVERLAY (ANXIOUS PARENT)\n\n**Maternal/Paternal Anxiety Mitigation:** Localize the parent close to the chair using the 'Parental Presence/Absence' technique (Tandon 3rd Ed).\n\n**Communication Guideline:** Use reassuring, non-clinical terms. Explain the 'Tell-Show-Do' flow to the parent *before* running it with the child to keep them from interrupting chairside pacing.\n\n**Staff Action:** Reception staff to hand over the printed Pre-Visit Handout immediately to establish realistic clinic expectations.`;
      parentTactics = (parentTactics === '—' ? '' : parentTactics) + anxiousOverlay;
      break;
      
    case 'educated_demanding':
      const demandingOverlay = `\n\n### 👥 CLINICAL BOUNDARY OVERLAY (EDUCATED BUT DEMANDING PARENT)\n\n**Informed Consent Protocol:** Ensure formal, signed written informed consent is completed before initiating any behavior shaping. Explicitly document DCI 2022 guidelines regarding stabilization protocols if required.\n\n**Chairside Management:** Position the parent clearly outside the operator's immediate visual and physical sweep field. Set explicit, polite verbal boundaries regarding operating room guidelines.\n\n**Staff Action:** Senior clinical associate must witness and document the pre-operative briefing logs.`;
      parentTactics = (parentTactics === '—' ? '' : parentTactics) + demandingOverlay;
      break;
      
    case 'overprotective':
      const overprotectiveOverlay = `\n\n### 👥 PARENT MANAGEMENT OVERLAY (OVERPROTECTIVE PARENT)\n\n**Separation Strategy:** Consider parental separation for procedure if child shows capability. Use transitional approach: parent present for introduction, absent for procedure, return for completion.\n\n**Communication:** Frame procedures in positive language focusing on child's capability and resilience rather than protection needs.\n\n**Staff Action:** Pre-brief parent about natural child coping mechanisms and importance of not reinforcing anxiety through overprotection.`;
      parentTactics = (parentTactics === '—' ? '' : parentTactics) + overprotectiveOverlay;
      break;
      
    case 'detached':
      const detachedOverlay = `\n\n### 👥 PARENT ENGAGEMENT OVERLAY (DETACHED PARENT)\n\n**Engagement Strategy:** Actively involve parent in post-operative care instructions. Use direct questions requiring parental commitment to follow-up.\n\n**Documentation:** Ensure all instructions are provided in writing. Consider SMS/WhatsApp follow-up for compliance.\n\n**Staff Action:** Reception to confirm parent contact details and schedule follow-up appointment before family leaves clinic.`;
      parentTactics = (parentTactics === '—' ? '' : parentTactics) + detachedOverlay;
      break;
      
    case 'joint_family':
      const jointFamilyOverlay = `\n\n### 👨‍👩‍👧‍👦 CULTURAL DYNAMICS: JOINT FAMILY PROTOCOL\n\n**Authority Acknowledgment:**  
- Address the grandparents/elders directly FIRST to show respect before explaining clinical necessity to the parents.  
- Identify who holds financial decision-making authority (often not the mother).  
- Do not proceed with consent until the actual decision-maker verbally agrees.\n\n**Preventing Generational Sabotage:**  
- Explicitly explain why modern pediatric guidelines differ from 1990s practices:  
  • *"Stainless Steel Crowns are now the gold standard (DCI 2022), not cement fillings."*  
  • *"Pulpotomy protocols have changed—we preserve baby teeth longer now."*  
  • *"Local anesthesia formulations are safer and child-specific now."*  
- Pre-empt objections: *"I know things were done differently before, but dental research has evolved significantly."*\n\n**Staff Action (Critical):**  
- Ensure the counseling room has enough seating for all adults present.  
- Do NOT isolate the mother in a separate consultation—grandparents will override decisions if excluded.  
- Reception staff must log: "Joint Family Present: [Number of adults] — Primary Contact: [Name/Relation]" in the chart.\n\n**Red Flags to Watch:**  
- Grandparent whispering objections in regional language during explanation  
- Mother nodding agreement but grandparent showing disapproval body language  
- Financial discussion being deferred to "talk to father/grandfather later" (= treatment will NOT happen)\n\n**De-escalation Script (if resistance occurs):**  
*"I completely understand your concerns. Let me show you the DCI 2022 guidelines and recent research papers. We can also arrange a second opinion consultation if that helps build confidence. What matters most is [child's name]'s long-term dental health."*`;
      parentTactics = (parentTactics === '—' ? '' : parentTactics) + jointFamilyOverlay;
      break;
      
    case 'cooperative':
    default:
      // No overlay needed for cooperative parents - standard protocol applies
      break;
  }

  // ============= CONTEXT OVERLAYS: VISIT TYPE =============
  switch(visitHistory) {
    case 'negative':
      const negativeVisitOverlay = `\n\n### 🔄 VISIT HISTORY OVERLAY (PRIOR NEGATIVE EXPERIENCE)\n\n**Trauma Recovery Protocol:** Extended desensitization phase required. Use systematic exposure starting with non-invasive procedures.\n\n**Trust Building:** Acknowledge previous difficult experience explicitly. "I know last time was hard. Today we'll go slower and you're in control."\n\n**Technique Modification:** Increase use of Tell-Show-Do cycles. Consider splitting procedures across multiple shorter visits rather than single long session.\n\n**Success Indicators:** Focus on rebuilding positive associations. Reward any progress, even if full procedure isn't completed in first attempt.`;
      parentTactics = (parentTactics === '—' ? '' : parentTactics) + negativeVisitOverlay;
      break;
      
    case 'positive':
      const positiveVisitOverlay = `\n\n### 🔄 VISIT HISTORY OVERLAY (POSITIVE PREVIOUS EXPERIENCE)\n\n**Efficiency Mode:** Streamline introduction phase. Child has established trust and understands clinical environment.\n\n**Rapport Shortcut:** Reference previous successful visit: "You were amazing last time with [previous procedure]. Ready to show me again?"\n\n**Technique Adjustment:** Reduce Tell-Show-Do repetition. Move faster through behavioral preparation phases.\n\n**Documentation Note:** Build on established behavioral momentum. Consider this patient for training demonstrations if appropriate.`;
      parentTactics = (parentTactics === '—' ? '' : parentTactics) + positiveVisitOverlay;
      break;
      
    case 'first':
      const firstVisitOverlay = `\n\n### 🔄 VISIT HISTORY OVERLAY (FIRST DENTAL VISIT)\n\n**Foundation Setting:** This visit establishes all future dental attitudes. Prioritize positive experience over procedural efficiency.\n\n**Extended Orientation:** Allow extra time for clinic familiarization. Show instruments, chair movements, sounds before any clinical work.\n\n**Parent Coaching:** Brief parent on their role before child enters. Establish communication expectations and hand signals.\n\n**Success Definition:** Completed procedure is secondary to positive emotional outcome. Even partial completion with good behavior is a win.`;
      parentTactics = (parentTactics === '—' ? '' : parentTactics) + firstVisitOverlay;
      break;
      
    case 'neutral':
    default:
      // No overlay needed for neutral visit history - standard protocol applies
      break;
  }

  // ============= BILINGUAL OBJECTION-HANDLING SCRIPTS =============
  // Inject procedure-specific Hindi/English front-desk scripts for 
  // common high-friction objections (pulpectomy, SDF, SSC, extraction)
  
  if (BILINGUAL_OBJECTION_SCRIPTS[procedure]) {
    const bilingualScript = BILINGUAL_OBJECTION_SCRIPTS[procedure];
    
    // Append to English and Hindi parent scripts
    parentScriptEn = (parentScriptEn === '—' ? '' : parentScriptEn) + bilingualScript;
    parentScriptHi = (parentScriptHi === '—' ? '' : parentScriptHi) + bilingualScript;
    
    // Also append to parentTactics for comprehensive counseling reference
    parentTactics = (parentTactics === '—' ? '' : parentTactics) + bilingualScript;
  }

  // Render final content with overlays applied
  document.getElementById('outParentScriptEn').textContent = parentScriptEn;
  document.getElementById('outParentScriptHi').textContent = parentScriptHi;
  document.getElementById('outParentScriptNote').textContent = parentScriptNote;
  document.getElementById('outParentTactics').textContent = parentTactics;

  // Failures
  let failHtml = '';
  (rec.failures||[]).forEach(f => { failHtml += `<li><i class="fa-solid fa-xmark"></i><span>${f}</span></li>`; });
  document.getElementById('outFailureList').innerHTML = failHtml;

  // Flag actions
  document.getElementById('outFlagActions').textContent = rec.flagActions || 'No specific flag overrides for this combination. Standard protocol applies.';

  // Chair Script
  const csKey = getChairScriptKey(ageGroup, behavior, procedure);
  if (csKey && CHAIR_SCRIPTS[csKey]) {
    currentChairScript = CHAIR_SCRIPTS[csKey];
    renderChairScript(currentChairScript);
  } else {
    document.getElementById('outChairScript').innerHTML = '<div style="padding:16px;text-align:center;color:var(--text3);font-size:12px;border:1px dashed var(--border);border-radius:var(--r);">No pre-built script for this exact combination — use the AI-generated script above.</div>';
    currentChairScript = null;
  }
}

// ─── CHAIR SCRIPTS DATA ──────────────────────────────────────────
const CHAIR_SCRIPTS = {
  infant_definitely_negative_exam: [
    { phase:"ENTER", label:"Enter & Position", en:"Walk in calmly. Speak to mother first, not the infant. 'Hello, I'm Dr. [name]. Let's make this quick and comfortable for both of you.'", hi:"शांत रहें। पहले माँ से बात करें। 'नमस्ते, मैं Dr. [नाम] हूँ। हम यह जल्दी और आराम से करेंगे।'" },
    { phase:"RAPPORT", label:"Parent Rapport", en:"Squat to mother's level. 'This is going to be a knee-to-knee check — I'll be across from you, baby lies in both our laps. Very common, very safe.'", hi:"'यह knee-to-knee जाँच होगी — बच्चा दोनों की गोद में रहेगा। बहुत common और safe है।'" },
    { phase:"INTRODUCE", label:"Position & Prepare", en:"Guide into knee-to-knee. 'Perfect. Now hold both arms gently at the sides. Baby may cry — that's completely normal and actually helps me see inside.'", hi:"'बिल्कुल ठीक। अब दोनों हाथ हल्के से पकड़ें। रोना बिल्कुल normal है — इससे मुझे अंदर देखने में मदद मिलती है।'" },
    { phase:"PROCEDURE", label:"Examination", en:"Work fast. Narrate quietly: 'Counting teeth — one, two, three… good. Checking gums — healthy. Almost done.'", hi:"'दाँत गिन रहे हैं — एक, दो, तीन… ठीक है। मसूड़े देख रहे हैं — अच्छे हैं। लगभग हो गया।'" },
    { phase:"CLOSE", label:"Close & Counsel", en:"'All done! Baby did perfectly. [To parent:] Here's what I found and what we'll do next…'", hi:"'हो गया! बच्चे ने बहुत अच्छा किया। [माँ से:] यह मिला और आगे यह करेंगे…'" }
  ],
  infant_negative_exam: [
    { phase:"ENTER", label:"Enter Warmly", en:"Greet mother by name. Smile at infant. 'Hello! Let's take a quick look together — you'll be right there the whole time.'", hi:"'नमस्ते! हम मिलकर एक नज़र देखेंगे — आप पूरे समय वहीं रहेंगी।'" },
    { phase:"RAPPORT", label:"Engage Infant", en:"Make eye contact with infant, smile. Let infant see your gloved hand before touching. No sudden movements.", hi:"बच्चे से आँख मिलाएँ, मुस्कुराएँ। छूने से पहले gloved हाथ दिखाएँ। कोई अचानक हरकत नहीं।" },
    { phase:"INTRODUCE", label:"Knee-to-Knee Setup", en:"'Now I'll sit facing you. Baby comes across into both our laps — head toward me, feet toward you. Your hands stay gently on their tummy.'", hi:"'अब मैं आपके सामने बैठूँगा/बैठूँगी। बच्चा दोनों की गोद में — सिर मेरी तरफ, पैर आपकी तरफ। आपके हाथ पेट पर।'" },
    { phase:"PROCEDURE", label:"Examine", en:"Mirror and finger exam. 'One… two… three teeth — lovely. Gums look great. Checking for any spots… all clear.'", hi:"'एक… दो… तीन दाँत — सुंदर। मसूड़े अच्छे हैं। कोई दाग तो नहीं… सब ठीक है।'" },
    { phase:"CLOSE", label:"Finish & Praise", en:"'Done! That was wonderful. [Name] was so calm. Let me share what I noticed…'", hi:"'हो गया! बहुत अच्छा रहा। [नाम] बहुत शांत था/थी। मैंने जो देखा वह बताता/बताती हूँ…'" }
  ],
  toddler_definitely_negative_exam: [
    { phase:"ENTER", label:"Enter & Ignore Child", en:"Walk in, greet parent only. Ignore the child for 30 seconds — let them observe you without pressure. Then look over casually: 'Oh hello! Who's this?'", hi:"अंदर आएँ, सिर्फ माँ-बाप को नमस्ते करें। 30 सेकंड बच्चे को ignore करें। फिर casually देखें: 'अरे, यह कौन है?'" },
    { phase:"RAPPORT", label:"Distraction Approach", en:"Show a sticker or toy. 'I have something for you if you open your mouth like a big lion for 30 seconds.' [Set phone timer visibly.]", hi:"'मेरे पास तुम्हारे लिए कुछ है — अगर तुम 30 सेकंड के लिए शेर की तरह मुँह खोलो।' [Phone timer दिखाएँ।]" },
    { phase:"INTRODUCE", label:"Knee-to-Knee", en:"'[Parent], I'll sit facing you. [Name] lies across both our laps — it's the fastest way and we'll be done before the timer runs out.'", hi:"'[माँ-बाप], मैं आपके सामने बैठूँगा। [नाम] दोनों की गोद में — सबसे तेज़ तरीका है, timer से पहले हो जाएगा।'" },
    { phase:"PROCEDURE", label:"Rapid Exam", en:"Work in silence except narration: 'Almost… almost… done! Timer's not even finished — you were SO fast!'", hi:"'लगभग… लगभग… हो गया! Timer भी खत्म नहीं हुआ — तुम बहुत तेज़ थे/थी!'" },
    { phase:"CLOSE", label:"Reward & Debrief", en:"Give reward immediately. '[Parent]: here is what I found. Next visit we'll…'", hi:"तुरंत reward दें। '[माँ-बाप]: यह मिला। अगली बार हम…'" }
  ],
  toddler_definitely_negative_restoration: [
    { phase:"ENTER", label:"Pre-Brief Parent", en:"[Before child enters] 'Baby may cry — that's okay, we expect that. Your only job: hold hands, look calm, don't say anything. I will handle the rest.'", hi:"[बच्चा आने से पहले] 'बच्चा रो सकता है — ठीक है, हम expect करते हैं। आपका काम: हाथ पकड़ें, शांत रहें, कुछ न बोलें। बाकी मैं संभालूँगा।'" },
    { phase:"RAPPORT", label:"Settle & Distract", en:"Show tablet with cartoon. 'Look — Chhota Bheem! Let's watch while I count your teeth.' [No clinical talk yet.]", hi:"'देखो — Chhota Bheem! चलो देखते हैं जब मैं दाँत गिनता/गिनती हूँ।' [कोई clinical बात नहीं।]" },
    { phase:"INTRODUCE", label:"TSD — Tool Intro", en:"'This is Mr. Water Toothbrush [show slow-speed]. See how it tickles? [demo on fingernail]. Now open big — we're going to clean the sneaky sugar bug!'", hi:"'यह Mr. Water Toothbrush है। देखो कैसे गुदगुदाता है? अब मुँह खोलो — हम उस शरारती sugar bug को साफ करेंगे!'" },
    { phase:"PROCEDURE", label:"Work — Narrate Continuously", en:"'Cleaning… cleaning… Mr. Straw is drinking the water — good job staying still! Almost there… nearly done… DONE! You were brilliant!'", hi:"'साफ कर रहे हैं… Mr. Straw पानी पी रहा है — बिल्कुल हिले नहीं, बहुत अच्छे! लगभग हो गया… DONE! तुम बहुत brave हो!'" },
    { phase:"CLOSE", label:"Celebrate & Next Step", en:"'First pick from the prize box — you've earned it! [Parent]: here's what we did and what we'll need next visit.'", hi:"'Prize box में से पहले तुम choose करो — तुमने deserve किया! [माँ-बाप]: यह हुआ और अगली बार यह होगा।'" }
  ],
  toddler_negative_exam: [
    { phase:"ENTER", label:"Enter & Make Friends", en:"'Hi [name]! Wow, is that a [notice something they're wearing/holding]? I love it!' [20 seconds of genuine child talk before any clinical activity.]", hi:"'हाय [नाम]! वाह, यह क्या है [कपड़े/खिलौना]? मुझे बहुत पसंद है!' [कोई clinical बात से पहले 20 सेकंड।]" },
    { phase:"RAPPORT", label:"Mirror Game", en:"'Want to see a magic mirror? [show mirror] It makes funny faces! Can you open like a hippo? Amazing!'", hi:"'एक magic mirror देखना है? यह funny faces दिखाता है! क्या तुम hippo की तरह मुँह खोल सकते हो? कमाल!'" },
    { phase:"INTRODUCE", label:"Finger Exam First", en:"'I'm just going to count with my finger — one… two… [gentle finger exam]. Great! Now let me use Mr. Mirror — he's shy, he just looks, never touches.'", hi:"'मैं सिर्फ उँगली से गिनूँगा — एक… दो… बहुत अच्छे! अब Mr. Mirror — वो शर्मीला है, सिर्फ देखता है, कभी छूता नहीं।'" },
    { phase:"PROCEDURE", label:"Full Exam", en:"'Mirror going in… counting teeth… gums looking good… checking everything… perfect! All done in record time!'", hi:"'Mirror जा रहा है… दाँत गिन रहे हैं… मसूड़े अच्छे हैं… सब देख लिया… बिल्कुल ठीक! Record time में हो गया!'" },
    { phase:"CLOSE", label:"Sticker & Next", en:"'You get a sticker for being SO good! [Parent]: everything looks [assessment]. We'll see you in [timeframe].'", hi:"'Sticker मिलेगा इतना अच्छा होने के लिए! [माँ-बाप]: सब [assessment] है। [समय] में मिलेंगे।'" }
  ],
  toddler_positive_restoration: [
    { phase:"ENTER", label:"Warm Welcome", en:"'[Name]! You're back! I remembered you — you were so good last time. Today we have an even cooler job for your teeth.'", hi:"'[नाम]! तुम वापस आ गए! मुझे याद है — पिछली बार तुम बहुत अच्छे थे। आज दाँतों के लिए और भी cool काम है।'" },
    { phase:"RAPPORT", label:"Review & Prime", en:"'Remember Mr. Water Toothbrush from last time? He's back! And today he brought a friend — Mr. Shield. He makes teeth super strong.'", hi:"'याद है पिछली बार का Mr. Water Toothbrush? वो वापस आया! और आज वो एक दोस्त लाया — Mr. Shield। वो दाँत super strong बनाता है।'" },
    { phase:"INTRODUCE", label:"TSD Refresher", en:"'Open like a lion — ROAR! [demonstrate]. Perfect — you remember! Now the magic sleepy drops — tiny little tickle, then the tooth goes to sleep. Ready?'", hi:"'शेर की तरह मुँह खोलो — दहाड़! बिल्कुल याद है तुम्हें! Magic sleepy drops — छोटी सी गुदगुदी, फिर दाँत सो जाएगा। तैयार?'" },
    { phase:"PROCEDURE", label:"Narrate & Reward Mid-Way", en:"'Cleaning, cleaning… halfway done — you're doing amazing! Keep that mouth open — brilliant… and DONE! You are a superstar!'", hi:"'साफ कर रहे हैं… आधा हो गया — तुम amazing हो! मुँह खुला रखो — बहुत बढ़िया… और DONE! तुम superstar हो!'" },
    { phase:"CLOSE", label:"Prize & Parent Update", en:"'Prize box — first pick, as promised! [Parent]: Restoration complete. Here's home care…'", hi:"'Prize box — पहले तुम, जैसा कहा था! [माँ-बाप]: Restoration हो गया। Home care के लिए…'" }
  ],
  toddler_definitely_positive_restoration: [
    { phase:"ENTER", label:"Celebrate Arrival", en:"'[Name]! My favourite patient! You make my job so easy — come on in!' [Genuine enthusiasm.]", hi:"'[नाम]! मेरे favourite patient! तुम मेरा काम इतना आसान बना देते हो — अंदर आओ!'" },
    { phase:"RAPPORT", label:"Quick Rapport", en:"'Tell me one thing that happened since last time?' [30-second genuine chat.] 'Okay — ready to be a tooth superhero again?'", hi:"'पिछली बार के बाद एक बात बताओ?' [30 सेकंड असली बात।] 'ठीक है — फिर से tooth superhero बनने के लिए तैयार?'" },
    { phase:"INTRODUCE", label:"Streamlined TSD", en:"'You know the drill — lion mouth, sleepy drops, then all sorted. We'll be done super fast. Open!'", hi:"'तुम्हें पता है — शेर का मुँह, sleepy drops, फिर सब हो जाएगा। बहुत जल्दी। खोलो!'" },
    { phase:"PROCEDURE", label:"Efficient Work", en:"Work efficiently. Minimal narration for cooperative child: 'Great… perfect… nearly done…' Don't over-talk.", hi:"कुशलता से काम करें। ज़्यादा बात न करें: 'बहुत अच्छे… perfect… लगभग हो गया…'" },
    { phase:"CLOSE", label:"Genuine Praise & Document", en:"'Absolute champion. [Parent]: we completed everything planned. Next visit: [plan]. Document: technique — TSD + rapport, zero sedation needed.'", hi:"'बिल्कुल champion। [माँ-बाप]: जो plan था सब हो गया। अगली बार: [plan]।'" }
  ],
  preschool_definitely_negative_restoration: [
    { phase:"ENTER", label:"Enter with Authority", en:"'Hi [name], I'm Dr. [name]. This is my workshop — come and have a look around.' [Confident, not asking permission. Tour the room briefly.]", hi:"'हाय [नाम], मैं Dr. [नाम] हूँ। यह मेरी workshop है — आओ देखो।' [आत्मविश्वास के साथ, permission नहीं माँगते।]" },
    { phase:"RAPPORT", label:"Name Every Tool", en:"'This is Mr. Water Toothbrush [suction]. This is Mr. Wind [air syringe]. This is the magic sleepy pillow [topical]. Let me show you on your finger — feel it?'", hi:"'यह Mr. Water Toothbrush। यह Mr. Wind। यह magic sleepy pillow। अपनी उँगली पर दिखाता हूँ — feel हुआ?'" },
    { phase:"INTRODUCE", label:"Directive Positioning", en:"'Now sit back like a rocket going to space. [Recline chair.] Arms on tummy — just like that. PERFECT. Lion mouth — ROAR!'", hi:"'अब पीछे बैठो जैसे rocket space जा रहा हो। हाथ पेट पर — बिल्कुल ऐसे। PERFECT। शेर — दहाड़!'" },
    { phase:"PROCEDURE", label:"Narrate Non-Stop", en:"'Sleepy pillow going in — just a tickle… [wait 90 sec topical] … tooth is getting sleepy… now the tiny water drop — keep very still… almost asleep… done! Now Mr. Toothbrush is cleaning — nearly finished… DONE!'", hi:"'Sleepy pillow — बस गुदगुदी… दाँत सो रहा है… अब tiny water drop — बिल्कुल हिलो मत… लगभग सो गया… DONE! Mr. Toothbrush साफ कर रहा है… DONE!'" },
    { phase:"CLOSE", label:"Big Celebration", en:"'You are a STAR! First pick from the prize box. [Parent]: completed [procedure]. Review in [timeframe].'", hi:"'तुम STAR हो! Prize box में से पहले तुम। [माँ-बाप]: [procedure] complete। [समय] में review।'" }
  ],
  preschool_definitely_negative_exam: [
    { phase:"ENTER", label:"Enter Quietly", en:"'Hello! I'm just going to have a quick look — no tools today, just my magic mirror.' [Keep coat/mask informal if possible.]", hi:"'Hello! मैं बस एक नज़र देखूँगा — आज कोई tool नहीं, बस magic mirror।'" },
    { phase:"RAPPORT", label:"Engagement Game", en:"'Can you roar like a lion? [child roars] AMAZING! That's exactly what I need — one big roar and I can see all your teeth. Ready?'", hi:"'क्या तुम शेर की तरह दहाड़ सकते हो? शानदार! बस एक बड़ी दहाड़ और मैं सारे दाँत देख सकता/सकती हूँ। Ready?'" },
    { phase:"INTRODUCE", label:"Show Mirror", en:"'Mr. Mirror is very shy — he just looks and never bites! Here, look at yourself! See? Funny!'", hi:"'Mr. Mirror बहुत शर्मीला है — बस देखता है, कभी काटता नहीं! देखो अपना चेहरा! देखो, funny है!'" },
    { phase:"PROCEDURE", label:"Rapid Exam", en:"'Open for 30 seconds… counting… one, two, three [narrate quickly]… gums healthy… checking back teeth… all done! Faster than a pizza!'", hi:"'30 सेकंड के लिए खोलो… गिन रहे हैं… एक, दो, तीन… मसूड़े healthy… पीछे के दाँत… हो गया! Pizza से भी जल्दी!'" },
    { phase:"CLOSE", label:"Sticker", en:"'Sticker time! You were so brave. [Parent]: Here is what I found [assessment].'", hi:"'Sticker time! तुम बहुत brave थे। [माँ-बाप]: यह मिला [assessment]।'" }
  ],
  preschool_definitely_negative_pulpectomy: [
    { phase:"ENTER", label:"Parent Pre-Brief (Child Out)", en:"[Before child comes in] 'This will take 30–40 min over two visits. Child may be vocal — that's expected. Your job: calm presence, hold left hand, no words unless I ask. Ready?'", hi:"[बच्चा बाहर हो] '30-40 min, दो visits में। बच्चा शोर कर सकता है — expected है। आपका काम: शांत रहें, बाएँ हाथ पकड़ें, बोलें नहीं जब तक मैं न पूछूँ।'" },
    { phase:"RAPPORT", label:"The Magic Sleep Story", en:"'Today your tooth is going for a holiday — we're going to give it magic sleeping drops so it has a nice rest. When it wakes up it will be all fixed!'", hi:"'आज तुम्हारा दाँत holiday पर जाएगा — हम उसे magic sleeping drops देंगे ताकि वो अच्छे से सोए। जागने पर बिल्कुल ठीक होगा!'" },
    { phase:"INTRODUCE", label:"Topical + LA TSD", en:"'Magic sleepy pillow first — just a tickle on the gum. [90 sec.] Now a tiny water drop inside — keep lion mouth open… good… tooth is starting to sleep…'", hi:"'Magic sleepy pillow पहले — मसूड़े पर बस गुदगुदी। अब अंदर tiny water drop — शेर का मुँह खुला रखो… अच्छे… दाँत सोने लगा…'" },
    { phase:"PROCEDURE", label:"Work with Narration", en:"'Tooth is fully asleep — now Mr. Cleaning Brush goes inside to fix everything. You won't feel anything — just vibration. Keep still… halfway… nearly done…'", hi:"'दाँत पूरा सो गया — अब Mr. Cleaning Brush अंदर जाएगा। कुछ feel नहीं होगा — बस vibration। हिलो मत… आधा हो गया… लगभग done…'" },
    { phase:"CLOSE", label:"Big Reward", en:"'Done for today! Part 2 next time — just as easy. Prize box — first pick! [Parent]: canal cleaned, temporised. Second visit: [date].'", hi:"'आज के लिए done! अगली बार Part 2 — उतना ही आसान। Prize box! [माँ-बाप]: canal साफ, temporary भरा। अगली visit: [date]।'" }
  ],
  preschool_definitely_negative_extraction: [
    { phase:"ENTER", label:"Authority Entry", en:"'Hi [name]. Today your wobbly tooth is going on an adventure — it's ready to leave and make room for your big-kid tooth. It'll be quick.'", hi:"'हाय [नाम]। आज तुम्हारा हिलता दाँत adventure पर जाएगा — वो जाने के लिए ready है ताकि big-kid दाँत आ सके। जल्दी होगा।'" },
    { phase:"RAPPORT", label:"Tooth Fairy Hook", en:"'Did you know the tooth fairy gives more coins for brave children? Let's make sure you get the maximum coins today!'", hi:"'क्या तुम्हें पता है Tooth Fairy brave बच्चों को ज़्यादा coins देती है? आज maximum coins लेना है!'" },
    { phase:"INTRODUCE", label:"Topical + Slow LA", en:"'Magic sleepy pillow on the gum — 60 seconds… [topical]. Now one tiny water drop — like a mosquito kiss — keep still… tooth is falling asleep.'", hi:"'Magic sleepy pillow — 60 seconds… अब एक tiny water drop — मच्छर की kiss जैसी — हिलो मत… दाँत सो रहा है।'" },
    { phase:"PROCEDURE", label:"Extraction", en:"'[Test with probe] Tooth is completely asleep! Now I'm going to wiggle it loose — just pressure, no pain. Wiggling… wiggling… and OUT! Your brave tooth!'", hi:"'[Test] दाँत पूरा सो गया! अब मैं उसे हिलाऊँगा — सिर्फ pressure, दर्द नहीं। हिला रहा हूँ… और OUT! तुम्हारा brave दाँत!'" },
    { phase:"CLOSE", label:"Show Tooth & Reward", en:"'Look — here it is! Put it under your pillow tonight. [Give gauze.] Bite on this for 10 minutes. [Parent]: post-op instructions, [review plan].'", hi:"'देखो — यह रहा! आज रात pillow के नीचे रखना। यह काटो 10 मिनट। [माँ-बाप]: post-op instructions।'" }
  ],
  preschool_negative_restoration: [
    { phase:"ENTER", label:"Warm Confident Entry", en:"'Hi [name]! I've been looking forward to seeing you. Ready to be a tooth champion today?'", hi:"'हाय [नाम]! मैं तुमसे मिलने के लिए excited था/थी। आज tooth champion बनने के लिए ready?'" },
    { phase:"RAPPORT", label:"Character Hook", en:"'You know Chhota Bheem? He cleans his teeth every day — that's why he's SO strong. Today we're going to clean your teeth just like Bheem!'", hi:"'Chhota Bheem को जानते हो? वो रोज़ दाँत साफ करता है — इसीलिए इतना strong है। आज हम Bheem जैसे तुम्हारे दाँत साफ करेंगे!'" },
    { phase:"INTRODUCE", label:"TSD with Story", en:"'First the magic sleepy pillow — it's Bheem's secret weapon [topical]. Now the sleepy drops — tiny tickle, and then your tooth joins Bheem's team!'", hi:"'पहले magic sleepy pillow — यह Bheem का secret weapon है। अब sleepy drops — छोटी गुदगुदी, और तुम्हारा दाँत Bheem की team में!'" },
    { phase:"PROCEDURE", label:"Continuous Narration", en:"'Mr. Toothbrush is cleaning… Bheem is cheering you on… halfway… the sugar bugs are running away… and DONE! Bheem would be SO proud!'", hi:"'Mr. Toothbrush साफ कर रहा है… Bheem cheer कर रहा है… आधा हो गया… sugar bugs भाग रहे हैं… और DONE! Bheem बहुत proud होगा!'" },
    { phase:"CLOSE", label:"Star Chart & Next", en:"'Gold star on your chart! One more visit to finish and you'll have a full chart. [Parent]: [what was done, what remains].'", hi:"'Gold star! एक और visit और chart पूरा हो जाएगा। [माँ-बाप]: [क्या हुआ, क्या बाकी है]।'" }
  ],
  preschool_positive_restoration: [
    { phase:"ENTER", label:"High Energy Welcome", en:"'[Name]! You're here! I heard you were amazing last time — ready to do it again? Today we're doing [procedure name in fun language].'", hi:"'[नाम]! तुम आ गए! सुना था तुम पिछली बार amazing थे — फिर करने के लिए ready? आज [procedure] करेंगे।'" },
    { phase:"RAPPORT", label:"Praise & Ownership", en:"'You know what makes you different from most kids? You actually help me — when you keep your mouth open, the whole thing goes faster. You're my best helper.'", hi:"'तुम्हें पता है ज़्यादातर बच्चों से तुम अलग क्यों हो? तुम actually help करते हो — जब मुँह खुला रखते हो, सब जल्दी होता है। तुम मेरे best helper हो।'" },
    { phase:"INTRODUCE", label:"Brief TSD", en:"'Quick recap: sleepy pillow, sleepy drops, Mr. Toothbrush, done. You know the drill. Ready? Open — ROAR!'", hi:"'जल्दी recap: sleepy pillow, sleepy drops, Mr. Toothbrush, done। तुम जानते हो। Ready? खोलो — दहाड़!'" },
    { phase:"PROCEDURE", label:"Efficient with Praise", en:"'Perfect… you're a natural… halfway — incredible… nearly done… and THAT'S IT! Honestly the best.'", hi:"'Perfect… तुम natural हो… आधा हो गया — incredible… लगभग done… और बस! सच में best।'" },
    { phase:"CLOSE", label:"Specific Praise & Document", en:"'Specifically: you kept your mouth open even when the water came — that's the hardest part and you nailed it. [Parent]: [procedure] complete, [next visit plan].'", hi:"'Specifically: जब पानी आया तब भी मुँह खुला रखा — यह सबसे मुश्किल था और तुमने perfect किया। [माँ-बाप]: [procedure] complete।'" }
  ],
  schoolage_definitely_negative_restoration: [
    { phase:"ENTER", label:"Direct, Respectful Intro", en:"'Hi [name]. I'm Dr. [name]. I want to explain exactly what we're doing today — no surprises, I promise. Is that okay with you?'", hi:"'हाय [नाम]। मैं Dr. [नाम] हूँ। मैं exactly बताना चाहता/चाहती हूँ आज क्या होगा — कोई surprise नहीं, promise। ठीक है?'" },
    { phase:"RAPPORT", label:"Make the Deal", en:"'I have a deal for you: you raise your hand if you feel anything uncomfortable, and I stop immediately. Deal? Good — that means you're in control.'", hi:"'मेरी एक deal है: अगर कुछ uncomfortable feel हो तो हाथ उठाओ, मैं तुरंत रुकूँगा। Deal? अच्छा — इसका मतलब तुम्हारा control है।'" },
    { phase:"INTRODUCE", label:"Step-by-Step Briefing", en:"'Step 1: gel on gum — 60 seconds, feels nothing. Step 2: tiny drop of anaesthetic — feels like a mosquito for 2 seconds. Step 3: we wait 3 minutes. Then we fix. Clear?'", hi:"'Step 1: gel मसूड़े पर — 60 seconds। Step 2: tiny drop — 2 seconds मच्छर जैसा। Step 3: 3 minute wait। फिर fix। समझ आया?'" },
    { phase:"PROCEDURE", label:"Narrate Each Step", en:"'Gel going in — feel it? Perfect. Now the drop — here it comes — [inject slowly] — there — done. Raise hand if you felt more than a pinch? Good. Now we wait…'", hi:"'Gel जा रही है — feel हो रहा है? Perfect। अब drop — आ रही है — [inject] — और done। अगर pinch से ज़्यादा लगा तो हाथ उठाओ? अच्छा। अब wait…'" },
    { phase:"CLOSE", label:"Debrief the Child", en:"'[Name] — what was the hardest part? [listen] Okay, next time I'll [adjust]. You did genuinely well. [Parent]: [procedure + next plan].'", hi:"'[नाम] — सबसे मुश्किल क्या था? ठीक है, अगली बार मैं [adjust] करूँगा। तुमने सच में अच्छा किया।'" }
  ],
  schoolage_definitely_negative_extraction: [
    { phase:"ENTER", label:"Validate Anxiety", en:"'Hi [name]. Being nervous about an extraction is completely normal — even adults feel that. I'm going to make sure you feel absolutely nothing. Deal?'", hi:"'हाय [नाम]। निकालने के बारे में nervous होना बिल्कुल normal है — बड़े भी ऐसा feel करते हैं। मैं ensure करूँगा कि कुछ feel न हो। Deal?'" },
    { phase:"RAPPORT", label:"Hand Signal Setup", en:"'If at any point you want me to pause — raise your left hand and I stop. No questions asked. This means you're always in control.'", hi:"'अगर कभी रुकना हो — बाएँ हाथ उठाओ और मैं रुकूँगा। तुम्हारा हमेशा control रहेगा।'" },
    { phase:"INTRODUCE", label:"Anaesthesia TSD", en:"'Gel on gum first — 90 seconds [apply]. Now the anaesthetic — you'll feel pressure, like someone pressing with a finger, then nothing. Ready? Here it comes…'", hi:"'पहले gel — 90 seconds। अब anaesthetic — pressure feel होगा जैसे उँगली दबाई हो, फिर कुछ नहीं। Ready? आ रहा है…'" },
    { phase:"PROCEDURE", label:"Test Then Extract", en:"'[Test] Can you feel this? Perfect — fully numb. Now I'm going to hold the tooth firmly and rock it free — you'll feel pressure but zero pain. Rocking… and it's out.'", hi:"'[Test] यह feel हो रहा है? Perfect — पूरा numb। अब मैं दाँत firmly पकड़ूँगा — pressure feel होगा, दर्द नहीं। हिला रहा हूँ… और OUT।'" },
    { phase:"CLOSE", label:"Show & Explain", en:"'Here's your tooth. [Gauze in.] Bite for 15 minutes — no spitting, no rinsing for 24 hours. [Parent]: Ibuprofen after 2 hrs, soft diet today, review in [X] days.'", hi:"'यह रहा दाँत। [Gauze] 15 मिनट काटो — 24 घंटे न थूकें, न कुल्ला। [माँ-बाप]: 2 घंटे बाद Ibuprofen, soft diet।'" }
  ],
  schoolage_negative_restoration: [
    { phase:"ENTER", label:"Peer-Level Greeting", en:"'Hey [name]! Sit anywhere you like. So — you've probably had fillings before. This one's pretty routine. I'll walk you through it.'", hi:"'हे [नाम]! जहाँ चाहो बैठो। तो — शायद पहले filling हुई है। यह quite routine है। मैं walk-through करूँगा।'" },
    { phase:"RAPPORT", label:"Acknowledge & Redirect", en:"'Are you nervous? [If yes:] That's fair — most people are. The part people worry about is the injection, and that lasts 3 seconds. The rest is just vibration.'", hi:"'Nervous हो? [हाँ तो:] ठीक है — ज़्यादातर लोग होते हैं। जो part worry करता है वो injection है, और वो 3 seconds। बाकी बस vibration।'" },
    { phase:"INTRODUCE", label:"Transparent Steps", en:"'1. Gel 60 sec. 2. Injection — 3 seconds sting. 3. Wait 3 min. 4. I drill — zero pain, just sound. 5. Fill. 6. Done. Total: 25 min. Ready?'", hi:"'1. Gel 60 sec। 2. Injection — 3 seconds। 3. Wait 3 min। 4. Drill — zero pain। 5. Fill। 6. Done। Total: 25 min। Ready?'" },
    { phase:"PROCEDURE", label:"Narrate Progress", en:"'Gel in. [60 sec] Injection now — [slow inject] — done. Wait 3 min [set visible timer]. [Test] Fully numb. Drilling now — just sound…'", hi:"'Gel। [60 sec] Injection — [inject] — done। 3 min wait [timer दिखाएँ]। [Test] पूरा numb। Drilling — बस sound…'" },
    { phase:"CLOSE", label:"Honest Debrief", en:"'[Name] — was it as bad as you expected? Good. Come back in [X months] for review. [Parent]: GIC placed, review at [date].'", hi:"'[नाम] — उतना बुरा था जितना सोचा था? अच्छा। [X months] में review के लिए आना।'" }
  ],
  preteen_negative_restoration: [
    { phase:"ENTER", label:"Adult-Style Greeting", en:"'Hi [name] — have a seat. I want to talk to you directly, not to your parents, okay? This is your appointment.'", hi:"'हाय [नाम] — बैठो। मैं directly तुमसे बात करना चाहता/चाहती हूँ, माँ-बाप से नहीं। यह तुम्हारी appointment है।'" },
    { phase:"RAPPORT", label:"Acknowledge Their Concern", en:"'What's your biggest worry about today? [Listen fully.] Okay — that's really common. Here's exactly what will happen and how I'll handle that specific thing.'", hi:"'आज सबसे बड़ी chinta क्या है? [पूरा सुनें।] ठीक है — यह actually बहुत common है।'" },
    { phase:"INTRODUCE", label:"Detailed Honest Briefing", en:"'I'll describe every step before I do it. First: topical gel — works in 60 sec. Then: LA injection — pressure and a brief sting. Honestly, that's the worst part.'", hi:"'हर step पहले बताऊँगा। First: topical gel — 60 sec। Then: LA injection — pressure और brief sting। Honestly, यही सबसे मुश्किल है।'" },
    { phase:"PROCEDURE", label:"Narrate, Pause, Check", en:"'[After LA] How are you doing? Good. The tooth is numb — feel this? [probe] Perfect. Drilling starts — it'll sound loud but you'll feel nothing. Raise your hand if anything.'", hi:"'[LA के बाद] कैसे हो? अच्छा। दाँत numb है। Drilling — आवाज़ loud होगी लेकिन कुछ feel नहीं। कुछ हो तो हाथ उठाओ।'" },
    { phase:"CLOSE", label:"Respect & Next Steps", en:"'[Name] — you handled that really well. Any questions? Your filling will be sensitive for 2–3 days — normal. If pain persists beyond a week, call us.'", hi:"'[नाम] — तुमने बहुत अच्छा handle किया। कोई सवाल? Filling 2-3 दिन sensitive रहेगी — normal है। एक week से ज़्यादा दर्द हो तो call करो।'" }
  ]
};

// ─── PARENT KIT ──────────────────────────────────────────────────
let pkState = {
  generated: false,
  data: null,
  patientContext: null,
  langs: { handout: 'en', briefing: 'en', hospital: 'en' }
};

function setPKLang(section, lang) {
  pkState.langs[section] = lang;
  const btnEn = document.getElementById(`pk${capitalize(section)}En`);
  const btnHi = document.getElementById(`pk${capitalize(section)}Hi`);
  const activeStyle = 'padding:3px 10px;border-radius:5px;font-size:11px;font-weight:600;cursor:pointer;';
  const colors = { handout: 'var(--accent)', briefing: 'var(--green)', hospital: 'var(--blue)' };
  const c = colors[section] || 'var(--accent)';
  if (lang === 'en') {
    btnEn.style.cssText = `${activeStyle}border:1px solid ${c};background:${c};color:white;`;
    btnHi.style.cssText = `${activeStyle}border:1px solid var(--border);background:transparent;color:var(--text2);`;
  } else {
    btnHi.style.cssText = `${activeStyle}border:1px solid ${c};background:${c};color:white;`;
    btnEn.style.cssText = `${activeStyle}border:1px solid var(--border);background:transparent;color:var(--text2);`;
  }
  renderPKSection(section);
}

function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

function renderPKSection(section) {
  if (!pkState.data) return;
  const d = pkState.data;
  const lang = pkState.langs[section];
  const el = document.getElementById(`pk${capitalize(section)}Content`);
  if (!el) return;
  if (section === 'handout') el.textContent = lang === 'hi' ? d.handoutHi : d.handoutEn;
  if (section === 'briefing') el.textContent = lang === 'hi' ? d.briefingHi : d.briefingEn;
  if (section === 'hospital') el.textContent = lang === 'hi' ? d.hospitalHi : d.hospitalEn;
}

function renderPKObjections(objections) {
  const container = document.getElementById('pkObjections');
  if (!container || !objections) return;
  container.innerHTML = objections.map(o => `
    <div style="border:1px solid var(--amber-border);border-radius:var(--r-sm);overflow:hidden;">
      <div style="background:var(--amber-bg);padding:8px 12px;font-size:11px;font-weight:700;color:var(--amber);display:flex;align-items:center;gap:6px;">
        <i class="fa-solid fa-circle-question"></i> ${o.question}
      </div>
      <div style="padding:10px 12px;font-size:12px;color:var(--text);line-height:1.7;">${o.answer}</div>
    </div>
  `).join('');
}

function showPKContent() {
  document.getElementById('pkEmpty').style.display = 'none';
  document.getElementById('pkLoading').style.display = 'none';
  const content = document.getElementById('pkContent');
  content.style.display = 'flex';
  content.style.flexDirection = 'column';
  content.style.gap = '18px';
}

async function generateParentKit() {
  // Don't regenerate if already done for the same patient context
  const ctx = document.getElementById('outPatientName').textContent;
  if (pkState.generated && pkState.patientContext === ctx) return;
  if (ctx === '—' || !ctx) { return; } // no plan yet

  pkState.patientContext = ctx;
  pkState.generated = false;

  document.getElementById('pkEmpty').style.display = 'none';
  document.getElementById('pkContent').style.display = 'none';
  document.getElementById('pkLoading').style.display = 'block';

  const loadMsgs = [
    'Writing parent handout…',
    'Crafting waiting room script…',
    'Building objection responses…',
    'Preparing WhatsApp message…',
    'Writing intern briefing…'
  ];
  let msgIdx = 0;
  const msgInterval = setInterval(() => {
    document.getElementById('pkLoadMsg').textContent = loadMsgs[msgIdx % loadMsgs.length];
    msgIdx++;
  }, 900);

  try {
    // Gather current patient context from the rendered plan
    const name = document.getElementById('outPatientName').textContent;
    const tags = document.getElementById('outTagsRow').textContent.trim();
    const procedure = document.getElementById('procedure')?.options[document.getElementById('procedure')?.selectedIndex]?.text || '';
    const ageGroup = document.getElementById('ageGroup')?.options[document.getElementById('ageGroup')?.selectedIndex]?.text || '';
    const parentProfile = document.getElementById('parentProfile')?.options[document.getElementById('parentProfile')?.selectedIndex]?.text || '';
    const behavior = document.querySelector('input[name="behavior"]:checked')?.value || '';
    const wt = document.getElementById('patientWeight')?.value || '';

    if (state.provider !== 'offline' && state.apiKey.trim()) {
      await generateParentKitAI(name, ageGroup, procedure, behavior, parentProfile, wt);
    } else {
      await generateParentKitOffline(name, ageGroup, procedure, behavior, parentProfile, wt);
    }
  } catch(err) {
    console.error('Parent kit error:', err);
    const name = document.getElementById('outPatientName').textContent;
    const ageGroup = document.getElementById('ageGroup')?.options[document.getElementById('ageGroup')?.selectedIndex]?.text || '';
    const procedure = document.getElementById('procedure')?.options[document.getElementById('procedure')?.selectedIndex]?.text || '';
    const behavior = document.querySelector('input[name="behavior"]:checked')?.value || '';
    const parentProfile = document.getElementById('parentProfile')?.options[document.getElementById('parentProfile')?.selectedIndex]?.text || '';
    const wt = document.getElementById('patientWeight')?.value || '';
    await generateParentKitOffline(name, ageGroup, procedure, behavior, parentProfile, wt);
  } finally {
    clearInterval(msgInterval);
  }
}

async function generateParentKitAI(name, ageGroup, procedure, behavior, parentProfile, wt) {
  const SYSTEM = `You are an expert pediatric dental communication specialist working in an Indian dental college/teaching hospital. Generate a complete parent communication kit. Respond ONLY in this exact JSON (no markdown, no backticks, no preamble):
{
  "handoutEn": "3–4 paragraph plain-English 'What to Expect Today' handout for parent. No jargon. Warm, reassuring tone. Mention the teaching hospital context positively.",
  "handoutHi": "Same handout in natural spoken Hindi (Devanagari script). Warm tone suitable for Indian parents.",
  "briefingEn": "Exact verbal script to say to parent in waiting room BEFORE child enters. Cover: what will happen, how long, parent's role, what NOT to say to child. 150–200 words.",
  "briefingHi": "Same briefing script in natural Hindi (Devanagari).",
  "objections": [
    {"question": "Common parent objection 1 specific to this procedure", "answer": "Confident, empathetic 2–3 sentence response"},
    {"question": "Common parent objection 2", "answer": "Response"},
    {"question": "Common parent objection 3 specific to teaching hospital setting", "answer": "Response"},
    {"question": "Common parent objection 4", "answer": "Response"}
  ],
  "hospitalEn": "Script explaining teaching hospital setup to anxious parent: why students are present, why senior supervises, why it may take longer — framed positively. 100–150 words.",
  "hospitalHi": "Same in Hindi (Devanagari).",
  "whatsapp": "Post-procedure WhatsApp message. Start with child's name. What was done today, 2–3 specific aftercare instructions for this procedure, when to return, a warm closing. Use simple language. 80–100 words. No clinical jargon.",
  "intern": "One-paragraph intern briefing card: key behavior profile, parent profile warning, one critical do and one critical don't for this specific case. Punchy, clinical, 80 words max."
}`;

  const USER = `Patient: ${name}. Age Group: ${ageGroup}. Procedure: ${procedure}. Behavior (Frankl): ${behavior}. Parent Profile: ${parentProfile}. Weight: ${wt || 'not provided'} kg. Setting: Dental College / Teaching Hospital.`;

  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': state.apiKey,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 3000,
      system: SYSTEM,
      messages: [{ role: 'user', content: USER }]
    })
  });
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.error?.message || `API ${resp.status}`);
  const raw = data.content[0].text;
  const clean = raw.replace(/```json|```/g, '').trim();
  try {
    pkState.data = JSON.parse(clean);
    pkState.generated = true;
    renderParentKit();
  } catch (err) {
    console.error('Failed to parse parent kit JSON:', err);
    toast('Error processing Parent Kit data. Please try again.');
  }
}

async function generateParentKitOffline(name, ageGroup, procedure, behavior, parentProfile, wt) {
  // Offline fallback — pre-built templates with variable substitution
  const procLabel = procedure || 'dental procedure';
  const ageLbl = ageGroup || 'child';
  const isAnxious = behavior === 'definitely_negative' || behavior === 'negative';
  const isOverprotective = parentProfile.toLowerCase().includes('overprotective') || parentProfile.toLowerCase().includes('anxious');
  const wtStr = wt ? `(${wt} kg)` : '';

  pkState.data = {
    handoutEn: `Dear Parent / Guardian,

Welcome to our Pediatric Dental Department. Today, ${name} ${wtStr} is scheduled for a ${procLabel}. We want to make sure you feel fully informed and comfortable before we begin.

What will happen: Our clinical team will first spend a few minutes helping ${name} feel at ease with the chair and instruments. We use a technique called Tell-Show-Do — we explain everything before we do it, so there are no surprises for your child.

How long it will take: Please expect the appointment to last approximately 30–45 minutes. Teaching appointments may take a little longer because we ensure every step is done carefully under supervision.

Your role: The most important thing you can do is stay calm and avoid warning your child about pain or needles. Children mirror their parents' emotions. A relaxed parent helps us create a relaxed child.

If you have any questions before we begin, please ask our team. We are here for you and ${name}.`,

    handoutHi: `प्रिय माता-पिता / अभिभावक,

हमारे पीडियाट्रिक डेंटल विभाग में आपका स्वागत है। आज ${name} ${wtStr} के लिए ${procLabel} निर्धारित है। हम चाहते हैं कि आप पूरी तरह से सहज और जानकार महसूस करें।

क्या होगा: हमारी टीम पहले कुछ मिनट ${name} को chair और instruments से परिचित कराएगी। हम Tell-Show-Do तकनीक का उपयोग करते हैं — सब कुछ करने से पहले बताते हैं, ताकि बच्चे को कोई आश्चर्य न हो।

कितना समय लगेगा: कृपया लगभग 30–45 मिनट की अपेक्षा रखें। Teaching appointments में थोड़ा अधिक समय लग सकता है क्योंकि हर कदम carefully किया जाता है।

आपकी भूमिका: सबसे महत्वपूर्ण है कि आप शांत रहें और बच्चे को दर्द या injection के बारे में warning न दें। बच्चे अपने माता-पिता की भावनाएं mirror करते हैं।

कोई भी प्रश्न हो तो हमारी टीम से पूछें।`,

    briefingEn: `"Hello, I'm Dr. [your name]. Before we bring ${name} in, I want to take 2 minutes to brief you so we can work as a team today.

Here's what's going to happen: We'll do a ${procLabel}. The whole thing takes about 30–40 minutes. ${name} may be a little unsure at first — that's completely normal, and we're trained to handle it.

Your job today — and this is really important — is to be calm, quiet, and follow my lead. Please don't say things like 'it won't hurt' or 'don't be scared' — those words actually make children more anxious. If ${name} looks at you, just give a calm smile and a thumbs up.

If I ask you to step outside briefly, it's a standard technique that helps the child feel more independent — not something to worry about.

Any questions before we bring ${name} in?"`,

    briefingHi: `"नमस्ते, मैं Dr. [आपका नाम] हूँ। ${name} को अंदर लाने से पहले, मैं 2 मिनट में आपको brief करना चाहता/चाहती हूँ।

क्या होगा: हम ${procLabel} करेंगे। पूरा समय लगभग 30–40 मिनट है। ${name} पहले थोड़ा uncertain हो सकता/सकती है — यह बिल्कुल normal है।

आपका काम — और यह बहुत important है — शांत रहना, quiet रहना, और मेरे lead को follow करना। कृपया यह न कहें: 'दर्द नहीं होगा' या 'डरो मत' — ये शब्द बच्चों को और anxious बनाते हैं। अगर ${name} आपकी तरफ देखे, बस एक शांत मुस्कान और thumbs up दें।

अगर मैं आपको थोड़ी देर के लिए बाहर जाने को कहूँ, यह एक standard technique है जो बच्चे को more independent feel कराती है।

कोई सवाल?"`,

    objections: [
      {
        question: `"Why does my child need an injection / anaesthesia?"`,
        answer: `Local anaesthesia ensures ${name} feels absolutely no pain during the procedure. Without it, even a small amount of discomfort can create lasting dental fear. We apply a numbing gel first so the injection itself is barely felt — most children are surprised by how easy it is.`
      },
      {
        question: `"Why are there students in the room? I want a senior doctor only."`,
        answer: `Our clinical students work under direct, real-time supervision of qualified faculty — similar to how teaching hospitals work across medicine. In fact, teaching cases receive more careful attention because every step is reviewed. Your child is in safe, thoroughly supervised hands.`
      },
      {
        question: `"Can't you just fill the tooth without drilling?"`,
        answer: `We always use the minimum necessary intervention. For ${procLabel}, removing the decay is essential — otherwise the infection spreads deeper and the tooth cannot be saved. Leaving decay and just placing filling material on top would actually make things worse over time.`
      },
      {
        question: `"My child was traumatised at another clinic. Is this going to be the same?"`,
        answer: `That's exactly why we do things differently here. We never rush, we explain every step before doing it, and we stop if your child signals discomfort. Our entire approach is designed for children who've had difficult experiences before. Many of our most cooperative patients started exactly where ${name} is today.`
      }
    ],

    hospitalEn: `"I want to quickly explain how our department works so you feel fully comfortable.

You'll notice there are a few team members in the room — a senior faculty doctor and clinical students. This is how dental colleges function worldwide. The student performs the procedure under direct, real-time supervision of our faculty, who guides and checks every step. Think of it like a pilot with a co-pilot and air traffic control — multiple trained eyes watching.

This actually means your child receives more careful, thorough treatment than a solo private clinic where one person works alone. We take extra time because we do things right.

We're glad you chose us for ${name}'s care."`,

    hospitalHi: `"मैं quickly explain करना चाहता/चाहती हूँ कि हमारा department कैसे काम करता है।

आप देखेंगे कि room में कुछ team members हैं — एक senior faculty doctor और clinical students। यह दुनियाभर के dental colleges में ऐसे ही होता है। Student procedure करता है senior faculty की direct supervision में, जो हर step guide और check करते हैं। यह एक pilot और air traffic control की तरह है — multiple trained नज़रें।

इसका मतलब है ${name} को एक solo private clinic से कहीं ज़्यादा careful और thorough treatment मिलती है। हम extra time लेते हैं क्योंकि हम सही तरीके से काम करते हैं।

हमें खुशी है कि आपने ${name} की care के लिए हमें चुना।"`,

    whatsapp: `Hi! 🦷 This is Dr. [name] from the Pediatric Dental Dept.

${name} did really well today! We completed the ${procLabel} successfully.

A few things to keep in mind:
• Avoid very hot or cold foods for 2–3 hours
• Some mild soreness is normal — Paracetamol syrup as needed
• No rinsing vigorously today

Please come back on [next appointment date]. If you notice any swelling, prolonged pain, or have any concerns, call us directly.

${name} was very brave today — please give lots of praise! 😊`,

    intern: `CASE BRIEF — ${name} | ${ageGroup} | ${procLabel}

Behavior: ${behavior === 'definitely_negative' ? 'Frankl 1 — DEFINITELY NEGATIVE. Expect resistance. Do NOT rush.' : behavior === 'negative' ? 'Frankl 2 — Negative/Anxious. Use full TSD. Go slow.' : 'Frankl 3–4. Standard TSD. Should be manageable.'}

Parent: ${parentProfile}. ${isOverprotective ? '⚠️ HIGH RISK of anxiety transmission — brief parent firmly before child enters.' : 'Parent briefed. Follow standard protocol.'}

✅ DO: Narrate every step. Use Tell-Show-Do. Give child control signals (raise hand to pause).
❌ DON'T: Rush. Don't say "it won't hurt." Don't let parent speak once child is in chair.

Faculty is supervising. Call immediately if child escalates to Frankl 1.`
  };

  pkState.generated = true;
  renderParentKit();
}

function renderParentKit() {
  const d = pkState.data;
  if (!d) return;

  // Render all sections
  document.getElementById('pkHandoutContent').textContent = d.handoutEn;
  document.getElementById('pkBriefingContent').textContent = d.briefingEn;
  document.getElementById('pkHospitalContent').textContent = d.hospitalEn;
  document.getElementById('pkWhatsapp').textContent = d.whatsapp;
  document.getElementById('pkIntern').textContent = d.intern;
  renderPKObjections(d.objections);

  // Reset lang buttons
  pkState.langs = { handout: 'en', briefing: 'en', hospital: 'en' };

  showPKContent();
  toast('Parent Communication Kit ready!');
}

function copyWhatsapp() {
  const txt = document.getElementById('pkWhatsapp').textContent;
  navigator.clipboard.writeText(txt).then(() => {
    toast('WhatsApp message copied!');
  }).catch(err => {
    console.error('Clipboard error:', err);
    toast('Failed to copy to clipboard');
  });
}

function copyParentKit() {
  const d = pkState.data;
  if (!d) return;
  const txt = [
    '=== WHAT TO EXPECT TODAY (EN) ===\n' + d.handoutEn,
    '\n=== WAITING ROOM BRIEFING (EN) ===\n' + d.briefingEn,
    '\n=== TEACHING HOSPITAL EXPLAINER (EN) ===\n' + d.hospitalEn,
    '\n=== WHATSAPP MESSAGE ===\n' + d.whatsapp,
    '\n=== INTERN BRIEFING ===\n' + d.intern
  ].join('\n');
  navigator.clipboard.writeText(txt).then(() => {
    toast('Full Parent Kit copied to clipboard!');
  }).catch(err => {
    console.error('Clipboard error:', err);
    toast('Failed to copy to clipboard');
  });
}
// ─── END PARENT KIT ──────────────────────────────────────────────

const KHER_DRUGS = [
  {
    id: 'tblAmox',
    name: 'Amox+Clav',
    icon: 'fa-capsules',
    rows: [
      {min:7,max:9,label:'4ml BD (228.5mg)'},
      {min:9,max:11,label:'5ml BD (228.5mg)'},
      {min:11,max:13,label:'6ml BD (228.5mg)'},
      {min:13,max:15.5,label:'7.5ml BD (228.5mg)'},
      {min:15.5,max:18,label:'4ml BD (457mg)'},
      {min:18,max:22,label:'5ml BD (457mg)'},
      {min:22,max:26,label:'6ml BD (457mg)'},
      {min:26,max:29,label:'7ml BD (457mg)'},
      {min:29,max:35,label:'7.5ml BD (457mg)'},
    ]
  },
  {
    id: 'tblCefad',
    name: 'Cefadroxil',
    icon: 'fa-pills',
    rows: [
      {min:6,max:8,label:'2.5ml BD'},
      {min:8,max:13,label:'3ml BD'},
      {min:13,max:18,label:'5ml BD'},
      {min:18,max:22.5,label:'6ml BD'},
      {min:22.5,max:27.5,label:'7.5ml BD'},
      {min:27.5,max:35,label:'9ml BD'},
    ]
  },
  {
    id: 'tblMetro',
    name: 'Metronidazole',
    icon: 'fa-flask',
    rows: [
      {min:6,max:9,label:'2ml TDS'},
      {min:9,max:11,label:'2.5ml TDS'},
      {min:11,max:14,label:'3ml TDS'},
      {min:14,max:18,label:'4ml TDS'},
      {min:18,max:22,label:'5ml TDS'},
      {min:22,max:26,label:'6ml TDS'},
      {min:26,max:35,label:'7ml TDS'},
    ]
  },
  {
    id: 'tblPara',
    name: 'Paracetamol',
    icon: 'fa-droplet',
    rows: [
      {min:6,max:9,label:'4ml 4–6hrly'},
      {min:9,max:11,label:'5ml 4–6hrly'},
      {min:11,max:13.5,label:'6ml 4–6hrly'},
      {min:13.5,max:17.5,label:'7.5ml 4–6hrly'},
      {min:17.5,max:22,label:'5ml DS 4–6hrly'},
      {min:22,max:27,label:'6ml DS 4–6hrly'},
      {min:27,max:35,label:'7.5ml DS 4–6hrly'},
    ]
  },
  {
    id: 'tblIbupro',
    name: 'Ibuprofen',
    icon: 'fa-fire-flame-curved',
    rows: [
      {min:4,max:8,label:'2.5ml 6hrly'},
      {min:8,max:11,label:'4ml 6hrly'},
      {min:11,max:15,label:'5ml 6hrly'},
      {min:15,max:21,label:'7.5ml 6hrly'},
      {min:21,max:27,label:'10ml 6hrly'},
      {min:27,max:35,label:'12ml 6hrly'},
    ]
  }
];

function getDrugDoseForWeight(drug, wt) {
  for (const r of drug.rows) {
    if (wt >= r.min && wt < r.max) return r.label;
  }
  if (wt >= drug.rows[drug.rows.length-1].max) return drug.rows[drug.rows.length-1].label + ' (max)';
  return null;
}

function highlightDrugTables(wt) {
  KHER_DRUGS.forEach(drug => {
    const tbl = document.getElementById(drug.id);
    if (!tbl) return;
    const rows = tbl.querySelectorAll('tbody tr');
    rows.forEach(row => {
      const min = parseFloat(row.dataset.min);
      const max = parseFloat(row.dataset.max);
      if (wt >= min && wt < max) {
        row.style.background = 'var(--green-bg)';
        row.style.fontWeight = '700';
        row.style.outline = '2px solid var(--green)';
        row.style.outlineOffset = '-1px';
      } else {
        row.style.background = '';
        row.style.fontWeight = '';
        row.style.outline = '';
      }
    });
  });
}

function updateDosagePreview() {
  const wt = parseFloat(document.getElementById('patientWeight').value);
  const card = document.getElementById('dosagePreviewCard');
  const content = document.getElementById('dosagePreviewContent');
  const label = document.getElementById('previewWeightLabel');

  if (!wt || wt < 3) { card.style.display = 'none'; return; }

  label.textContent = wt + ' kg';
  let html = '';
  KHER_DRUGS.forEach(drug => {
    const dose = getDrugDoseForWeight(drug, wt);
    if (dose) {
      html += `<div style="background:white;border:1px solid var(--green-border);border-radius:var(--r-sm);padding:6px 8px;">
        <div style="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--green);margin-bottom:2px;">${drug.name}</div>
        <div style="font-size:11px;font-weight:700;color:var(--text);font-family:var(--mono);">${dose}</div>
      </div>`;
    }
  });
  content.innerHTML = html;
  card.style.display = 'block';

  // Also highlight tables if already visible
  highlightDrugTables(wt);
}

// Chair script state
let chairLang = 'en';
let currentChairScript = null;

function setChairLang(lang) {
  chairLang = lang;
  document.getElementById('csLangEn').style.cssText = lang === 'en'
    ? 'padding:4px 12px;border-radius:6px;border:1px solid var(--accent);background:var(--accent);color:white;font-size:12px;font-weight:600;cursor:pointer;'
    : 'padding:4px 12px;border-radius:6px;border:1px solid var(--border);background:transparent;color:var(--text2);font-size:12px;font-weight:600;cursor:pointer;';
  document.getElementById('csLangHi').style.cssText = lang === 'hi'
    ? 'padding:4px 12px;border-radius:6px;border:1px solid var(--accent);background:var(--accent);color:white;font-size:12px;font-weight:600;cursor:pointer;'
    : 'padding:4px 12px;border-radius:6px;border:1px solid var(--border);background:transparent;color:var(--text2);font-size:12px;font-weight:600;cursor:pointer;';
  if (currentChairScript) renderChairScript(currentChairScript);
}

function getChairScriptKey(ageGroup, behavior, procedure) {
  const procMap = { restoration:'restoration', exam:'exam', pulpectomy:'pulpectomy', extraction:'extraction', sdf:'sdf', spacemaintainer:'restoration', xray:'exam', ssc:'restoration', fluoride:'sdf', habit:'exam', trauma:'extraction' };
  const proc = procMap[procedure] || 'exam';
  const key = `${ageGroup}_${behavior}_${proc}`;
  if (CHAIR_SCRIPTS[key]) return key;
  const fallbacks = [
    `${ageGroup}_negative_${proc}`,
    `${ageGroup}_definitely_negative_${proc}`,
    `${ageGroup}_positive_${proc}`,
    `${ageGroup}_negative_exam`,
    `${ageGroup}_definitely_negative_exam`
  ];
  for (const k of fallbacks) { if (CHAIR_SCRIPTS[k]) return k; }
  return null;
}

function renderChairScript(steps) {
  const phaseColors = { ENTER:'var(--blue)', RAPPORT:'var(--green)', INTRODUCE:'var(--amber)', PROCEDURE:'var(--accent)', CLOSE:'var(--text2)' };
  const phaseBg = { ENTER:'var(--blue-bg)', RAPPORT:'var(--green-bg)', INTRODUCE:'var(--amber-bg)', PROCEDURE:'var(--accent-bg)', CLOSE:'var(--surface2)' };
  const phaseBorder = { ENTER:'var(--blue-border)', RAPPORT:'var(--green-border)', INTRODUCE:'var(--amber-border)', PROCEDURE:'var(--accent-border)', CLOSE:'var(--border)' };
  let html = '';
  steps.forEach((step, i) => {
    const color = phaseColors[step.phase] || 'var(--text2)';
    const bg = phaseBg[step.phase] || 'var(--surface2)';
    const border = phaseBorder[step.phase] || 'var(--border)';
    const text = chairLang === 'hi' ? step.hi : step.en;
    html += `<div style="margin-bottom:12px;border-radius:var(--r);border:1px solid ${border};overflow:hidden;">
      <div style="padding:8px 14px;background:${bg};display:flex;align-items:center;gap:8px;border-bottom:1px solid ${border};">
        <span style="background:${color};color:white;font-size:9px;font-weight:700;letter-spacing:.06em;padding:2px 8px;border-radius:20px;text-transform:uppercase;">${step.phase}</span>
        <span style="font-size:12px;font-weight:600;color:var(--text);">${step.label}</span>
        <span style="margin-left:auto;font-size:10px;color:var(--text3);">Step ${i+1} of ${steps.length}</span>
      </div>
      <div style="padding:12px 14px;font-size:13px;color:var(--text);line-height:1.75;${chairLang==='hi'?'':'font-style:italic;'}">${text}</div>
    </div>`;
  });
  document.getElementById('outChairScript').innerHTML = html;
}

// ─── (existing code continues below) ────────────────────────────
async function callAiEngine(name, ageGroup, procedure, behavior, parentProfile, visitHistory, flags) {

  const SYSTEM_PROMPT = `You are an expert Pediatric Dentist at a DCI-accredited dental institution in India. The institution follows Marwah 5th Edition as the primary textbook alongside Shobha Tandon 3rd Edition and DCI 2022 curriculum. Your knowledge base is primarily Nikhil Marwah 5th Edition (Jaypee 2024), Shobha Tandon 3rd Edition, and DCI 2022 curriculum. You generate India-specific, practical clinical game plans for Indian children. You are deeply aware of: Joint Family dynamics, overprotective Indian mothers, limited N2O availability in private Indian clinics, high ECC prevalence, and the cultural contexts of Indian pediatric patients across different regions.

Respond ONLY in this exact JSON format (no markdown, no preamble, no backticks):
{
  "success": "X%",
  "duration": "XX–XX min",
  "durationTip": "one clinical tip about time management",
  "protocol": "Primary protocol name with Marwah chapter reference",
  "stratTitle": "Strategy name",
  "stratDesc": "3–4 sentence detailed strategy rooted in Marwah/Tandon techniques",
  "cultural": "Specific India/cultural context note relevant to this case",
  "techniques": ["technique1","technique2","technique3","technique4"],
  "checklist": ["prep step 1","prep step 2","prep step 3","prep step 4"],
  "escalation": [
    {"title":"Step 1 name","desc":"description"},
    {"title":"Step 2 name","desc":"description"},
    {"title":"Step 3 name","desc":"description"}
  ],
  "drugs": [
    {"name":"drug name","dose":"X mg/kg","note":"note"},
    {"name":"drug name","dose":"X mg/kg","note":"note"}
  ],
  "drugNote": "India-specific drug availability/formulary note",
  "scriptEn": "Exact English verbal script — directive, not requesting",
  "scriptHi": "Exact Hindi verbal script — natural spoken Hindi in Devanagari",
  "scriptNote": "*Clinical rationale for the script approach",
  "parentTactics": "India-specific parent management tactics for this parent profile",
  "failures": ["trap1","trap2","trap3","trap4"],
  "flagActions": "Actions for any clinical flags mentioned"
}`;

  const wt = parseFloat(document.getElementById('patientWeight')?.value) || null;
  const wtStr = wt ? `Child weight: ${wt} kg — calculate actual mg doses in the drugs array.` : 'Weight not provided — use mg/kg only.';
  const USER_PROMPT = `Patient: ${name}. Age Group: ${ageGroup}. Procedure: ${procedure}. Behavior (Frankl): ${behavior}. Parent Profile: ${parentProfile}. Visit History: ${visitHistory}. ${wtStr} Special Flags: ${flags.join(', ') || 'none'}.`;

  let raw = '';

  // ── ANTHROPIC (Claude) ──────────────────────────────────────────
  if (state.provider === 'anthropic') {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': state.apiKey,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 2000,
        system: SYSTEM_PROMPT,
        messages: [{ role: 'user', content: USER_PROMPT }]
      })
    });
    if (!resp.ok) {
      const errorData = await resp.json().catch(() => ({ error: { message: 'Unknown error' } }));
      throw new Error(errorData.error?.message || `Anthropic API error (${resp.status})`);
    }
    const data = await resp.json();
    raw = data.content[0].text;
  }

  // ── GOOGLE GEMINI FLASH ─────────────────────────────────────────
  else if (state.provider === 'google') {
    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${state.apiKey}`,
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
          contents: [{ parts: [{ text: USER_PROMPT }] }],
          generationConfig: { responseMimeType: 'application/json', temperature: 0.4, maxOutputTokens: 2000 }
        })
      }
    );
    if (!resp.ok) {
      const errorData = await resp.json().catch(() => ({ error: { message: 'Unknown error' } }));
      throw new Error(errorData.error?.message || `Gemini API error (${resp.status})`);
    }
    const data = await resp.json();
    raw = data.candidates[0].content.parts[0].text;
  }

  // ── ALIBABA QWEN TURBO ──────────────────────────────────────────
  else if (state.provider === 'qwen') {
    const resp = await fetch('https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${state.apiKey}`,
        'content-type': 'application/json'
      },
      body: JSON.stringify({
        model: 'qwen-turbo',
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: USER_PROMPT }
        ],
        max_tokens: 2000,
        temperature: 0.4
      })
    });
    if (!resp.ok) {
      const errorData = await resp.json().catch(() => ({ error: { message: 'Unknown error' } }));
      throw new Error(errorData.error?.message || `Qwen API error (${resp.status})`);
    }
    const data = await resp.json();
    raw = data.choices[0].message.content;
  }

  // ── PARSE & RENDER ──────────────────────────────────────────────
  const clean = raw.replace(/```json|```/g, '').trim();
  let payload;
  try {
    payload = JSON.parse(clean);
  } catch (err) {
    console.error('Failed to parse game plan JSON:', err);
    toast('Error processing game plan data. Please try again.');
    return;
  }

  const providerLabels = { anthropic: 'Live Claude AI', google: 'Live Gemini Flash AI', qwen: 'Live Qwen Turbo AI' };
  document.getElementById('planModeLabel').textContent = `${providerLabels[state.provider] || 'Live AI'} — India Clinical Mode`;
  renderPlan(payload, name, ageGroup, procedure, behavior, parentProfile, visitHistory, flags);

  toast(`${providerLabels[state.provider] || 'AI'} game plan ready!`);
}
