/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * PedoPlan Export & Sharing System (see APP_CONFIG.version)
 * ───────────────────────────────────────────────────────────────────────────────
 * Plan serialization, multi-format export (PDF, JSON, HTML, Image),
 * and shareable link generation. All exports tracked via monetization engine.
 * ═══════════════════════════════════════════════════════════════════════════════
 */

const PedoPlanExport = {
  
  // ──── SERIALIZE CURRENT PLAN ─────────────────────────────────────────────
  // Captures all current form data + generated plan into single JSON object
  serializeCurrentPlan: function() {
    const plan = {
      id: `plan_${Date.now()}`,
      version: '1.0',
      createdAt: new Date().toISOString(),
      
      // INPUT DATA
      patient: {
        name: document.getElementById('patientName')?.value || 'Unknown',
        weight: document.getElementById('patientWeight')?.value || '',
        weightUnit: 'kg'
      },
      
      clinical: {
        ageGroup: document.getElementById('ageGroup')?.value || '',
        behavior: document.getElementById('behavior')?.value || '',
        procedure: document.getElementById('procedure')?.value || '',
        parentProfile: document.getElementById('parentProfile')?.value || '',
        visitHistory: document.getElementById('visitHistory')?.value || ''
      },
      
      flags: Array.from(document.querySelectorAll('input[name="flag"]:checked'))
        .map(el => el.value),
      
      // OUTPUT DATA (rendered plan)
      output: {
        success: document.getElementById('outSuccess')?.textContent || '',
        duration: document.getElementById('outDuration')?.textContent || '',
        protocol: document.getElementById('outProtocol')?.textContent || '',
        strategy: {
          title: document.getElementById('outStratTitle')?.textContent || '',
          description: document.getElementById('outStratDesc')?.textContent || ''
        },
        cultural: document.getElementById('outCultural')?.textContent || '',
        techniques: Array.from(document.querySelectorAll('#outTechniques li'))
          .map(li => li.textContent.trim()),
        checklist: Array.from(document.querySelectorAll('#outChecklist li'))
          .map(li => li.textContent.trim()),
        escalation: this.parseTableRows('outEscalation'),
        drugs: this.parseTableRows('outDrugs'),
        parentTactics: document.getElementById('outParentTactics')?.textContent || '',
        failures: Array.from(document.querySelectorAll('#outFailures li'))
          .map(li => li.textContent.trim()),
        scriptEn: document.getElementById('outScriptEn')?.textContent || '',
        scriptHi: document.getElementById('outScriptHi')?.textContent || ''
      },
      
      // METADATA
      metadata: {
        aiProvider: document.getElementById('planModeLabel')?.textContent || 'Unknown',
        language: chairLang || 'en',
        exportedAt: new Date().toISOString()
      }
    };
    
    return plan;
  },

  // ──── PARSE TABLE ROWS ──────────────────────────────────────────────────
  parseTableRows: function(elementId) {
    const table = document.getElementById(elementId);
    if (!table) return [];
    
    return Array.from(table.querySelectorAll('tbody tr')).map(row => {
      const cells = row.querySelectorAll('td');
      return Object.fromEntries(
        Array.from(cells).map((cell, i) => [
          `col${i}`,
          cell.textContent.trim()
        ])
      );
    });
  },

  // ──── EXPORT AS JSON ────────────────────────────────────────────────────
  exportJSON: function(plan = null) {
    const planData = plan || this.serializeCurrentPlan();
    const json = JSON.stringify(planData, null, 2);
    
    // Trigger download
    this.downloadFile(json, `kiddokanine_${planData.patient.name}_${Date.now()}.json`, 'application/json');
    
    return planData;
  },

  // ──── EXPORT AS PDF ─────────────────────────────────────────────────────
  // Desktop mode: Uses Electron's built-in PDF generation
  // Web mode: Uses html2pdf library
  exportPDF: async function(plan = null) {
    const planData = plan || this.serializeCurrentPlan();
    
    // Check if running in Electron (desktop app)
    const isElectron = window.electronAPI && window.electronAPI.isElectron;
    
    if (isElectron) {
      // Use Electron's print to PDF feature
      toast('Preparing PDF... Opening print dialog');
      setTimeout(() => {
        window.print(); // Electron can save as PDF from print dialog
      }, 300);
      return;
    }
    
    // Web version: use html2pdf library
    if (typeof html2pdf === 'undefined') {
      console.error('html2pdf library not loaded.');
      alert('PDF export not available. Please use Print → Save as PDF instead.');
      return;
    }
    
    const html = this.generatePDFHTML(planData);
    
    const options = {
      margin: 10,
      filename: `kiddokanine_${planData.patient.name}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { orientation: 'portrait', unit: 'mm', format: 'a4' }
    };
    
    try {
      await html2pdf().set(options).from(html).save();
      toast('PDF exported successfully!');
    } catch (err) {
      console.error('PDF export failed:', err);
      alert('PDF export failed. Please try Print → Save as PDF instead.');
    }
  },

  // ──── GENERATE PDF HTML ──────────────────────────────────────────────────
  generatePDFHTML: function(planData) {
    const p = planData;
    const renderTable = (items, headers) => {
      let html = `<table style="width:100%;border-collapse:collapse;margin:10px 0;">
        <thead><tr>`;
      headers.forEach(h => {
        html += `<th style="border:1px solid #ddd;padding:8px;background:#f0f0f0;text-align:left;">${h}</th>`;
      });
      html += `</tr></thead><tbody>`;
      items.forEach(item => {
        html += `<tr>`;
        headers.forEach((_, i) => {
          html += `<td style="border:1px solid #ddd;padding:8px;">${item[`col${i}`] || ''}</td>`;
        });
        html += `</tr>`;
      });
      html += `</tbody></table>`;
      return html;
    };
    
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; color: #333; line-height: 1.6; }
          h1 { color: #003087; border-bottom: 2px solid #003087; padding-bottom: 10px; }
          h2 { color: #003087; margin-top: 20px; }
          .header { text-align: center; margin-bottom: 20px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
          .section { margin-bottom: 20px; }
          .label { font-weight: bold; color: #555; }
          .value { padding-left: 10px; }
          .success-badge { background: #2d7a4f; color: white; padding: 10px; border-radius: 5px; display: inline-block; margin: 10px 0; }
          table { margin: 10px 0; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>KIDDOKANINE Clinical Game Plan</h1>
          <p><strong>Pediatric &amp; Preventive Dentistry Clinical Tool</strong></p>
          <p>Generated: ${new Date(p.createdAt).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
        </div>

        <div class="section">
          <h2>Patient Information</h2>
          <p><span class="label">Name:</span> <span class="value">${p.patient.name}</span></p>
          <p><span class="label">Weight:</span> <span class="value">${p.patient.weight || 'Not specified'} ${p.patient.weightUnit}</span></p>
        </div>

        <div class="section">
          <h2>Clinical Details</h2>
          <p><span class="label">Age Group:</span> <span class="value">${p.clinical.ageGroup}</span></p>
          <p><span class="label">Behavior (Frankl):</span> <span class="value">${p.clinical.behavior}</span></p>
          <p><span class="label">Procedure:</span> <span class="value">${p.clinical.procedure}</span></p>
          <p><span class="label">Parent Profile:</span> <span class="value">${p.clinical.parentProfile}</span></p>
          ${p.flags.length > 0 ? `<p><span class="label">Clinical Flags:</span> <span class="value">${p.flags.join(', ')}</span></p>` : ''}
        </div>

        <div class="section">
          <h2>Clinical Game Plan</h2>
          <div class="success-badge">Success Probability: ${p.output.success}</div>
          <p><span class="label">Protocol:</span> <span class="value">${p.output.protocol}</span></p>
          <p><span class="label">Duration:</span> <span class="value">${p.output.duration}</span></p>
        </div>

        <div class="section">
          <h2>Strategy</h2>
          <p><strong>${p.output.strategy.title}</strong></p>
          <p>${p.output.strategy.description}</p>
        </div>

        <div class="section">
          <h2>Cultural Context</h2>
          <p>${p.output.cultural}</p>
        </div>

        <div class="section">
          <h2>Key Techniques</h2>
          <ul>${p.output.techniques.map(t => `<li>${t}</li>`).join('')}</ul>
        </div>

        <div class="section">
          <h2>Preparation Checklist</h2>
          <ul>${p.output.checklist.map(c => `<li>${c}</li>`).join('')}</ul>
        </div>

        ${p.output.escalation.length > 0 ? `
        <div class="section">
          <h2>Escalation Ladder</h2>
          ${renderTable(p.output.escalation, ['Step', 'Description'])}
        </div>
        ` : ''}

        ${p.output.drugs.length > 0 ? `
        <div class="section">
          <h2>Pharmacology</h2>
          ${renderTable(p.output.drugs, ['Drug', 'Dose', 'Note'])}
        </div>
        ` : ''}

        <div class="section">
          <h2>Parent Management</h2>
          <p>${p.output.parentTactics}</p>
        </div>

        <div class="section">
          <h2>Common Pitfalls to Avoid</h2>
          <ul>${p.output.failures.map(f => `<li>${f}</li>`).join('')}</ul>
        </div>

        ${p.output.scriptEn ? `
        <div class="section">
          <h2>Chair Script (English)</h2>
          <p style="padding:10px;background:#f9f9f9;border-left:3px solid #003087;">${p.output.scriptEn}</p>
        </div>
        ` : ''}

        ${p.output.scriptHi ? `
        <div class="section">
          <h2>Chair Script (Hindi)</h2>
          <p style="padding:10px;background:#f9f9f9;border-left:3px solid #b5401a;font-size:16px;">${p.output.scriptHi}</p>
        </div>
        ` : ''}

        <div style="margin-top:40px;padding-top:20px;border-top:1px solid #ddd;font-size:11px;color:#999;text-align:center;">
          <p>KIDDOKANINE · Pediatric Dentistry Clinical Assistant</p>
          <p>Grounded in: Nikhil Marwah 5th Ed. · Shobha Tandon 3rd Ed. · DCI Curriculum 2022</p>
          <p>Export Date: ${new Date().toLocaleDateString('en-IN')} · Beta Build · Proprietary Software</p>
        </div>
      </body>
      </html>
    `;
  },

  // ──── EXPORT AS HTML ────────────────────────────────────────────────────
  exportHTML: function(plan = null) {
    const planData = plan || this.serializeCurrentPlan();
    const html = this.generatePDFHTML(planData);
    
    this.downloadFile(html, `kiddokanine_${planData.patient.name}.html`, 'text/html');
    return planData;
  },

  // ──── EXPORT AS IMAGE (PNG) ──────────────────────────────────────────────
  // Desktop mode: Falls back to print or shows helpful message
  // Web mode: Captures visible plan area as image
  exportAsImage: async function() {
    const isElectron = window.electronAPI && window.electronAPI.isElectron;
    
    if (isElectron) {
      // Electron doesn't support html2canvas easily - suggest alternative
      if (confirm('Image export: Use Print dialog and select "Save as PDF" or "Microsoft Print to PDF".\n\nOpen print dialog now?')) {
        window.print();
      }
      return;
    }
    
    try {
      // Check if html2canvas is available
      if (typeof html2canvas === 'undefined') {
        alert('Image export not available. Please use Print → Save as PDF instead.');
        return;
      }
      
      const planData = this.serializeCurrentPlan();
      const element = document.querySelector('[id^="outTab_"]') || document.getElementById('planArea');
      
      if (!element) {
        alert('No plan to export. Generate a plan first.');
        return;
      }
      
      const canvas = await html2canvas(element, {
        scale: 2,
        backgroundColor: '#fefcf8',
        logging: false
      });
      
      canvas.toBlob(blob => {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `kiddokanine_${planData.patient.name}_${Date.now()}.png`;
        link.click();
        URL.revokeObjectURL(url);
        
        toast('Plan exported as image!');
      });
    } catch (err) {
      console.error('Image export failed:', err);
      alert('Image export failed. Please use Print → Save as PDF instead.');
    }
  },

  // ──── COPY PLAN TO CLIPBOARD ────────────────────────────────────────────
  copyToClipboard: function() {
    const plan = this.serializeCurrentPlan();
    const json = JSON.stringify(plan, null, 2);
    
    navigator.clipboard.writeText(json).then(() => {
      toast('Plan copied to clipboard!');
    }).catch(err => {
      console.error('Clipboard copy failed:', err);
      alert('Failed to copy to clipboard.');
    });
  },

  // ──── GENERATE SHAREABLE LINK ───────────────────────────────────────────
  // Encodes plan data in URL fragment (client-side, no backend needed)
  generateShareLink: function() {
    const plan = this.serializeCurrentPlan();
    const encoded = btoa(JSON.stringify(plan));
    const shareUrl = `${window.location.origin}${window.location.pathname}#shared=${encoded}`;
    
    return {
      url: shareUrl,
      qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(shareUrl)}`
    };
  },

  // ──── LOAD FROM SHARED LINK ────────────────────────────────────────────
  loadFromSharedLink: function(hash) {
    try {
      const match = hash.match(/shared=([^&]+)/);
      if (!match) return null;
      
      const decoded = atob(match[1]);
      let plan;
      try {
        plan = JSON.parse(decoded);
      } catch (err) {
        console.error('Failed to parse shared plan data:', err);
        toast('Invalid shared plan link. Data may be corrupted.');
        return null;
      }
      
      // Populate form fields
      if (plan.patient) {
        document.getElementById('patientName').value = plan.patient.name;
        document.getElementById('patientWeight').value = plan.patient.weight;
      }
      
      if (plan.clinical) {
        document.getElementById('ageGroup').value = plan.clinical.ageGroup;
        document.getElementById('behavior').value = plan.clinical.behavior;
        document.getElementById('procedure').value = plan.clinical.procedure;
        document.getElementById('parentProfile').value = plan.clinical.parentProfile;
        document.getElementById('visitHistory').value = plan.clinical.visitHistory;
      }
      
      // Restore flags
      if (plan.flags && plan.flags.length > 0) {
        plan.flags.forEach(flag => {
          const checkbox = document.querySelector(`input[name="flag"][value="${flag}"]`);
          if (checkbox) checkbox.checked = true;
        });
      }
      
      toast(`Plan loaded from share link!`);
      return plan;
    } catch (err) {
      console.error('Failed to load shared plan:', err);
      return null;
    }
  },

  // ──── HELPER: DOWNLOAD FILE ────────────────────────────────────────────
  downloadFile: function(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast(`Downloaded: ${filename}`);
  }
};

// ──── ADD EXPORT BUTTON TO UI ────────────────────────────────────────────
// This adds export buttons to the nav after page load
document.addEventListener('DOMContentLoaded', () => {
  // Only add if not already present
  if (document.getElementById('exportMenu')) return;
  
  const navActions = document.querySelector('.nav-actions');
  if (!navActions) return;
  
  // Create dropdown menu
  const menu = document.createElement('div');
  menu.id = 'exportMenu';
  menu.style.cssText = `
    position: relative;
    display: flex;
    align-items: center;
  `;
  
  menu.innerHTML = `
    <button class="nav-btn" id="exportBtn" style="display:flex;align-items:center;gap:6px;">
      <i class="fas fa-download"></i>
      <span>Export</span>
      <i class="fas fa-chevron-down" style="font-size:10px;"></i>
    </button>
    <div id="exportDropdown" style="
      position: absolute;
      top: 100%;
      right: 0;
      background: white;
      border: 1px solid var(--border);
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      z-index: 1000;
      min-width: 160px;
      display: none;
      margin-top: 4px;
    ">
      <button onclick="PedoPlanExport.exportJSON()" style="
        width: 100%;
        padding: 10px 14px;
        border: none;
        background: none;
        text-align: left;
        cursor: pointer;
        font-family: var(--sans);
        font-size: 13px;
        color: var(--text);
        border-bottom: 1px solid var(--border);
      ">📄 JSON</button>
      <button onclick="PedoPlanExport.exportHTML()" style="
        width: 100%;
        padding: 10px 14px;
        border: none;
        background: none;
        text-align: left;
        cursor: pointer;
        font-family: var(--sans);
        font-size: 13px;
        color: var(--text);
        border-bottom: 1px solid var(--border);
      ">🌐 HTML</button>
      <button onclick="PedoPlanExport.exportPDF()" style="
        width: 100%;
        padding: 10px 14px;
        border: none;
        background: none;
        text-align: left;
        cursor: pointer;
        font-family: var(--sans);
        font-size: 13px;
        color: var(--text);
        border-bottom: 1px solid var(--border);
      ">📕 PDF</button>
      <button onclick="PedoPlanExport.exportAsImage()" style="
        width: 100%;
        padding: 10px 14px;
        border: none;
        background: none;
        text-align: left;
        cursor: pointer;
        font-family: var(--sans);
        font-size: 13px;
        color: var(--text);
        border-bottom: 1px solid var(--border);
      ">🖼️ Image</button>
      <button onclick="PedoPlanExport.copyToClipboard()" style="
        width: 100%;
        padding: 10px 14px;
        border: none;
        background: none;
        text-align: left;
        cursor: pointer;
        font-family: var(--sans);
        font-size: 13px;
        color: var(--text);
      ">📋 Copy JSON</button>
    </div>
  `;
  
  navActions.insertBefore(menu, navActions.firstChild);
  
  // Toggle dropdown
  document.getElementById('exportBtn').addEventListener('click', (e) => {
    e.stopPropagation();
    const dropdown = document.getElementById('exportDropdown');
    dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
  });
  
  // Close on outside click
  document.addEventListener('click', () => {
    document.getElementById('exportDropdown').style.display = 'none';
  });
});

