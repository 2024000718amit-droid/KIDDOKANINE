
// ═══════════════════════════════════════════════════════════════
// APPLICATION CONFIG — Single source of truth for branding
// ═══════════════════════════════════════════════════════════════
const APP_CONFIG = {
  authorName: "Dr. Amit Verma",           // Update this for new author
  clinicName: "KIDDOKANINE Dental Clinic",   // Update this for new clinic
  version: "v1.0",                        // Update this for new version
  appName: "KIDDOKANINE"                    // Update this for new app name
};



// ═══════════════════════════════════════════════════════════════
// F2 — PERSISTENT BRANDING
// ═══════════════════════════════════════════════════════════════

const PedoPlanBranding = {

  // ── Patch nav: replace badge text, add ™ and creator credit ──
  patchNav: function() {
    // Update nav badge to v1.0
    const badge = document.querySelector('.nav-badge');
    if (badge) badge.textContent = 'v1.0';

    // Update nav title to include ™
    const title = document.querySelector('.nav-title');
    if (title) {
      title.innerHTML = 'KIDDOKANINE';
    }

    // Add "About / Terms" button to nav
    const navActions = document.querySelector('.nav-actions');
    if (navActions) {
      const aboutBtn = document.createElement('button');
      aboutBtn.className = 'nav-btn';
      aboutBtn.innerHTML = '<i class="fas fa-info-circle"></i> About';
      aboutBtn.onclick = () => PedoPlanTerms.show();
      // Insert before first button
      navActions.insertBefore(aboutBtn, navActions.firstChild);
    }
  },

  // ── Inject persistent footer ──────────────────────────────────
  injectFooter: function() {
    const footer = document.createElement('footer');
    footer.className = 'no-print';
    footer.style.cssText = `
      text-align:center;padding:18px 24px;margin-top:32px;
      border-top:1px solid var(--border);background:var(--surface);
      font-size:11px;color:var(--text3);line-height:1.8;
    `;
    footer.innerHTML = `
      <strong style="color:var(--text2);">${APP_CONFIG.appName}</strong> ·
      Pediatric &amp; Preventive Dentistry Clinical Assistant<br>
      <span style="font-size:10px;">${APP_CONFIG.version} · Proprietary Software · All rights reserved</span>
    `;
    document.body.appendChild(footer);
  },

  init: function() {
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => { this.patchNav(); this.injectFooter(); });
    } else {
      this.patchNav(); this.injectFooter();
    }
  }
};


// ═══════════════════════════════════════════════════════════════
// F3 — ABOUT / TERMS PAGE (modal)
// ═══════════════════════════════════════════════════════════════

const PedoPlanTerms = {

  show: function() {
    // Remove any existing instance
    const old = document.getElementById('ppTermsModal');
    if (old) old.remove();

    const modal = document.createElement('div');
    modal.id = 'ppTermsModal';
    modal.style.cssText = `
      position:fixed;inset:0;z-index:50000;
      background:rgba(20,15,10,.6);backdrop-filter:blur(4px);
      display:flex;align-items:center;justify-content:center;padding:16px;overflow-y:auto;
    `;
    modal.addEventListener('click', e => { if(e.target === modal) modal.remove(); });

    modal.innerHTML = `
      <div style="
        background:var(--surface);border:1px solid var(--border);border-radius:16px;
        max-width:580px;width:100%;padding:32px;position:relative;
        box-shadow:0 20px 60px rgba(0,0,0,0.18);max-height:90vh;overflow-y:auto;
      ">
        <button onclick="document.getElementById('ppTermsModal').remove();" style="
          position:absolute;top:16px;right:16px;background:none;border:none;
          font-size:24px;cursor:pointer;color:var(--text3);line-height:1;
        ">×</button>

        <!-- Header -->
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:24px;">
          <div style="width:48px;height:48px;background:var(--accent);border-radius:12px;display:flex;align-items:center;justify-content:center;color:white;font-size:22px;">🦷</div>
          <div>
            <div style="font-family:var(--serif);font-size:22px;line-height:1.1;">
              KIDDOKANINE
            </div>
            <div style="font-size:11px;color:var(--text3);">Pediatric Dentistry Clinical Assistant</div>
          </div>
        </div>

        <!-- Ownership notice -->
        <div style="background:var(--amber-bg);border:1px solid var(--amber-border);border-radius:10px;padding:16px;margin-bottom:20px;">
          <div style="font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--amber);margin-bottom:8px;">
            <i class="fas fa-shield-alt"></i> Proprietary Software Notice
          </div>
          <p style="font-size:13px;color:var(--text);line-height:1.7;margin:0;">
            <strong>KIDDOKANINE is proprietary software.</strong><br>
            Redistribution, resale, reverse engineering, or reproduction without
            the express written permission of the creator is strictly prohibited.
            This software is provided for authorised beta testers only and may not be
            shared, copied, or deployed without a valid licence.
          </p>
        </div>

        <!-- Details grid -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:20px;">
          ${[
            ['Created by',  'KIDDOKANINE Team'],
            ['Department',  'Pediatric &amp; Preventive Dentistry'],
            ['Institution', APP_CONFIG.clinicName],
            ['Version',     APP_CONFIG.version],
            ['Status',      'Invite-Only Beta'],
            ['Licence',     'Proprietary — All rights reserved'],
          ].map(([k,v]) => `
            <div style="background:var(--surface2);border-radius:8px;padding:12px;">
              <div style="font-size:9px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);margin-bottom:3px;">${k}</div>
              <div style="font-size:13px;font-weight:600;color:var(--text);">${v}</div>
            </div>
          `).join('')}
        </div>

        <!-- Clinical grounding -->
        <div style="background:var(--accent-bg);border:1px solid var(--accent-border);border-radius:10px;padding:14px;margin-bottom:20px;">
          <div style="font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--accent);margin-bottom:8px;">
            <i class="fas fa-book-medical"></i> Clinical Reference Basis
          </div>
          <ul style="margin:0;padding-left:16px;font-size:12px;color:var(--text2);line-height:1.9;">
            <li>Nikhil Marwah — Textbook of Pedodontics, 5th Edition</li>
            <li>Shobha Tandon — Textbook of Pedodontics, 3rd Edition</li>
            <li>DCI Curriculum 2022 — Paediatric Dentistry</li>
            <li>AAPD Guidelines 2023–24</li>
            <li>McDonald &amp; Avery — Dentistry for the Child and Adolescent, 10th Ed.</li>
          </ul>
        </div>

        <!-- Disclaimer -->
        <div style="font-size:11px;color:var(--text3);line-height:1.7;border-top:1px solid var(--border);padding-top:16px;">
          <strong style="color:var(--red);">Clinical Disclaimer:</strong>
          KIDDOKANINE generates clinical decision support only. All treatment decisions remain the sole
          responsibility of the qualified clinician. Not a substitute for professional clinical judgement.
          Always verify drug doses before prescribing. For educational and clinical planning use only.
        </div>

        <button onclick="document.getElementById('ppTermsModal').remove();" style="
          margin-top:20px;width:100%;padding:11px;border:none;border-radius:9px;
          background:var(--accent);color:white;font-weight:600;font-size:13px;
          cursor:pointer;font-family:var(--sans);
        ">Close</button>
      </div>
    `;

    document.body.appendChild(modal);
    const escH = e => { if(e.key==='Escape'){modal.remove();document.removeEventListener('keydown',escH);} };
    document.addEventListener('keydown', escH);
  }
};


// ═══════════════════════════════════════════════════════════════
// F4 — ANTI-CASUAL-COPY PROTECTION
// ═══════════════════════════════════════════════════════════════
// NOTE: This is lightweight deterrence only — not DRM.



// ═══════════════════════════════════════════════════════════════
// F5 — WATERMARKING (PDF / HTML exports)
// ═══════════════════════════════════════════════════════════════
// Patches PedoPlanExport.generatePDFHTML to append a watermark
// footer. Called after DOMContentLoaded once exports are ready.

const PedoPlanWatermark = {

  FOOTER_HTML: function() {
    const now = new Date().toLocaleString('en-IN', {
      year:'numeric', month:'long', day:'numeric',
      hour:'2-digit', minute:'2-digit'
    });
    return `
      <div style="
        margin-top:40px;padding:14px 20px;
        border-top:2px solid #003087;
        background:#f5f2ec;border-radius:0 0 8px 8px;
        font-family:Arial,sans-serif;
        display:flex;justify-content:space-between;align-items:center;
        flex-wrap:wrap;gap:8px;
      ">
        <div style="font-size:12px;color:#003087;font-weight:700;">
          🦷 Generated using KIDDOKANINE
        </div>
        <div style="font-size:11px;color:#5a5248;">
          KIDDOKANINE · Pediatric Dentistry · Beta Build
        </div>
        <div style="font-size:10px;color:#8c867e;">
          ${now}
        </div>
      </div>
      <div style="text-align:center;margin-top:8px;font-size:9px;color:#aaa;">
        KIDDOKANINE is proprietary software. Redistribution without permission is prohibited.
      </div>
    `;
  },

  // ── Patch generatePDFHTML to inject watermark ─────────────────
  patchExport: function() {
    if (!window.PedoPlanExport) return;
    const original = PedoPlanExport.generatePDFHTML.bind(PedoPlanExport);
    PedoPlanExport.generatePDFHTML = function(planData) {
      let html = original(planData);
      // Replace the existing footer div in the PDF HTML
      const watermark = PedoPlanWatermark.FOOTER_HTML();
      // Insert before </body>
      html = html.replace('</body>', watermark + '</body>');
      return html;
    };
  },

  init: function() {
    // Patch after all scripts have loaded
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.patchExport());
    } else {
      this.patchExport();
    }
  }
};


// ═══════════════════════════════════════════════════════════════
// F6 — USAGE ANALYTICS + ADMIN PANEL
// ═══════════════════════════════════════════════════════════════

const PedoPlanAnalytics = {

  STORAGE_KEY: 'pp_analytics_v1',

  // ── Default analytics schema ──────────────────────────────────
  _defaults: function() {
    return {
      totalUsers       : 0,
      casesGenerated   : 0,
      procedureCounts  : {},   // { procedure: count }
      franklCounts     : {},   // { 'definitely-negative': count, … }
      sessionDates     : [],   // ISO date strings
      lastUsed         : null
    };
  },

  // ── Load from localStorage ───────────────────────────────────
  load: function() {
    try {
      return JSON.parse(localStorage.getItem(this.STORAGE_KEY)) || this._defaults();
    } catch { return this._defaults(); }
  },

  // ── Save to localStorage ─────────────────────────────────────
  save: function(data) {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
  },

  // ── Track a generic event ─────────────────────────────────────
  event: function(type, meta = {}) {
    const data = this.load();
    data.lastUsed = new Date().toISOString();

    if (type === 'user_login') {
      data.totalUsers = Math.max(data.totalUsers, 1);
      const today = new Date().toISOString().split('T')[0];
      if (!data.sessionDates.includes(today)) data.sessionDates.push(today);
    }

    if (type === 'case_generated') {
      data.casesGenerated++;
      const proc = meta.procedure || 'unknown';
      data.procedureCounts[proc] = (data.procedureCounts[proc] || 0) + 1;
      const fr = meta.frankl || 'unknown';
      data.franklCounts[fr] = (data.franklCounts[fr] || 0) + 1;
    }

    if (type === 'app_unlocked') {
      data.totalUsers = Math.max(data.totalUsers, 1);
    }

    this.save(data);
  },

  // ── Hook into generatePlan to track cases ────────────────────
  // Attaches a passive submit listener to the form so analytics tracking
  // never interferes with the original generatePlan function reference.
  hookGeneratePlan: function() {
    const tryHook = () => {
      const form = document.getElementById('intakeForm');
      if (!form) return;
      form.addEventListener('submit', () => {
        try {
          const proc   = document.getElementById('procedure')?.value || 'unknown';
          const frankl = document.querySelector('.radio-card.selected .radio-label')?.textContent || 'unknown';
          PedoPlanAnalytics.event('case_generated', { procedure: proc, frankl });
        } catch(e) {}
      }, { passive: true });
    };
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', tryHook);
    } else {
      tryHook();
    }
  },

  // ── Top item from a frequency map ────────────────────────────
  _top: function(map) {
    const entries = Object.entries(map || {});
    if (!entries.length) return 'N/A';
    return entries.sort((a,b) => b[1]-a[1])[0][0];
  },

  // ── Show admin panel (triggered by Ctrl+Alt+P) ───────────────
  showPanel: function() {
    const old = document.getElementById('ppAdminPanel');
    if (old) { old.remove(); return; } // toggle

    const data = this.load();
    const lastUsed = data.lastUsed
      ? new Date(data.lastUsed).toLocaleString('en-IN')
      : 'Never';

    const sessionCount = data.sessionDates.length;
    const topProc  = this._top(data.procedureCounts);
    const topFrank = this._top(data.franklCounts);

    // Build procedure breakdown rows
    const procRows = Object.entries(data.procedureCounts || {})
      .sort((a,b)=>b[1]-a[1])
      .map(([k,v]) => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border);">
          <span style="font-size:12px;color:var(--text2);">${k}</span>
          <span style="font-size:12px;font-weight:700;color:var(--accent);">${v}</span>
        </div>
      `).join('') || '<div style="font-size:12px;color:var(--text3);padding:8px 0;">No data yet</div>';

    const panel = document.createElement('div');
    panel.id = 'ppAdminPanel';
    panel.style.cssText = `
      position:fixed;top:68px;right:16px;z-index:60000;
      background:var(--surface);border:1px solid var(--border);border-radius:14px;
      padding:20px;width:320px;
      box-shadow:0 12px 40px rgba(0,0,0,0.18);
      font-family:var(--sans);
    `;

    panel.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
        <div style="font-family:var(--serif);font-size:16px;color:var(--text);">
          Admin Panel
        </div>
        <div style="display:flex;gap:8px;align-items:center;">
          <span style="font-size:9px;background:var(--red-bg);color:var(--red);border:1px solid var(--red-border);padding:2px 8px;border-radius:20px;font-weight:700;">PRIVATE</span>
          <button onclick="document.getElementById('ppAdminPanel').remove();" style="background:none;border:none;font-size:20px;cursor:pointer;color:var(--text3);line-height:1;">×</button>
        </div>
      </div>

      <!-- KPI cards -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;">
        ${[
          ['Total Users',    data.totalUsers,  'fa-users'],
          ['Cases Generated',data.casesGenerated,'fa-file-medical'],
          ['Sessions',       sessionCount,     'fa-calendar-check'],
          ['Top Procedure',  topProc,          'fa-tooth'],
        ].map(([label, val, icon]) => `
          <div style="background:var(--surface2);border-radius:9px;padding:12px;">
            <div style="font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--text3);margin-bottom:4px;">
              <i class="fas ${icon}" style="margin-right:4px;"></i>${label}
            </div>
            <div style="font-size:16px;font-weight:700;color:var(--accent);">${val}</div>
          </div>
        `).join('')}
      </div>

      <!-- Top Frankl + Last Used -->
      <div style="background:var(--accent-bg);border:1px solid var(--accent-border);border-radius:9px;padding:12px;margin-bottom:14px;">
        <div style="font-size:10px;font-weight:700;color:var(--accent);margin-bottom:6px;">Summary</div>
        <div style="font-size:12px;color:var(--text2);line-height:1.9;">
          <strong>Top Frankl Category:</strong> ${topFrank}<br>
          <strong>Last Active:</strong> ${lastUsed}
        </div>
      </div>

      <!-- Procedure breakdown -->
      <div style="margin-bottom:14px;">
        <div style="font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--text3);margin-bottom:8px;">Procedure Breakdown</div>
        ${procRows}
      </div>

      <!-- Actions -->
      <div style="display:flex;gap:8px;">
        <button onclick="if(confirm('Reset all analytics data?')){localStorage.removeItem('pp_analytics_v1');document.getElementById('ppAdminPanel').remove();PedoPlanAnalytics.showPanel();}" style="
          flex:1;padding:8px;border:1px solid var(--red-border);border-radius:7px;
          background:var(--red-bg);color:var(--red);font-size:11px;font-weight:600;
          cursor:pointer;font-family:var(--sans);
        ">Reset Data</button>
        <button onclick="
          const d=PedoPlanAnalytics.load();
          const b='data:text/json;charset=utf-8,'+encodeURIComponent(JSON.stringify(d,null,2));
          const a=document.createElement('a');a.href=b;a.download='kiddokanine_analytics.json';a.click();
        " style="
          flex:1;padding:8px;border:1px solid var(--border);border-radius:7px;
          background:var(--surface2);color:var(--text2);font-size:11px;font-weight:600;
          cursor:pointer;font-family:var(--sans);
        ">Export JSON</button>
      </div>

      <div style="margin-top:12px;font-size:10px;color:var(--text3);text-align:center;">
        Ctrl+Alt+P to toggle · KIDDOKANINE Admin
      </div>
    `;

    document.body.appendChild(panel);
  },

  // ── Register Ctrl+Alt+P hotkey ────────────────────────────────
  registerHotkey: function() {
    document.addEventListener('keydown', e => {
      if (e.ctrlKey && e.altKey && e.key === 'p') {
        e.preventDefault();
        PedoPlanAnalytics.showPanel();
      }
    });
  },

  init: function() {
    this.registerHotkey();
    // Hook generatePlan after DOM ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.hookGeneratePlan());
    } else {
      this.hookGeneratePlan();
    }
  }
};


// ═══════════════════════════════════════════════════════════════
// SUPABASE PATIENT STORAGE MODULE — PedoPlanDB
// ═══════════════════════════════════════════════════════════════
//
// HOW TO SET UP SUPABASE (one-time, ~10 minutes):
// ─────────────────────────────────────────────────────────────
// 1. Go to https://supabase.com → Sign up free → New Project
// 2. Note your Project URL and anon/public API key (Settings → API)
// 3. Open the SQL Editor in Supabase and run this DDL once:
//
//    CREATE TABLE patients (
//      id           uuid DEFAULT gen_random_uuid() PRIMARY KEY,
//      created_at   timestamptz DEFAULT now(),
//      user_email   text,
//      name         text NOT NULL,
//      age_group    text,
//      procedure    text,
//      behavior     text,
//      parent_profile text,
//      visit_history  text,
//      flags        text
//    );
//    -- Enable Row Level Security (optional but recommended):
//    ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
//    CREATE POLICY "anon_insert" ON patients FOR INSERT WITH CHECK (true);
//    CREATE POLICY "anon_select" ON patients FOR SELECT USING (user_email = auth.jwt()->>'email');
//
// 4. Paste your URL and KEY into the config below.
// 5. Done — patients are saved automatically on every plan generation.
// ─────────────────────────────────────────────────────────────
// FUTURE UPGRADES:
//   - Swap anon key for user JWT once Supabase Auth is wired in
//   - Add RLS policy per user_email for private patient records
//   - Add soft-delete (deleted_at column) instead of hard DELETE
// ═══════════════════════════════════════════════════════════════

const PedoPlanDB = {

  // ── CONFIGURATION — fill these in after Supabase setup ───────
  SUPABASE_URL : 'https://ebtvqlltlrbjubkbitdu.supabase.co',
  SUPABASE_KEY : 'sb_publishable_If9dyweScLVGsFFr4MIwmQ_0CAINVbB',
  TABLE        : 'patients',
  
  // ── Local storage key for offline/desktop mode ────────────────
  LOCAL_STORAGE_KEY: 'pp_patients_local',

  // ── Internal: true once URL+KEY have been set ─────────────────
  get configured() {
    return this.SUPABASE_URL !== 'YOUR_SUPABASE_PROJECT_URL' &&
           this.SUPABASE_KEY !== 'YOUR_SUPABASE_ANON_KEY';
  },
  
  // ── Check if running in Electron (desktop mode) ───────────────
  get isDesktopMode() {
    return window.electronAPI && window.electronAPI.isElectron;
  },

  // ── Internal: build Supabase REST endpoint ────────────────────
  _endpoint: function(params = '') {
    return `${this.SUPABASE_URL}/rest/v1/${this.TABLE}${params}`;
  },

  // ── Internal: standard headers for every request ─────────────
  _headers: function(extra = {}) {
    return {
      'Content-Type'  : 'application/json',
      'apikey'        : this.SUPABASE_KEY,
      'Authorization' : `Bearer ${this.SUPABASE_KEY}`,
      ...extra
    };
  },

  // ── Get current user email from auth session ──────────────────
  _userEmail: function() {
    try {
      const s = JSON.parse(localStorage.getItem('pp_auth_session') || '{}');
      return s.email || 'anonymous';
    } catch { return 'anonymous'; }
  },

  // ── SAVE a patient record ─────────────────────────────────────
  // Called automatically after every plan generation.
  // Fields: name, age_group, procedure, behavior,
  //         parent_profile, visit_history, flags
  savePatient: async function(data) {
    // Desktop mode: save to localStorage
    if (this.isDesktopMode || !this.configured) {
      console.info('PedoPlanDB: Saving patient to local storage (desktop mode)');
      return this._savePatientLocal(data);
    }
    
    // Web mode with Supabase configured
    const payload = {
      user_email     : this._userEmail(),
      name           : data.name           || '',
      age_group      : data.age_group      || '',
      procedure      : data.procedure      || '',
      behavior       : data.behavior       || '',
      parent_profile : data.parent_profile || '',
      visit_history  : data.visit_history  || '',
      flags          : data.flags          || ''
    };
    const res = await fetch(this._endpoint(), {
      method  : 'POST',
      headers : this._headers({ 'Prefer': 'return=representation' }),
      body    : JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Supabase insert failed: ${err}`);
    }
    const saved = await res.json();
    this._refreshBadge();
    return saved[0];
  },
  
  // ── LOCAL STORAGE: Save patient ───────────────────────────────
  _savePatientLocal: function(data) {
    const patients = this._loadPatientsLocal();
    const newPatient = {
      id             : Date.now(), // Simple ID
      user_email     : this._userEmail(),
      name           : data.name           || '',
      age_group      : data.age_group      || '',
      procedure      : data.procedure      || '',
      behavior       : data.behavior       || '',
      parent_profile : data.parent_profile || '',
      visit_history  : data.visit_history  || '',
      flags          : data.flags          || '',
      created_at     : new Date().toISOString()
    };
    patients.unshift(newPatient); // Add to beginning
    
    // Keep only last 200 patients
    if (patients.length > 200) {
      patients.length = 200;
    }
    
    localStorage.setItem(this.LOCAL_STORAGE_KEY, JSON.stringify(patients));
    this._refreshBadge();
    return newPatient;
  },
  
  // ── LOCAL STORAGE: Load all patients ──────────────────────────
  _loadPatientsLocal: function() {
    try {
      const data = localStorage.getItem(this.LOCAL_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (err) {
      console.error('Error loading local patients:', err);
      return [];
    }
  },

  // ── LOAD all patients for this user ──────────────────────────
  // Returns newest-first, max 200 records.
  loadPatients: async function() {
    // Desktop mode: load from localStorage
    if (this.isDesktopMode || !this.configured) {
      console.info('PedoPlanDB: Loading patients from local storage (desktop mode)');
      return this._loadPatientsLocal();
    }
    
    // Web mode with Supabase
    const email = this._userEmail();
    const params = `?user_email=eq.${encodeURIComponent(email)}&order=created_at.desc&limit=200`;
    const res = await fetch(this._endpoint(params), {
      headers: this._headers({ 'Accept': 'application/json' })
    });
    if (!res.ok) throw new Error('Supabase fetch failed: ' + await res.text());
    return res.json();
  },

  // ── DELETE a patient record by id (scoped to current user) ──
  deletePatient: async function(id) {
    // Desktop mode: delete from localStorage
    if (this.isDesktopMode || !this.configured) {
      const patients = this._loadPatientsLocal();
      const filtered = patients.filter(p => p.id !== id);
      localStorage.setItem(this.LOCAL_STORAGE_KEY, JSON.stringify(filtered));
      this._refreshBadge();
      return;
    }
    
    // Web mode with Supabase
    const email = this._userEmail();
    const res = await fetch(
      this._endpoint(`?id=eq.${id}&user_email=eq.${encodeURIComponent(email)}`),
      { method: 'DELETE', headers: this._headers() }
    );
    if (!res.ok) throw new Error('Supabase delete failed');
  },

  // ── SEARCH patients client-side ───────────────────────────────
  searchPatients: function(patients, query) {
    if (!query.trim()) return patients;
    const q = query.toLowerCase();
    return patients.filter(p =>
      (p.name       || '').toLowerCase().includes(q) ||
      (p.procedure  || '').toLowerCase().includes(q) ||
      (p.age_group  || '').toLowerCase().includes(q) ||
      (p.behavior   || '').toLowerCase().includes(q)
    );
  },

  // ── UPDATE badge count on Patients nav button ─────────────────
  _refreshBadge: async function() {
    try {
      const list = await this.loadPatients();
      const btn = document.getElementById('ppPatientsBtn');
      if (btn && list.length > 0) {
        const existing = btn.querySelector('.pp-badge-count');
        if (existing) existing.remove();
        const badge = document.createElement('span');
        badge.className = 'pp-badge-count';
        badge.style.cssText = `
          background:var(--accent);color:white;border-radius:10px;
          font-size:9px;font-weight:700;padding:1px 5px;margin-left:2px;
        `;
        badge.textContent = list.length;
        btn.appendChild(badge);
      }
    } catch(e) {}
  },

  // ── FORMAT helpers ────────────────────────────────────────────
  _label: {
    age_group: {
      infant: 'Infant (0–18mo)', toddler: 'Toddler (1.5–3yr)',
      preschool: 'Pre-school (3–6yr)', schoolage: 'School-age (6–9yr)', preteen: 'Pre-teen (9–12yr)'
    },
    behavior: {
      // underscore keys — match radio button values
      'definitely_negative': 'Frankl 1 — Def. Negative',
      'negative':            'Frankl 2 — Negative',
      'positive':            'Frankl 3 — Positive',
      'definitely_positive': 'Frankl 4 — Def. Positive',
      // hyphen aliases for any legacy records already saved
      'definitely-negative': 'Frankl 1 — Def. Negative',
      'definitely-positive': 'Frankl 4 — Def. Positive'
    }
  },
  _fmt: function(type, val) {
    return (this._label[type] && this._label[type][val]) || val || '—';
  },
  _date: function(iso) {
    try {
      return new Date(iso).toLocaleString('en-IN', {
        day:'2-digit', month:'short', year:'numeric',
        hour:'2-digit', minute:'2-digit'
      });
    } catch { return iso; }
  },

  // ── SHOW HISTORY PANEL ────────────────────────────────────────
  showHistory: async function() {
    // Remove any existing panel
    const old = document.getElementById('ppPatientHistoryModal');
    if (old) { old.remove(); return; }

    // Build skeleton immediately, populate async
    const modal = document.createElement('div');
    modal.id = 'ppPatientHistoryModal';
    modal.style.cssText = `
      position:fixed;inset:0;z-index:50000;
      background:rgba(20,15,10,.65);backdrop-filter:blur(4px);
      display:flex;align-items:center;justify-content:center;
      padding:16px;overflow-y:auto;font-family:var(--sans);
    `;
    modal.addEventListener('click', e => { if(e.target === modal) modal.remove(); });

    modal.innerHTML = `
      <div style="
        background:var(--surface);border:1px solid var(--border);border-radius:16px;
        max-width:720px;width:100%;padding:0;position:relative;
        box-shadow:0 24px 64px rgba(0,0,0,0.2);max-height:90vh;
        display:flex;flex-direction:column;overflow:hidden;
      ">
        <!-- Header -->
        <div style="padding:20px 24px 16px;border-bottom:1px solid var(--border);flex-shrink:0;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
            <div style="font-family:var(--serif);font-size:20px;color:var(--text);">
              <i class="fas fa-users" style="color:var(--accent);margin-right:8px;font-size:16px;"></i>
              Patient History
            </div>
            <button onclick="document.getElementById('ppPatientHistoryModal').remove();" style="
              background:none;border:none;font-size:22px;cursor:pointer;
              color:var(--text3);line-height:1;padding:4px;
            ">×</button>
          </div>
          <!-- Search bar -->
          <div style="position:relative;">
            <i class="fas fa-search" style="position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--text3);font-size:12px;"></i>
            <input id="ppPatientSearch" type="text" placeholder="Search by name, procedure, age group…"
              style="
                width:100%;padding:9px 12px 9px 32px;border:1px solid var(--border);
                border-radius:8px;background:var(--bg);color:var(--text);
                font-family:var(--sans);font-size:13px;outline:none;box-sizing:border-box;
              "
              oninput="PedoPlanDB._filterTable(this.value)"
            />
          </div>
        </div>

        <!-- Status / not-configured banner -->
        ${!this.configured ? `
          <div style="
            margin:16px 24px 0;padding:14px 16px;
            background:var(--amber-bg);border:1px solid var(--amber-border);border-radius:10px;
            font-size:12px;color:var(--amber);line-height:1.7;
          ">
            <strong><i class="fas fa-wrench"></i> Supabase not configured yet.</strong><br>
            Open the HTML file, find <code>PedoPlanDB</code> near the bottom, and paste your
            <code>SUPABASE_URL</code> and <code>SUPABASE_KEY</code>.<br>
            Run the SQL from the comments to create the <code>patients</code> table, then refresh.
          </div>
        ` : ''}

        <!-- Table container (scrollable) -->
        <div style="overflow-y:auto;flex:1;padding:16px 24px 20px;">
          <div id="ppPatientTableWrap">
            <div style="text-align:center;padding:40px;color:var(--text3);">
              <i class="fas fa-spinner fa-spin" style="font-size:24px;margin-bottom:10px;display:block;"></i>
              Loading patients…
            </div>
          </div>
        </div>

        <!-- Footer -->
        <div id="ppPatientFooter" style="
          padding:12px 24px;border-top:1px solid var(--border);flex-shrink:0;
          display:flex;justify-content:space-between;align-items:center;
          font-size:11px;color:var(--text3);background:var(--surface2);
        ">
          <span id="ppPatientCount">—</span>
          <span>
            <i class="fas fa-user-circle" style="margin-right:4px;color:var(--accent);"></i>
            <strong style="color:var(--text2);">${this._userEmail()}</strong>
            &nbsp;·&nbsp;Sorted newest first&nbsp;·&nbsp;Synced via Supabase
          </span>
        </div>
      </div>
    `;

    document.body.appendChild(modal);
    document.addEventListener('keydown', function escH(e) {
      if (e.key === 'Escape') { modal.remove(); document.removeEventListener('keydown', escH); }
    });

    // Async load
    this._currentPatients = [];
    try {
      const patients = await this.loadPatients();
      this._currentPatients = patients;
      this._renderTable(patients);
      document.getElementById('ppPatientCount').textContent =
        patients.length === 0 ? 'No patients yet' : `${patients.length} patient${patients.length !== 1 ? 's' : ''} stored`;
    } catch(err) {
      document.getElementById('ppPatientTableWrap').innerHTML = `
        <div style="
          text-align:center;padding:32px;
          background:var(--red-bg);border:1px solid var(--red-border);
          border-radius:10px;color:var(--red);font-size:13px;
        ">
          <i class="fas fa-exclamation-circle" style="font-size:20px;margin-bottom:8px;display:block;"></i>
          <strong>Could not load patients.</strong><br>
          Check your Supabase URL/Key and internet connection.<br>
          <code style="font-size:10px;opacity:.7;">${err.message}</code>
        </div>
      `;
      document.getElementById('ppPatientCount').textContent = 'Error loading data';
    }
  },

  // ── Internal: render table rows ───────────────────────────────
  _currentPatients: [],
  _renderTable: function(patients) {
    const wrap = document.getElementById('ppPatientTableWrap');
    if (!wrap) return;

    if (!patients.length) {
      wrap.innerHTML = `
        <div style="text-align:center;padding:48px 24px;color:var(--text3);">
          <i class="fas fa-user-plus" style="font-size:32px;margin-bottom:12px;display:block;opacity:.4;"></i>
          <div style="font-size:14px;font-weight:600;color:var(--text2);">No patients yet</div>
          <div style="font-size:12px;margin-top:4px;">Generate a plan to save the first record.</div>
        </div>
      `;
      return;
    }

    const rows = patients.map(p => `
      <tr id="ppRow-${p.id}" style="border-bottom:1px solid var(--border);">
        <td style="padding:10px 12px;font-weight:600;font-size:13px;color:var(--text);">${p.name || '—'}</td>
        <td style="padding:10px 8px;font-size:12px;color:var(--text2);">${this._fmt('age_group', p.age_group)}</td>
        <td style="padding:10px 8px;font-size:12px;color:var(--text2);">${p.procedure || '—'}</td>
        <td style="padding:10px 8px;">
          <span style="
            font-size:10px;font-weight:700;padding:2px 7px;border-radius:20px;white-space:nowrap;
            ${(p.behavior === 'definitely_negative' || p.behavior === 'definitely-negative') ? 'background:var(--red-bg);color:var(--red);border:1px solid var(--red-border);' :
              (p.behavior === 'negative')                                                     ? 'background:var(--amber-bg);color:var(--amber);border:1px solid var(--amber-border);' :
              (p.behavior === 'positive')                                                     ? 'background:var(--green-bg);color:var(--green);border:1px solid var(--green-border);' :
                                                                                               'background:var(--accent-bg);color:var(--accent);border:1px solid var(--accent-border);'}
          ">${this._fmt('behavior', p.behavior)}</span>
        </td>
        <td style="padding:10px 8px;font-size:11px;color:var(--text3);white-space:nowrap;">${this._date(p.created_at)}</td>
        <td style="padding:10px 8px;text-align:center;">
          <button onclick="PedoPlanDB._reloadPatient('${p.id}')" title="Load into form"
            style="background:var(--accent-bg);border:1px solid var(--accent-border);color:var(--accent);
            border-radius:6px;padding:4px 9px;cursor:pointer;font-size:11px;font-weight:600;
            font-family:var(--sans);margin-right:4px;">
            <i class="fas fa-redo" style="font-size:10px;"></i> Load
          </button>
          <button onclick="PedoPlanDB._confirmDelete('${p.id}')" title="Delete record"
            style="background:var(--red-bg);border:1px solid var(--red-border);color:var(--red);
            border-radius:6px;padding:4px 8px;cursor:pointer;font-size:11px;
            font-family:var(--sans);">
            <i class="fas fa-trash" style="font-size:10px;"></i>
          </button>
        </td>
      </tr>
    `).join('');

    wrap.innerHTML = `
      <table style="width:100%;border-collapse:collapse;">
        <thead>
          <tr style="background:var(--surface2);">
            ${['Patient','Age Group','Procedure','Frankl','Saved','Actions'].map(h =>
              `<th style="padding:8px 12px;text-align:left;font-size:10px;font-weight:700;
                letter-spacing:.06em;text-transform:uppercase;color:var(--text3);
                border-bottom:1px solid var(--border);">${h}</th>`
            ).join('')}
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    `;
  },

  // ── Internal: live search filter ─────────────────────────────
  _filterTable: function(query) {
    const filtered = this.searchPatients(this._currentPatients, query);
    this._renderTable(filtered);
    const count = document.getElementById('ppPatientCount');
    if (count) count.textContent = query
      ? `${filtered.length} of ${this._currentPatients.length} patients`
      : `${this._currentPatients.length} patient${this._currentPatients.length !== 1 ? 's' : ''} stored`;
  },

  // ── Internal: reload patient into intake form ─────────────────
  _reloadPatient: function(id) {
    const p = this._currentPatients.find(x => x.id === id);
    if (!p) return;

    // Populate form fields
    const set = (elId, val) => { const el = document.getElementById(elId); if (el) el.value = val || ''; };
    set('patientName',   p.name);
    set('ageGroup',      p.age_group);
    set('procedure',     p.procedure);
    set('parentProfile', p.parent_profile);
    set('visitHistory',  p.visit_history);

    // Set behavior radio
    const radio = document.querySelector(`input[name="behavior"][value="${p.behavior}"]`);
    if (radio) {
      radio.checked = true;
      // Trigger the radio card selected state
      document.querySelectorAll('.radio-card').forEach(c => c.classList.remove('selected'));
      const card = radio.closest('.radio-card');
      if (card) card.classList.add('selected');
    }

    // Set flags (checkboxes)
    document.querySelectorAll('input[name="flag"]').forEach(cb => {
      cb.checked = (p.flags || '').split(',').includes(cb.value);
    });

    // Update procedure dropdown (triggers any dependent UI)
    if (typeof updateProcedures === 'function') updateProcedures();

    // Close modal and scroll to form
    document.getElementById('ppPatientHistoryModal')?.remove();
    document.getElementById('intakeForm')?.scrollIntoView({ behavior: 'smooth' });
    toast(`Loaded: ${p.name}`);
  },

  // ── Internal: confirm + delete ────────────────────────────────
  _confirmDelete: async function(id) {
    const p = this._currentPatients.find(x => x.id === id);
    if (!confirm(`Delete record for "${p?.name || 'this patient'}"? This cannot be undone.`)) return;
    try {
      await this.deletePatient(id);
      this._currentPatients = this._currentPatients.filter(x => x.id !== id);
      this._renderTable(this._currentPatients);
      const count = document.getElementById('ppPatientCount');
      if (count) count.textContent = `${this._currentPatients.length} patients stored`;
      this._refreshBadge();
      toast('Patient record deleted.');
    } catch(e) {
      toast('Delete failed — check connection.');
    }
  },

  // ── INIT: load badge count on app start ───────────────────────
  init: function() {
    // Refresh badge after DOM is ready (non-blocking)
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this._refreshBadge());
    } else {
      this._refreshBadge();
    }
  }
};

// ═══════════════════════════════════════════════════════════════
// KIDDOKANINE LICENSE SYSTEM
// ═══════════════════════════════════════════════════════════════

const KiddokanineLicense = {
  VALID_KEYS: [
    "KDKN-X7M2-9QR4-LP83", "KDKN-B5TW-KJ16-ZN94", "KDKN-H3PQ-8MV7-CR52", "KDKN-A9FX-2WT5-DK61",
    "KDKN-R4NZ-7YB3-QM18", "KDKN-G8KL-5XP9-TJ27", "KDKN-U2VM-4HC8-WF36", "KDKN-S6DT-1QN5-YB74",
    "KDKN-E7RJ-9KW2-MX45", "KDKN-C3PH-6ZT8-VN19", "KDKN-F5YB-2MR7-LK93", "KDKN-W9QX-8DS4-GJ61",
    "KDKN-T1NK-3VP6-XH28", "KDKN-D4MW-7YC2-RQ57", "KDKN-J6FZ-5BT9-PN34", "KDKN-L8XR-1QM4-HV72",
    "KDKN-V2TG-9KN6-BS48", "KDKN-N5CJ-4WP8-ZD13", "KDKN-Q7HL-6YF3-KM96", "KDKN-Y3BV-2XS7-TC85"
  ],
  init: function() {
    if (localStorage.getItem('kiddokanine_licensed') === 'true') return;
    this.showGate();
  },
  showGate: function() {
    const overlay = document.createElement('div');
    overlay.id = 'kiddokanine-license-gate';
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:#f5f2ec;z-index:999999;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;text-align:center;font-family:sans-serif;';
    overlay.innerHTML = `
      <div style="background:#fff;padding:30px;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,0.1);max-width:400px;width:100%;">
        <h2 style="color:#003087;margin-top:0;">Welcome to KIDDOKANINE</h2>
        <p style="color:#666;font-size:14px;margin-bottom:20px;">Please enter your premium license key to unlock the clinical matrix.</p>
        <input type="text" id="kdk-license-input" placeholder="KDKN-XXXX-XXXX-XXXX" style="width:100%;padding:12px;border:1px solid #ccc;border-radius:6px;margin-bottom:15px;font-size:16px;text-transform:uppercase;box-sizing:border-box;">
        <button onclick="KiddokanineLicense.verify()" style="background:#003087;color:#fff;border:none;padding:12px 20px;border-radius:6px;font-size:16px;cursor:pointer;width:100%;font-weight:bold;">Unlock App</button>
        <p id="kdk-license-error" style="color:#b5401a;font-size:13px;margin-top:15px;display:none;"></p>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  verify: function() {
    const input = document.getElementById('kdk-license-input').value.trim().toUpperCase();
    const errorEl = document.getElementById('kdk-license-error');
    if (this.VALID_KEYS.includes(input)) {
      localStorage.setItem('kiddokanine_licensed', 'true');
      document.getElementById('kiddokanine-license-gate').remove();
    } else {
      errorEl.textContent = "Invalid license key. Please check your purchase email.";
      errorEl.style.display = 'block';
    }
  },
  reset: function() {
    if(confirm("Are you sure you want to remove your license key from this device?")) {
      localStorage.removeItem('kiddokanine_licensed');
      location.reload();
    }
  }
};

// ═══════════════════════════════════════════════════════════════
// BOOT — initialise all modules
// ═══════════════════════════════════════════════════════════════

(function PedoPlanSecurityBoot() {
  // F4: anti-copy runs immediately (before DOM)
  // DISABLED FOR MOBILE APP - No protection needed
  // PedoPlanProtection.init();

  // F6: analytics + hotkey (before DOM for keydown listener)
  PedoPlanAnalytics.init();

  // F5: watermark patches exports (waits for DOMContentLoaded internally)
  PedoPlanWatermark.init();

  // F2: branding patches nav + footer (waits for DOMContentLoaded internally)
  PedoPlanBranding.init();

  // KIDDOKANINE License: check license status before loading app
  KiddokanineLicense.init();

  // Patient DB: load badge count after DOM ready
  PedoPlanDB.init();

  console.log(`%c${APP_CONFIG.appName} Security Module loaded — ${APP_CONFIG.version}`, 'color:#003087;font-weight:bold;');
})();

